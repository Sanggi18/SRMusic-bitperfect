package com.example.ui.lyrics.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.unit.dp

private const val INTERLUDE_DOT_COUNT = 3
private const val INTERLUDE_ROW_HEIGHT_DP = 36
private const val INTERLUDE_DOT_REST_ALPHA = 0.25f
private const val INTERLUDE_DOT_REST_SCALE = 0.80f

/**
 * Titik interlude gaya baru (adopt logika LyricGapContent):
 * baris expand 0 -> 36dp saat jeda aktif lalu collapse lagi,
 * dan tiap titik menyala progresif mengikuti progres jeda —
 * titik ke-i terisi penuh di sepertiga ke-i dari durasi jeda.
 * Digambar via Canvas, tanpa recomposition per frame.
 */
@Composable
fun InterludeDotsContent(
    progress: Float,
    isCurrent: Boolean,
    accentColor: Color,
    modifier: Modifier = Modifier,
) {
    val heightFactor by animateFloatAsState(
        targetValue = if (isCurrent) 1f else 0f,
        animationSpec = tween(
            durationMillis = if (isCurrent) 400 else 350,
            easing = FastOutSlowInEasing
        ),
        label = "interlude_height_factor",
    )

    val dotAlpha by animateFloatAsState(
        targetValue = if (isCurrent) 1f else 0f,
        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing),
        label = "interlude_alpha",
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .layout { measurable, constraints ->
                val targetHeightPx = (INTERLUDE_ROW_HEIGHT_DP.dp * heightFactor).roundToPx()
                val placeable = measurable.measure(
                    constraints.copy(
                        minHeight = targetHeightPx,
                        maxHeight = targetHeightPx
                    )
                )
                layout(placeable.width, placeable.height) {
                    placeable.placeRelative(0, 0)
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Canvas(
            modifier = Modifier
                .padding(start = 8.dp)
                .size(width = 48.dp, height = 12.dp)
                .graphicsLayer { alpha = dotAlpha },
        ) {
            val radius = 4.dp.toPx()
            val dotSpacing = 6.dp.toPx()
            val dotStride = radius * 2f + dotSpacing

            repeat(INTERLUDE_DOT_COUNT) { dotIndex ->
                val lit = (progress * INTERLUDE_DOT_COUNT - dotIndex).coerceIn(0f, 1f)

                val alpha = INTERLUDE_DOT_REST_ALPHA + (1f - INTERLUDE_DOT_REST_ALPHA) * lit
                val dotScale = INTERLUDE_DOT_REST_SCALE + (1f - INTERLUDE_DOT_REST_SCALE) * lit

                drawCircle(
                    color = accentColor.copy(alpha = alpha),
                    radius = radius * dotScale,
                    center = Offset(
                        x = radius + dotIndex * dotStride,
                        y = size.height / 2f,
                    ),
                )
            }
        }
    }
}
