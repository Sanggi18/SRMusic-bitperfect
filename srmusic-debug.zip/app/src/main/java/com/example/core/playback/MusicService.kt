package com.example.core.playback

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Handler
import android.os.SystemClock
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.decent.usbaudio.UsbAudioDevice
import com.decent.usbaudio.UsbAudioPermissionHelper
import com.example.MainActivity
import com.example.core.audio.AudioOutputApi
import com.example.core.data.preferences.EqualizerPreferences

class MusicService : MediaSessionService() {

    companion object {
        private const val TAG = "SRMusicAudioDiag"

        @Volatile
        var activePlayer: ExoPlayer? = null
            private set

        @Volatile
        private var instance: MusicService? = null

        fun requestAudioOutputApiChange(api: AudioOutputApi) {
            val service = instance ?: return
            Handler(service.mainLooper).post {
                service.onUserRequestedAudioOutputApiChange(api)
            }
        }

        fun requestBitPerfectChange(enabled: Boolean) {
            val service = instance ?: return
            Handler(service.mainLooper).post {
                service.onUserRequestedBitPerfectChange(enabled)
            }
        }
    }

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private var equalizerEngine: EqualizerAudioEngine? = null

    // Separate persistent user preference from temporary effective backend
    private var userSelectedAudioApi: AudioOutputApi = AudioOutputApi.AUDIOTRACK
    private var effectiveAudioApi: AudioOutputApi = AudioOutputApi.AUDIOTRACK

    // User preference vs effective runtime status for Bit Perfect
    private var userBitPerfectEnabled: Boolean = false
    private var effectiveBitPerfectActive: Boolean = false

    // Guard against concurrent or re-entrant player rebuilds
    private var isRebuilding = false
    private var playerGeneration: Long = 0L

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            if (action == UsbManager.ACTION_USB_DEVICE_DETACHED) {
                Log.i(TAG, "ACTION_USB_DEVICE_DETACHED received")
                if (effectiveBitPerfectActive) {
                    onUsbStreamUnavailable()
                }
            }
        }
    }

    private fun onUserRequestedAudioOutputApiChange(api: AudioOutputApi) {
        userSelectedAudioApi = api
        Log.i(TAG, "USER_SELECT_AUDIO_API: $api")
        rebuildPlayer(api, effectiveBitPerfectActive)
    }

    private fun onUserRequestedBitPerfectChange(enabled: Boolean) {
        userBitPerfectEnabled = enabled
        Log.i(TAG, "USER_SELECT_BIT_PERFECT: $enabled")

        if (enabled) {
            val deviceManager = UsbAudioDevice.getInstance(this)
            val usbDevice = deviceManager.findUsbAudioDevice()
            if (usbDevice != null && !deviceManager.hasPermission(usbDevice)) {
                deviceManager.requestPermission(usbDevice) { granted ->
                    if (granted) {
                        Handler(mainLooper).post {
                            if (userBitPerfectEnabled) {
                                rebuildPlayer(userSelectedAudioApi, isBitPerfect = true)
                            }
                        }
                    } else {
                        Log.w(TAG, "USB DAC permission denied by user; remaining on normal output")
                    }
                }
                return
            }
            rebuildPlayer(userSelectedAudioApi, isBitPerfect = true)
        } else {
            rebuildPlayer(userSelectedAudioApi, isBitPerfect = false)
        }
    }

    private fun onUsbStreamUnavailable() {
        Log.w(TAG, "USB stream unavailable/failed; falling back to normal output $userSelectedAudioApi")
        if (effectiveBitPerfectActive) {
            rebuildPlayer(userSelectedAudioApi, isBitPerfect = false)
        }
    }

    @OptIn(UnstableApi::class)
    private fun createPlayer(api: AudioOutputApi, isBitPerfect: Boolean): ExoPlayer {
        val currentGen = ++playerGeneration
        val audioAttributes = AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .setUsage(C.USAGE_MEDIA)
            .build()

        val renderersFactory = FfmpegRenderersFactory(
            context = this,
            audioOutputApi = api,
            isBitPerfectEnabled = isBitPerfect,
            onInputFormatConfigured = { format ->
                Log.d(
                    TAG,
                    "DECODER_OUTPUT_PCM: rate=${format.sampleRate} ch=${format.channelCount} enc=${format.pcmEncoding}"
                )
            },
            onEffectiveOutputConfigured = { outputConfig ->
                Log.d(
                    TAG,
                    "EFFECTIVE_OUTPUT_CONFIG: rate=${outputConfig.sampleRate} mask=${outputConfig.channelMask} enc=${outputConfig.encoding}"
                )
            },
            onBackendFailure = { failedApi, reason ->
                Handler(mainLooper).post {
                    if (effectiveAudioApi == failedApi && failedApi != AudioOutputApi.AUDIOTRACK) {
                        Log.w(
                            TAG,
                            "FALLBACK requested=$failedApi reason=$reason; rebuilding to AudioTrack"
                        )
                        rebuildPlayer(AudioOutputApi.AUDIOTRACK, effectiveBitPerfectActive)
                    }
                }
            },
            onUsbOutputUnavailable = {
                Handler(mainLooper).post {
                    onUsbStreamUnavailable()
                }
            }
        )

        return ExoPlayer.Builder(this, renderersFactory)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build().apply {
                repeatMode = Player.REPEAT_MODE_ALL
            }
    }

    private fun setupPlayerListener(exoPlayer: ExoPlayer, eqEngine: EqualizerAudioEngine) {
        exoPlayer.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId != 0 && audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                    eqEngine.attachToSession(audioSessionId)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    val sid = exoPlayer.audioSessionId
                    if (sid != 0 && sid != C.AUDIO_SESSION_ID_UNSET) {
                        eqEngine.attachToSession(sid)
                    }
                    Log.i(
                        TAG,
                        "PLAYER_READY backend=$effectiveAudioApi isBitPerfect=$effectiveBitPerfectActive audioSessionId=$sid posMs=${exoPlayer.currentPosition}"
                    )
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                Log.e(
                    TAG,
                    "PLAYER_ERROR backend=$effectiveAudioApi errorCode=${error.errorCode} message=${error.message}",
                    error
                )
            }
        })
    }

    @OptIn(UnstableApi::class)
    override fun onCreate() {
        super.onCreate()
        instance = this

        val eqPrefs = EqualizerPreferences(this)
        val eqConfig = eqPrefs.loadEqualizerConfig()
        val initialApi = eqConfig.selectedAudioOutputApi
        val initialBitPerfect = eqConfig.isBitPerfectEnabled
        userSelectedAudioApi = initialApi
        effectiveAudioApi = initialApi
        userBitPerfectEnabled = initialBitPerfect

        val startWithBitPerfect = initialBitPerfect && UsbAudioDevice.getInstance(this).let {
            val d = it.findUsbAudioDevice()
            d != null && it.hasPermission(d)
        }
        effectiveBitPerfectActive = startWithBitPerfect

        Log.i(TAG, "INIT_PLAYER initialApi=$initialApi bitPerfectRequested=$initialBitPerfect effectiveBitPerfect=$startWithBitPerfect")

        val eqEngine = EqualizerAudioEngine(this, eqPrefs)
        equalizerEngine = eqEngine

        player = createPlayer(initialApi, startWithBitPerfect)
        setupPlayerListener(player, eqEngine)
        activePlayer = player

        val sessionActivityPendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivityPendingIntent)
            .build()

        // Register USB detach receiver
        val filter = IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }

        // Register callback for when device is claimed via MainActivity
        UsbAudioPermissionHelper.onDeviceClaimed = { device ->
            Handler(mainLooper).post {
                if (userBitPerfectEnabled && !effectiveBitPerfectActive) {
                    Log.i(TAG, "USB device claimed (${device.productName}); switching to Bit Perfect")
                    rebuildPlayer(userSelectedAudioApi, isBitPerfect = true)
                }
            }
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = mediaSession?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    @OptIn(UnstableApi::class)
    fun rebuildPlayerWithApi(api: AudioOutputApi) {
        rebuildPlayer(api, effectiveBitPerfectActive)
    }

    @OptIn(UnstableApi::class)
    fun rebuildPlayer(api: AudioOutputApi, isBitPerfect: Boolean) {
        if (isRebuilding) {
            Log.d(TAG, "rebuildPlayer already in progress, skipping duplicate call for $api (bitPerfect=$isBitPerfect)")
            return
        }
        if (api == effectiveAudioApi && isBitPerfect == effectiveBitPerfectActive && ::player.isInitialized) {
            Log.d(TAG, "SWITCH ignored: API unchanged ($api) and BitPerfect unchanged ($isBitPerfect)")
            return
        }

        isRebuilding = true
        try {
            Log.i(TAG, "SWITCH requested api=$api bitPerfect=$isBitPerfect (previous api=$effectiveAudioApi bitPerfect=$effectiveBitPerfectActive)")
            val startTimeMs = SystemClock.elapsedRealtime()

            val oldPlayer = player
            val session = mediaSession ?: return

            // 1. Snapshot all playlist items and playback state
            val count = oldPlayer.mediaItemCount
            val mediaItems = ArrayList<MediaItem>(count)
            for (i in 0 until count) {
                mediaItems.add(oldPlayer.getMediaItemAt(i))
            }
            val currentIndex = oldPlayer.currentMediaItemIndex
            val currentPosition = oldPlayer.currentPosition
            val playWhenReady = oldPlayer.playWhenReady
            val playbackState = oldPlayer.playbackState
            val repeatMode = oldPlayer.repeatMode
            val shuffleModeEnabled = oldPlayer.shuffleModeEnabled
            val playbackParameters = oldPlayer.playbackParameters

            Log.i(
                TAG,
                "SWITCH_START items=$count index=$currentIndex posMs=$currentPosition state=$playbackState"
            )

            // 2. Build new ExoPlayer with the requested backend and sink
            val newPlayer = createPlayer(api, isBitPerfect)

            // 3. Attach new player to MediaSession
            session.setPlayer(newPlayer)

            // 4. Restore configuration & playlist
            newPlayer.repeatMode = repeatMode
            newPlayer.shuffleModeEnabled = shuffleModeEnabled
            newPlayer.playbackParameters = playbackParameters

            if (mediaItems.isNotEmpty()) {
                newPlayer.setMediaItems(mediaItems, currentIndex, currentPosition)
                if (playbackState != Player.STATE_IDLE) {
                    newPlayer.prepare()
                }
            }
            newPlayer.playWhenReady = playWhenReady

            // 5. Setup audio session listener
            equalizerEngine?.let { setupPlayerListener(newPlayer, it) }

            // 6. Update reference fields
            player = newPlayer
            activePlayer = newPlayer
            effectiveAudioApi = api
            effectiveBitPerfectActive = isBitPerfect

            // 7. Safely release old player
            oldPlayer.release()

            val elapsedMs = SystemClock.elapsedRealtime() - startTimeMs
            Log.i(
                TAG,
                "SWITCH_DONE newEffectiveBackend=$api isBitPerfect=$isBitPerfect items=${newPlayer.mediaItemCount} index=${newPlayer.currentMediaItemIndex} posMs=${newPlayer.currentPosition} playWhenReady=$playWhenReady elapsedMs=$elapsedMs"
            )
        } finally {
            isRebuilding = false
        }
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        try {
            unregisterReceiver(usbReceiver)
        } catch (_: Exception) {}
        UsbAudioPermissionHelper.onDeviceClaimed = null

        equalizerEngine?.destroy()
        equalizerEngine = null
        activePlayer = null
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
