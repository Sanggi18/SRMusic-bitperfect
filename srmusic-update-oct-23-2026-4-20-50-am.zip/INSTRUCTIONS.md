# SRMusic Android Architecture & UI/UX Instructions

Dokumen ini adalah referensi arsitektur dan standar implementasi resmi untuk proyek **SRMusic Android App**. Setiap pengembang atau AI Agent **WAJIB** membaca dan mematuhi spesifikasi di bawah ini sebelum merancang atau memodifikasi kode.

---

## 1. Pemisahan Layer Arsitektur (Separation of Concerns)

Proyek mengikuti pola arsitektur **Clean Architecture / MVVM-MVI** yang terstruktur sebagai berikut:

### A. Core Layer (`core/`)
- Berisi seluruh logika domain, pemrosesan data, playback engine, dan utilities bersama.
  - `core/model/`: Domain data models (misal `Song`, `ArtworkRef`, `EqualizerConfig`, `PlaybackState`).
  - `core/data/`: Data persistence (Room DAOs, database migrations, SharedPreferences/DataStore).
  - `core/playback/`: Media3 ExoPlayer, FFmpeg renderers, audio sink pipeline, MusicService lifecycle.
  - `core/audio/`: Oboe, audio output detectors, terminal logger, DAC volume & sample rate modes.
  - `core/util/`: Filter algorithms (AlbumFilter, ArtistFilter), folder parsers, time formatting.
- **ATURAN MUTLAK**: Layer `core/` **TIDAK BOLEH** mengimpor atau bergantung pada layer `ui/`.

### B. Feature Layer (`ui/<feature>/`)
- Setiap fitur mengisolasi state management dan komponen visualnya sendiri:
  - `ui/<feature>/core/`: ViewModel, UiState, dan Actions spesifik untuk fitur tersebut. State management tetap berada di dalam folder fiturnya, BUKAN di `core/`.
  - `ui/<feature>/components/`: Komponen UI modular, widget kecil, dialog, dan cards milik fitur tersebut.
  - `ui/<feature>/<Feature>Screen.kt`: Composable screen utama.

### C. Shared UI Layer (`ui/common/`)
- Menyediakan komponen visual yang digunakan lintas fitur:
  - `ui/common/theme/`: Sistem tema terpusat (`Theme.kt`, `Color.kt`, `Type.kt`, `Spacing.kt`, `ExpressiveMotion.kt`).
  - `ui/common/components/`: Komponen bersama (`ArtworkCard`, `AlbumArtwork`, `PlayShuffleButtonRow`, `SRMusicGlyphIcon`).

### D. Screen Composables sebagai Pure Presenters
- Layar composable (`*Screen.kt`) hanya bertindak sebagai **Pure Presenter**:
  - Mengambil state dari ViewModel (`collectAsStateWithLifecycle`).
  - Merender UI dan mendelegasikan aksi pengguna ke atas (*upward action callbacks*).
  - **DILARANG KERAS** meletakkan business logic, kalkulasi data, format angka/waktu, atau efek samping langsung di dalam Screen Composable.

---

## 2. Standar UI/UX Jetpack Compose

### A. Aturan No Grey Box Ripple (MANDATORY)
- Setiap komponen yang dapat diklik (`.clickable`) dengan sudut membulat atau custom shape **WAJIB** menerapkan:
  1. `.clip(shape)` **sebelum** `.clickable`, atau
  2. `indication = null` dengan `MutableInteractionSource` (misal menggunakan efek tekan pegas `springPress`), atau
  3. `ripple(bounded = true)` yang dibatasi oleh bentuk shape.
- **DILARANG** mengaplikasikan `.clickable` langsung pada container yang belum di-clip, karena Jetpack Compose akan menampilkan ripple kotak abu-abu (*Grey Box Ripple*) di luar batas sudut lengkung.

### B. Pratinjau Home Terkunci (Locked Home Previews)
- **For You**: Pratinjau di layar beranda wajib berupa kolase artwork grid 2x2 terkunci (maksimal 4 lagu). Format carousel hanya diperuntukkan bagi layar anak (*child screens*).
- **Genre Today**: Pratinjau di layar beranda wajib berupa kartu bertumpuk statis (`GenreTodayCard`) dengan judul genre dan subtitle warna primer.

### C. Carousel Artwork Persegi (1:1 Aspect Ratio)
- Pada seluruh child screen (misal For You Remix Screen, Genre Today Screen), carousel album art wajib menggunakan item dengan rasio aspek persegi 1:1 (`aspectRatio(1f)`), mencegah distorsi vertikal atau peregangan gambar.

### D. Accessibility & Touch Targets
- Setiap elemen interaktif wajib memiliki touch target minimum **48dp x 48dp**.
- Setiap icon dan gambar non-dekoratif wajib menyertakan `contentDescription` yang jelas.
- Tambahkan `Modifier.testTag("snake_case_name")` pada tombol, input, dan kartu aksi utama.

---

## 3. Standar Audio & Hardware DAC Playback

1. **Bit-Perfect Mode**:
   - Seluruh pipeline bit-perfect menggunakan **C++ Direct USB Exclusive Mode** (`libusb` / UAC2 kernel bypass).
   - Audio diteruskan langsung ke hardware DAC tanpa melalui resampling atau mixer Android `AudioFlinger`.
2. **Standard Android Audio**:
   - Saat Bit-Perfect nonaktif, audio dialihkan ke `AudioTrack` atau `Oboe` dengan dukungan 32-bit float output dan equalizer software internal.

---

## 4. Aturan Kritis Performa UI & Navigasi (DILARANG MENGUBAH LOGIKA INI)

Ketiga logika berikut merupakan optimasi performa inti SRMusic yang terbukti stabil dan **TIDAK BOLEH DIUBAH** dalam refaktor atau update apa pun:

### A. Penghapusan Efek Bouncy / Overscroll Total (Android 12+)
- `LocalOverscrollFactory provides null` dan `LocalOverscrollConfiguration provides null` **WAJIB** terpasang di `Theme.kt`.
- Hal ini memastikan overscroll glow/stretch bawaan Android 12+ tidak aktif di Home, Songs, Artist, dan Albums saat ditarik ke atas maupun ke bawah.

### B. Prioritas Load Artwork (Gambar Lagu & MediaStore)
- Di `ArtworkCard.kt`, prioritas URI **WAJIB** mengutamakan `contentUri` (MediaStore.Audio.Media.EXTERNAL_CONTENT_URI) terlebih dahulu, baru kemudian fallback ke `parsedArtworkUri`:
  ```kotlin
  val primaryUri = contentUri?.takeIf { it != Uri.EMPTY } ?: (artworkUri as? Uri)?.takeIf { it != Uri.EMPTY }
  ```
- **Rasional**: Di Android 10+ (API 29+), `contentUri` memungkinkan eksekusi langsung `loadThumbnail(contentUri, Size(px, px), null)` secara native dan instan tanpa fallback decoding manual yang berat.

### C. Navigasi Bottom Bar (Anti-Stutter: Tanpa Mampir ke Songs & Pill Tetap Smooth)
- Di `AppNavigation.kt`, fungsi `selectTab(tab)` **WAJIB** menghitung selisih jarak halaman sebelum melakukan scroll:
  ```kotlin
  val pageDiff = kotlin.math.abs(targetIndex - pagerState.currentPage)
  if (animate && pageDiff <= 1) {
      pagerState.animateScrollToPage(page = targetIndex, animationSpec = tween(250, easing = FastOutSlowInEasing))
  } else {
      pagerState.scrollToPage(targetIndex)
  }
  ```
  - **Jarak bertetangga (`pageDiff <= 1`)**: Pager bergeser dengan animasi halus (`animateScrollToPage`).
  - **Melompati tab (`pageDiff > 1`, misal Home ➔ Artist)**: Pager langsung melompat ke halaman tujuan menggunakan `scrollToPage(targetIndex)` tanpa animasi fisik yang melewati dan me-render ratusan item di `SongScreen` ("tidak mampir dulu"), mencegah stutter dan frame drop.
- **Animasi Background Pill Icon Tetap Smooth (Tidak Respawn)**:
  - Di `MainBottomNavigationBar` (`MainTabNavigation.kt`), posisi pill dikendalikan oleh `pillAnimatable.animateTo(pillTargetPos, spring(dampingRatio = 1f, stiffness = 400f))`.
  - Saat `scrollToPage` terjadi seketika, `pillTargetPos` berubah seketika dan `pillAnimatable` secara otomatis menganimasikan pil latar belakang meluncur mulus (*smooth slide*) dari indeks asal ke indeks tujuan tanpa lompat atau respawn tiba-tiba.

