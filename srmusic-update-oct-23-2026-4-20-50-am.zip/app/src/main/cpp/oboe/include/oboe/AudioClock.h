#ifndef OBOE_AUDIO_CLOCK_H

#define OBOE_AUDIO_CLOCK_H

#include <sys/types.h>
#include <ctime>
#include "oboe/Definitions.h"

namespace oboe {
class AudioClock {
public:
    static int64_t getNanoseconds(clockid_t clockId = CLOCK_MONOTONIC) {
        struct timespec time;

        int result = clock_gettime(clockId, &time);

        if (result < 0) {
            return result;
        }

        return (time.tv_sec * kNanosPerSecond) + time.tv_nsec;
    }

    static int sleepUntilNanoTime(int64_t nanoTime, clockid_t clockId = CLOCK_MONOTONIC) {
        struct timespec time;

        time.tv_sec = nanoTime / kNanosPerSecond;

        time.tv_nsec = nanoTime - (time.tv_sec * kNanosPerSecond);

        return 0 - clock_nanosleep(clockId, TIMER_ABSTIME, &time, NULL);
    }

    static int sleepForNanos(int64_t nanoseconds, clockid_t clockId = CLOCK_REALTIME) {
        if (nanoseconds > 0) {
            struct timespec time;

            time.tv_sec = nanoseconds / kNanosPerSecond;

            time.tv_nsec = nanoseconds - (time.tv_sec * kNanosPerSecond);

            return 0 - clock_nanosleep(clockId, 0, &time, NULL);
        }

        return 0;
    }
};
}

#endif
