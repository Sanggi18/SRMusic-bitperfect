#ifndef OBOE_STREAM_H_

#define OBOE_STREAM_H_

#include <atomic>
#include <cstdint>
#include <ctime>
#include <mutex>
#include "oboe/Definitions.h"
#include "oboe/ResultWithValue.h"
#include "oboe/AudioStreamBuilder.h"
#include "oboe/AudioStreamBase.h"
#include "oboe/Utilities.h"

namespace oboe {
constexpr int64_t kDefaultTimeoutNanos = (2000 * kNanosPerMillisecond);

class AudioStream : public AudioStreamBase {
    friend class AudioStreamBuilder;

public:
    AudioStream() {}

    explicit AudioStream(const AudioStreamBuilder &builder);

    virtual ~AudioStream();

    virtual Result open() {
        return Result::OK;
    }

    virtual Result release() {
        return Result::ErrorUnimplemented;
    }

    virtual Result close();

    virtual Result start(int64_t timeoutNanoseconds = kDefaultTimeoutNanos);

    virtual Result pause(int64_t timeoutNanoseconds = kDefaultTimeoutNanos);

    virtual Result flush(int64_t timeoutNanoseconds = kDefaultTimeoutNanos);

    virtual Result stop(int64_t timeoutNanoseconds = kDefaultTimeoutNanos);

    virtual Result requestStart() = 0;

    virtual Result requestPause() = 0;

    virtual Result requestFlush() = 0;

    virtual Result requestStop() = 0;

    virtual StreamState getState() = 0;

    virtual Result waitForStateChange(StreamState inputState,
                                          StreamState *nextState,
                                          int64_t timeoutNanoseconds) = 0;

    virtual ResultWithValue<int32_t> setBufferSizeInFrames(int32_t  ) {
        return Result::ErrorUnimplemented;
    }

    virtual ResultWithValue<int32_t> getXRunCount() {
        return ResultWithValue<int32_t>(Result::ErrorUnimplemented);
    }

    virtual bool isXRunCountSupported() const = 0;

    int32_t getFramesPerBurst() const {
        return mFramesPerBurst;
    }

    int32_t getBytesPerFrame() const {
        return isCompressedFormat(mFormat) ? 1 : mChannelCount * getBytesPerSample(); }

    int32_t getBytesPerSample() const;

    virtual int64_t getFramesWritten();

    virtual int64_t getFramesRead();

    virtual ResultWithValue<double> calculateLatencyMillis() {
        return ResultWithValue<double>(Result::ErrorUnimplemented);
    }

    virtual Result getTimestamp(clockid_t  ,
                                int64_t*  ,
                                int64_t*  ) {
        return Result::ErrorUnimplemented;
    }

    virtual ResultWithValue<FrameTimestamp> getTimestamp(clockid_t  );

    virtual ResultWithValue<int32_t> write(const void*  ,
                             int32_t  ,
                             int64_t   ) {
        return ResultWithValue<int32_t>(Result::ErrorUnimplemented);
    }

    virtual ResultWithValue<int32_t> read(void*  ,
                            int32_t  ,
                            int64_t  ) {
        return ResultWithValue<int32_t>(Result::ErrorUnimplemented);
    }

    virtual AudioApi getAudioApi() const = 0;

    bool usesAAudio() const {
        return getAudioApi() == AudioApi::AAudio;
    }

    virtual void *getUnderlyingStream() const {
        return nullptr;
    }

    virtual void updateFramesWritten() = 0;

    virtual void updateFramesRead() = 0;

    AudioStreamDataCallback *swapDataCallback(AudioStreamDataCallback *dataCallback) {
        AudioStreamDataCallback *previousCallback = mDataCallback;

        mDataCallback = dataCallback;

        return previousCallback;
    }

    AudioStreamPartialDataCallback *swapPartialDataCallback(
            AudioStreamPartialDataCallback *partialDataCallback) {
        AudioStreamPartialDataCallback *previousPartialCallback = mPartialDataCallback;

        mPartialDataCallback = partialDataCallback;

        return previousPartialCallback;
    }

    AudioStreamErrorCallback *swapErrorCallback(AudioStreamErrorCallback *errorCallback) {
        AudioStreamErrorCallback *previousCallback = mErrorCallback;

        mErrorCallback = errorCallback;

        return previousCallback;
    }

    ResultWithValue<int32_t> getAvailableFrames();

    ResultWithValue<int32_t> waitForAvailableFrames(int32_t numFrames,
                                                    int64_t timeoutNanoseconds);

    virtual oboe::Result getLastErrorCallbackResult() const {
        return mErrorCallbackResult;
    }

    int32_t getDelayBeforeCloseMillis() const {
        return mDelayBeforeCloseMillis;
    }

    void setDelayBeforeCloseMillis(int32_t delayBeforeCloseMillis) {
        mDelayBeforeCloseMillis = delayBeforeCloseMillis;
    }

    void setPerformanceHintEnabled(bool enabled) {
        mPerformanceHintEnabled = enabled;
    }

    bool isPerformanceHintEnabled() {
        return mPerformanceHintEnabled;
    }

    virtual oboe::Result reportWorkload([[maybe_unused]] int32_t appWorkload) {
        return oboe::Result::ErrorUnimplemented;
    }

    virtual oboe::Result notifyWorkloadIncrease([[maybe_unused]] bool cpu,
                                                [[maybe_unused]] bool gpu,
                                                [[maybe_unused]] const char* debugName) {
        return oboe::Result::ErrorUnimplemented;
    }

    virtual oboe::Result notifyWorkloadReset([[maybe_unused]] bool cpu,
                                             [[maybe_unused]] bool gpu,
                                             [[maybe_unused]] const char* debugName) {
        return oboe::Result::ErrorUnimplemented;
    }

    virtual oboe::Result notifyWorkloadSpike([[maybe_unused]] bool cpu,
                                             [[maybe_unused]] bool gpu,
                                             [[maybe_unused]] const char* debugName) {
        return oboe::Result::ErrorUnimplemented;
    }

    virtual oboe::Result setOffloadDelayPadding([[maybe_unused]] int32_t delayInFrames,
                                                [[maybe_unused]] int32_t paddingInFrames) {
        return Result::ErrorUnimplemented;
    }

    virtual ResultWithValue<int32_t> getOffloadDelay() {
        return ResultWithValue<int32_t>(Result::ErrorUnimplemented);
    }

    virtual ResultWithValue<int32_t> getOffloadPadding() {
        return ResultWithValue<int32_t>(Result::ErrorUnimplemented);
    }

    virtual oboe::Result setOffloadEndOfStream() {
        return Result::ErrorUnimplemented;
    }

    virtual ResultWithValue<int64_t> flushFromFrame([[maybe_unused]] FlushFromAccuracy accuracy,
                                                    [[maybe_unused]] int64_t positionInFrames) {
        return ResultWithValue<int64_t>(Result::ErrorUnimplemented);
    }

    virtual oboe::Result setPlaybackParameters(
            [[maybe_unused]] const PlaybackParameters& parameters) {
        return Result::ErrorUnimplemented;
    }

    virtual ResultWithValue<PlaybackParameters> getPlaybackParameters() {
        return ResultWithValue<PlaybackParameters>(Result::ErrorUnimplemented);
    }

    std::shared_ptr<oboe::AudioStream> lockWeakThis() {
        return mWeakThis.lock();
    }

    AudioStream *getParentStream() const {
        return mParentStream;
    }

    bool hasParentStream() const {
        return mHasParentStream;
    }

    void setParentStream(AudioStream *parentStream) {
        mParentStream = parentStream;

        mHasParentStream = parentStream != nullptr;
    }

protected:
    bool wasErrorCallbackCalled() {
        return mErrorCallbackCalled.exchange(true);
    }

    virtual Result waitForStateTransition(StreamState startingState,
                                          StreamState endingState,
                                          int64_t timeoutNanoseconds);

    virtual DataCallbackResult onDefaultCallback(void*  , int  ) {
        return DataCallbackResult::Stop;
    }

    virtual DataCallbackResult fireDataCallback(void *audioData, int numFrames);

    virtual int32_t firePartialDataCallback(void* audioData, int numFrames);

    bool isDataCallbackEnabled() {
        return mDataCallbackEnabled;
    }

    void setDataCallbackEnabled(bool enabled) {
        mDataCallbackEnabled = enabled;
    }

    void calculateDefaultDelayBeforeCloseMillis();

    void sleepBeforeClose() {
        if (mDelayBeforeCloseMillis > 0) {
            usleep(mDelayBeforeCloseMillis * 1000);
        }
    }

    virtual void beginPerformanceHintInCallback() {}

    virtual void endPerformanceHintInCallback(int32_t  ) {}

    virtual void closePerformanceHint() {}

    void setWeakThis(std::shared_ptr<oboe::AudioStream> &sharedStream) {
        mWeakThis = sharedStream;
    }

    std::weak_ptr<AudioStream> mWeakThis;

    AudioStream *mParentStream{};

    bool mHasParentStream{};

    std::atomic<int64_t> mFramesWritten{};

    std::atomic<int64_t> mFramesRead{};

    std::mutex           mLock;

    oboe::Result         mErrorCallbackResult = oboe::Result::OK;

    int32_t              mFramesPerBurst = kUnspecified;

    static constexpr int kMinDelayBeforeCloseMillis = 10;

    static constexpr int kMaxDelayBeforeCloseMillis = 100;

    int32_t              mDelayBeforeCloseMillis = kMinDelayBeforeCloseMillis;

private:
    void                 checkScheduler();

    int                  mPreviousScheduler = -1;

    std::atomic<bool>    mDataCallbackEnabled{false};

    std::atomic<bool>    mErrorCallbackCalled{false};

    std::atomic<bool>    mPerformanceHintEnabled{false};
};

    struct StreamDeleterFunctor {
        void operator()(AudioStream  *audioStream) {
            if (audioStream) {
                audioStream->close();
            }

            delete audioStream;
        }
    };
}

#endif
