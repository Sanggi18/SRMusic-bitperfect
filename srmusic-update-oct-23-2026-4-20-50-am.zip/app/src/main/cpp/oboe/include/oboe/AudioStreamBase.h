#ifndef OBOE_STREAM_BASE_H_

#define OBOE_STREAM_BASE_H_

#include <memory>
#include <string>
#include <vector>
#include "oboe/AudioStreamCallback.h"
#include "oboe/Definitions.h"

namespace oboe {
class AudioStreamBase {
public:
    AudioStreamBase() {}

    virtual ~AudioStreamBase() = default;

    AudioStreamBase(const AudioStreamBase&) = default;

    AudioStreamBase& operator=(const AudioStreamBase&) = default;

    int32_t getChannelCount() const { return mChannelCount; }

    Direction getDirection() const { return mDirection; }

    int32_t getSampleRate() const { return mSampleRate; }

    int32_t getFramesPerCallback() const { return getFramesPerDataCallback(); }

    int32_t getFramesPerDataCallback() const { return mFramesPerCallback; }

    AudioFormat getFormat() const { return mFormat; }

    virtual int32_t getBufferSizeInFrames() { return mBufferSizeInFrames; }

    virtual int32_t getBufferCapacityInFrames() const { return mBufferCapacityInFrames; }

    SharingMode getSharingMode() const { return mSharingMode; }

    PerformanceMode getPerformanceMode() const { return mPerformanceMode; }

    virtual int32_t getDeviceId() const {
        return mDeviceIds.empty() ? kUnspecified :  mDeviceIds[0];
    }

    virtual std::vector<int32_t> getDeviceIds() const {
        return mDeviceIds;
    }

    AudioStreamDataCallback *getDataCallback() const {
        return mDataCallback;
    }

    AudioStreamPartialDataCallback* getPartialDataCallback() const {
        return mPartialDataCallback;
    }

    AudioStreamErrorCallback *getErrorCallback() const {
        return mErrorCallback;
    }

    std::shared_ptr<AudioStreamPresentationCallback> getPresentationCallback() const {
        return mSharedPresentationCallback;
    }

    std::shared_ptr<AudioStreamRoutingCallback> getRoutingCallback() const {
        return mSharedRoutingCallback;
    }

    bool isDataCallbackSpecified() const {
        return mDataCallback != nullptr;
    }

    bool isPartialDataCallbackSpecified() const {
        return mPartialDataCallback != nullptr;
    }

    bool anyDataCallbackSpecified() const {
        return isDataCallbackSpecified() || isPartialDataCallbackSpecified();
    }

    bool isErrorCallbackSpecified() const {
        return mErrorCallback != nullptr;
    }

    bool isPresentationCallbackSpecified() const {
        return mSharedPresentationCallback != nullptr;
    }

    Usage getUsage() const { return mUsage; }

    ContentType getContentType() const { return mContentType; }

    InputPreset getInputPreset() const { return mInputPreset; }

    SessionId getSessionId() const { return mSessionId; }

    bool isContentSpatialized() const { return mIsContentSpatialized; }

    SpatializationBehavior getSpatializationBehavior() const { return mSpatializationBehavior; }

    AllowedCapturePolicy getAllowedCapturePolicy() const { return mAllowedCapturePolicy; }

    PrivacySensitiveMode getPrivacySensitiveMode() const { return mPrivacySensitiveMode; }

    std::string getPackageName() const { return mPackageName; }

    std::string getAttributionTag() const { return mAttributionTag; }

    bool isChannelConversionAllowed() const {
        return mChannelConversionAllowed;
    }

    bool  isFormatConversionAllowed() const {
        return mFormatConversionAllowed;
    }

    SampleRateConversionQuality getSampleRateConversionQuality() const {
        return mSampleRateConversionQuality;
    }

    ChannelMask getChannelMask() const {
        return mChannelMask;
    }

    int32_t getHardwareChannelCount() const { return mHardwareChannelCount; }

    int32_t getHardwareSampleRate() const { return mHardwareSampleRate; }

    AudioFormat getHardwareFormat() const { return mHardwareFormat; }

protected:
    AudioStreamDataCallback        *mDataCallback = nullptr;

    std::shared_ptr<AudioStreamDataCallback> mSharedDataCallback;

    AudioStreamPartialDataCallback  *mPartialDataCallback = nullptr;

    std::shared_ptr<AudioStreamPartialDataCallback> mSharedPartialDataCallback;

    AudioStreamErrorCallback       *mErrorCallback = nullptr;

    std::shared_ptr<AudioStreamErrorCallback> mSharedErrorCallback;

    std::shared_ptr<AudioStreamPresentationCallback> mSharedPresentationCallback;

    std::shared_ptr<AudioStreamRoutingCallback> mSharedRoutingCallback;

    int32_t                         mFramesPerCallback = kUnspecified;

    int32_t                         mChannelCount = kUnspecified;

    int32_t                         mSampleRate = kUnspecified;

    int32_t                         mBufferCapacityInFrames = kUnspecified;

    int32_t                         mBufferSizeInFrames = kUnspecified;

    ChannelMask                     mChannelMask = ChannelMask::Unspecified;

    SharingMode                     mSharingMode = SharingMode::Shared;

    AudioFormat                     mFormat = AudioFormat::Unspecified;

    Direction                       mDirection = Direction::Output;

    PerformanceMode                 mPerformanceMode = PerformanceMode::None;

    Usage                           mUsage = Usage::Media;

    ContentType                     mContentType = ContentType::Music;

    InputPreset                     mInputPreset = InputPreset::VoiceRecognition;

    SessionId                       mSessionId = SessionId::None;

    AllowedCapturePolicy            mAllowedCapturePolicy = AllowedCapturePolicy::Unspecified;

    PrivacySensitiveMode            mPrivacySensitiveMode = PrivacySensitiveMode::Unspecified;

    std::string                     mPackageName;

    std::string                     mAttributionTag;

    bool                            mIsContentSpatialized = false;

    SpatializationBehavior          mSpatializationBehavior = SpatializationBehavior::Unspecified;

    int32_t                         mHardwareChannelCount = kUnspecified;

    int32_t                         mHardwareSampleRate = kUnspecified;

    AudioFormat                     mHardwareFormat = AudioFormat::Unspecified;

    bool                            mChannelConversionAllowed = false;

    bool                            mFormatConversionAllowed = false;

    SampleRateConversionQuality     mSampleRateConversionQuality = SampleRateConversionQuality::Medium;

    std::vector<int32_t>            mDeviceIds;

    virtual Result isValidConfig() {
        switch (mFormat) {
            case AudioFormat::Unspecified:
            case AudioFormat::I16:
            case AudioFormat::Float:
            case AudioFormat::I24:
            case AudioFormat::I32:
            case AudioFormat::IEC61937:
            case AudioFormat::MP3:
            case AudioFormat::AAC_LC:
            case AudioFormat::AAC_HE_V1:
            case AudioFormat::AAC_HE_V2:
            case AudioFormat::AAC_ELD:
            case AudioFormat::AAC_XHE:
            case AudioFormat::OPUS:
                break;

            default:
                return Result::ErrorInvalidFormat;
        }

        switch (mSampleRateConversionQuality) {
            case SampleRateConversionQuality::None:
            case SampleRateConversionQuality::Fastest:
            case SampleRateConversionQuality::Low:
            case SampleRateConversionQuality::Medium:
            case SampleRateConversionQuality::High:
            case SampleRateConversionQuality::Best:
                return Result::OK;

            default:
                return Result::ErrorIllegalArgument;
        }
    }
};
}

#endif
