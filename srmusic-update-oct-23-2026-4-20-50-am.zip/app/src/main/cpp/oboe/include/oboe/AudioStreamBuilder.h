#ifndef OBOE_STREAM_BUILDER_H_

#define OBOE_STREAM_BUILDER_H_

#include "oboe/Definitions.h"
#include "oboe/AudioStreamBase.h"
#include "oboe/Utilities.h"
#include "ResultWithValue.h"

namespace oboe {
    struct StreamDeleterFunctor;

    using ManagedStream = std::unique_ptr<AudioStream, StreamDeleterFunctor>;

class AudioStreamBuilder : public AudioStreamBase {
public:
    AudioStreamBuilder() : AudioStreamBase() {}

    AudioStreamBuilder(const AudioStreamBase &audioStreamBase): AudioStreamBase(audioStreamBase) {}

    AudioStreamBuilder *setChannelCount(int channelCount) {
        mChannelCount = channelCount;

        mChannelMask = ChannelMask::Unspecified;

        return this;
    }

     AudioStreamBuilder *setChannelMask(ChannelMask channelMask) {
         mChannelMask = channelMask;

         mChannelCount = getChannelCountFromChannelMask(channelMask);

         return this;
     }

    AudioStreamBuilder *setDirection(Direction direction) {
        mDirection = direction;

        return this;
    }

    AudioStreamBuilder *setSampleRate(int32_t sampleRate) {
        mSampleRate = sampleRate;

        return this;
    }

    AudioStreamBuilder *setFramesPerCallback(int framesPerCallback) {
        return setFramesPerDataCallback(framesPerCallback);
    }

    AudioStreamBuilder *setFramesPerDataCallback(int framesPerCallback) {
        mFramesPerCallback = framesPerCallback;

        return this;
    }

    AudioStreamBuilder *setFormat(AudioFormat format) {
        mFormat = format;

        return this;
    }

    AudioStreamBuilder *setBufferCapacityInFrames(int32_t bufferCapacityInFrames) {
        mBufferCapacityInFrames = bufferCapacityInFrames;

        return this;
    }

    AudioApi getAudioApi() const { return mAudioApi; }

    AudioStreamBuilder *setAudioApi(AudioApi audioApi) {
        mAudioApi = audioApi;

        return this;
    }

    static bool isAAudioSupported();

    static bool isAAudioRecommended();

    AudioStreamBuilder *setSharingMode(SharingMode sharingMode) {
        mSharingMode = sharingMode;

        return this;
    }

    AudioStreamBuilder *setPerformanceMode(PerformanceMode performanceMode) {
        mPerformanceMode = performanceMode;

        return this;
    }

    AudioStreamBuilder *setUsage(Usage usage) {
        mUsage = usage;

        return this;
    }

    AudioStreamBuilder *setContentType(ContentType contentType) {
        mContentType = contentType;

        return this;
    }

    AudioStreamBuilder *setInputPreset(InputPreset inputPreset) {
        mInputPreset = inputPreset;

        return this;
    }

    AudioStreamBuilder *setSessionId(SessionId sessionId) {
        mSessionId = sessionId;

        return this;
    }

    AudioStreamBuilder *setDeviceId(int32_t deviceId) {
        mDeviceIds.clear();

        if (deviceId != kUnspecified) {
            mDeviceIds.push_back(deviceId);
        }

        return this;
    }

    AudioStreamBuilder *setAllowedCapturePolicy(AllowedCapturePolicy allowedCapturePolicy) {
        mAllowedCapturePolicy = allowedCapturePolicy;

        return this;
    }

    AudioStreamBuilder *setPrivacySensitiveMode(PrivacySensitiveMode privacySensitiveMode) {
        mPrivacySensitiveMode = privacySensitiveMode;

        return this;
    }

    AudioStreamBuilder *setIsContentSpatialized(bool isContentSpatialized) {
        mIsContentSpatialized = isContentSpatialized;

        return this;
    }

    AudioStreamBuilder *setSpatializationBehavior(SpatializationBehavior spatializationBehavior) {
        mSpatializationBehavior = spatializationBehavior;

        return this;
    }

    AudioStreamBuilder *setDataCallback(
            std::shared_ptr<AudioStreamDataCallback> sharedDataCallback) {
        mDataCallback = sharedDataCallback.get();

        mSharedDataCallback = sharedDataCallback;

        mSharedPartialDataCallback.reset();

        mPartialDataCallback = nullptr;

        return this;
    }

    AudioStreamBuilder *setDataCallback(AudioStreamDataCallback *dataCallback) {
        mDataCallback = dataCallback;

        mSharedDataCallback = nullptr;

        mPartialDataCallback = nullptr;

        mSharedPartialDataCallback.reset();

        return this;
    }

    AudioStreamBuilder *setPartialDataCallback(
            const std::shared_ptr<AudioStreamPartialDataCallback>& partialDataCallback) {
        mSharedDataCallback.reset();

        mDataCallback = nullptr;

        mSharedPartialDataCallback = partialDataCallback;

        mPartialDataCallback = mSharedPartialDataCallback.get();

        return this;
    }

    AudioStreamBuilder *setErrorCallback(std::shared_ptr<AudioStreamErrorCallback> sharedErrorCallback) {
        mErrorCallback = sharedErrorCallback.get();

        mSharedErrorCallback = sharedErrorCallback;

        return this;
    }

    AudioStreamBuilder *setErrorCallback(AudioStreamErrorCallback *errorCallback) {
        mErrorCallback = errorCallback;

        mSharedErrorCallback = nullptr;

        return this;
    }

    AudioStreamBuilder *setPresentationCallback(
            std::shared_ptr<AudioStreamPresentationCallback> sharedPresentationCallback) {
        mSharedPresentationCallback = sharedPresentationCallback;

        return this;
    }

    AudioStreamBuilder *setRoutingCallback(
            std::shared_ptr<AudioStreamRoutingCallback> sharedRoutingCallback) {
        mSharedRoutingCallback = sharedRoutingCallback;

        return this;
    }

    AudioStreamBuilder *setCallback(AudioStreamCallback *streamCallback) {
        mDataCallback = streamCallback;

        mErrorCallback = streamCallback;

        mSharedPartialDataCallback.reset();

        mPartialDataCallback = nullptr;

        return this;
    }

    AudioStreamBuilder *setChannelConversionAllowed(bool allowed) {
        mChannelConversionAllowed = allowed;

        return this;
    }

    AudioStreamBuilder *setFormatConversionAllowed(bool allowed) {
        mFormatConversionAllowed = allowed;

        return this;
    }

    AudioStreamBuilder *setSampleRateConversionQuality(SampleRateConversionQuality quality) {
        mSampleRateConversionQuality = quality;

        return this;
    }

    AudioStreamBuilder *setPackageName(std::string packageName) {
        mPackageName = packageName;

        return this;
    }

    AudioStreamBuilder *setAttributionTag(std::string attributionTag) {
        mAttributionTag = attributionTag;

        return this;
    }

    bool willUseAAudio() const {
        return (mAudioApi == AudioApi::AAudio && isAAudioSupported())
                || (mAudioApi == AudioApi::Unspecified && isAAudioRecommended());
    }

    Result openStream(AudioStream **stream);

    Result openStream(std::shared_ptr<oboe::AudioStream> &stream);

    Result openManagedStream(ManagedStream &stream);

private:
    Result openStreamInternal(AudioStream **streamPP);

    bool isCompatible(AudioStreamBase &other);

    oboe::AudioStream *build();

    AudioApi       mAudioApi = AudioApi::Unspecified;
};
}

#endif
