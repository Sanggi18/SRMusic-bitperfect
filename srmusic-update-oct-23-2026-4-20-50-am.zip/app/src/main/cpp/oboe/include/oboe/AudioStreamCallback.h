#ifndef OBOE_STREAM_CALLBACK_H

#define OBOE_STREAM_CALLBACK_H

#include "oboe/Definitions.h"

namespace oboe {
class AudioStream;

class AudioStreamDataCallback {
public:
    virtual ~AudioStreamDataCallback() = default;

    virtual DataCallbackResult onAudioReady(
            AudioStream *audioStream,
            void *audioData,
            int32_t numFrames) = 0;
};

class AudioStreamErrorCallback {
public:
    virtual ~AudioStreamErrorCallback() = default;

    virtual bool onError(AudioStream*  , Result  ) {
        return false;
    }

    virtual void onErrorBeforeClose(AudioStream*  , Result  ) {}

    virtual void onErrorAfterClose(AudioStream*  , Result  ) {}
};

class AudioStreamPresentationCallback {
public:
    virtual ~AudioStreamPresentationCallback() = default;

    virtual void onPresentationEnded(AudioStream*  ) {}
};

class AudioStreamRoutingCallback {
public:
    virtual void onRoutingChanged(AudioStream*  ,
                                  const int32_t*  ,
                                  int32_t  ) {}
};

class AudioStreamPartialDataCallback {
public:
    virtual ~AudioStreamPartialDataCallback() = default;

    virtual int32_t onPartialAudioReady(
            AudioStream *audioStream,
            void *audioData,
            int32_t numFrames) = 0;
};

class AudioStreamCallback : public AudioStreamDataCallback,
                            public AudioStreamErrorCallback {
public:
    virtual ~AudioStreamCallback() = default;
};
}

#endif
