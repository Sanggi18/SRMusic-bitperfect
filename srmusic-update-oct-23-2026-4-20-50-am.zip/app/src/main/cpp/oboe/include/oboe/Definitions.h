#ifndef OBOE_DEFINITIONS_H

#define OBOE_DEFINITIONS_H

#include <cstdint>
#include <type_traits>

namespace oboe {
    constexpr int32_t kUnspecified = 0;

    constexpr int64_t kNanosPerMicrosecond =    1000;

    constexpr int64_t kNanosPerMillisecond =    kNanosPerMicrosecond * 1000;

    constexpr int64_t kMillisPerSecond =        1000;

    constexpr int64_t kNanosPerSecond =         kNanosPerMillisecond * kMillisPerSecond;

    enum class StreamState : int32_t {
        Uninitialized = 0,
        Unknown = 1,
        Open = 2,
        Starting = 3,
        Started = 4,
        Pausing = 5,
        Paused = 6,
        Flushing = 7,
        Flushed = 8,
        Stopping = 9,
        Stopped = 10,
        Closing = 11,
        Closed = 12,
        Disconnected = 13,
    };

    enum class Direction : int32_t {
        Output = 0,
        Input = 1,
    };

    enum class AudioFormat : int32_t {
        Invalid = -1,
        Unspecified = 0,
        I16 = 1,
        Float = 2,
        I24 = 3,
        I32 = 4,
        IEC61937 = 5,
        MP3 = 6,
        AAC_LC,
        AAC_HE_V1,
        AAC_HE_V2,
        AAC_ELD,
        AAC_XHE,
        OPUS,
    };

    enum class DataCallbackResult : int32_t {
        Continue = 0,
        Stop = 1,
    };

    enum class Result : int32_t {
        OK = 0,
        ErrorBase = -900,
        ErrorDisconnected = -899,
        ErrorIllegalArgument = -898,
        ErrorInternal = -896,
        ErrorInvalidState = -895,
        ErrorInvalidHandle = -892,
        ErrorUnimplemented = -890,
        ErrorUnavailable = -889,
        ErrorNoFreeHandles = -888,
        ErrorNoMemory = -887,
        ErrorNull = -886,
        ErrorTimeout = -885,
        ErrorWouldBlock = -884,
        ErrorInvalidFormat = -883,
        ErrorOutOfRange = -882,
        ErrorNoService = -881,
        ErrorInvalidRate = -880,
        Reserved1,
        Reserved2,
        Reserved3,
        Reserved4,
        Reserved5,
        Reserved6,
        Reserved7,
        Reserved8,
        Reserved9,
        Reserved10,
        ErrorClosed = -869,
    };

    enum class SharingMode : int32_t {
        Exclusive = 0,
        Shared = 1,
    };

    enum class PerformanceMode : int32_t {
        None = 10,
        PowerSaving = 11,
        LowLatency = 12,
        PowerSavingOffloaded = 13,
    };

    enum class AudioApi : int32_t {
        Unspecified = kUnspecified,
        OpenSLES,
        AAudio
    };

    enum class SampleRateConversionQuality : int32_t {
        None,
        Fastest,
        Low,
        Medium,
        High,
        Best,
    };

    enum class Usage : int32_t {
        Media =  1,
        VoiceCommunication = 2,
        VoiceCommunicationSignalling = 3,
        Alarm = 4,
        Notification = 5,
        NotificationRingtone = 6,
        NotificationEvent = 10,
        AssistanceAccessibility = 11,
        AssistanceNavigationGuidance = 12,
        AssistanceSonification = 13,
        Game = 14,
        Assistant = 16,
    };

    enum ContentType : int32_t {
        Speech = 1,
        Music = 2,
        Movie = 3,
        Sonification = 4,
    };

    enum InputPreset : int32_t {
        Generic = 1,
        Camcorder = 5,
        VoiceRecognition = 6,
        VoiceCommunication = 7,
        Unprocessed = 9,
         VoicePerformance = 10,
    };

    enum SessionId {
         None = -1,
         Allocate = 0,
    };

    enum ChannelCount : int32_t {
      Unspecified = kUnspecified,
      Mono = 1,
      Stereo = 2,
    };

    enum class ChannelMask : uint32_t {
        Unspecified = kUnspecified,
        FrontLeft = 1 << 0,
        FrontRight = 1 << 1,
        FrontCenter = 1 << 2,
        LowFrequency = 1 << 3,
        BackLeft = 1 << 4,
        BackRight = 1 << 5,
        FrontLeftOfCenter = 1 << 6,
        FrontRightOfCenter = 1 << 7,
        BackCenter = 1 << 8,
        SideLeft = 1 << 9,
        SideRight = 1 << 10,
        TopCenter = 1 << 11,
        TopFrontLeft = 1 << 12,
        TopFrontCenter = 1 << 13,
        TopFrontRight = 1 << 14,
        TopBackLeft = 1 << 15,
        TopBackCenter = 1 << 16,
        TopBackRight = 1 << 17,
        TopSideLeft = 1 << 18,
        TopSideRight = 1 << 19,
        BottomFrontLeft = 1 << 20,
        BottomFrontCenter = 1 << 21,
        BottomFrontRight = 1 << 22,
        LowFrequency2 = 1 << 23,
        FrontWideLeft = 1 << 24,
        FrontWideRight = 1 << 25,
        Mono = FrontLeft,
        Stereo = FrontLeft |

                 FrontRight,
        CM2Point1 = FrontLeft |

                    FrontRight |

                    LowFrequency,
        Tri = FrontLeft |

              FrontRight |

              FrontCenter,
        TriBack = FrontLeft |

                  FrontRight |

                  BackCenter,
        CM3Point1 = FrontLeft |

                    FrontRight |

                    FrontCenter |

                    LowFrequency,
        CM2Point0Point2 = FrontLeft |

                          FrontRight |

                          TopSideLeft |

                          TopSideRight,
        CM2Point1Point2 = CM2Point0Point2 |

                          LowFrequency,
        CM3Point0Point2 = FrontLeft |

                          FrontRight |

                          FrontCenter |

                          TopSideLeft |

                          TopSideRight,
        CM3Point1Point2 = CM3Point0Point2 |

                          LowFrequency,
        Quad = FrontLeft |

               FrontRight |

               BackLeft |

               BackRight,
        QuadSide = FrontLeft |

                   FrontRight |

                   SideLeft |

                   SideRight,
        Surround = FrontLeft |

                   FrontRight |

                   FrontCenter |

                   BackCenter,
        Penta = Quad |

                FrontCenter,
        CM5Point1 = FrontLeft |

                    FrontRight |

                    FrontCenter |

                    LowFrequency |

                    BackLeft |

                    BackRight,
        CM5Point1Side = FrontLeft |

                        FrontRight |

                        FrontCenter |

                        LowFrequency |

                        SideLeft |

                        SideRight,
        CM6Point1 = FrontLeft |

                    FrontRight |

                    FrontCenter |

                    LowFrequency |

                    BackLeft |

                    BackRight |

                    BackCenter,
        CM7Point1 = CM5Point1 |

                    SideLeft |

                    SideRight,
        CM5Point1Point2 = CM5Point1 |

                          TopSideLeft |

                          TopSideRight,
        CM5Point1Point4 = CM5Point1 |

                          TopFrontLeft |

                          TopFrontRight |

                          TopBackLeft |

                          TopBackRight,
        CM7Point1Point2 = CM7Point1 |

                          TopSideLeft |

                          TopSideRight,
        CM7Point1Point4 = CM7Point1 |

                          TopFrontLeft |

                          TopFrontRight |

                          TopBackLeft |

                          TopBackRight,
        CM9Point1Point4 = CM7Point1Point4 |

                          FrontWideLeft |

                          FrontWideRight,
        CM9Point1Point6 = CM9Point1Point4 |

                          TopSideLeft |

                          TopSideRight,
        FrontBack = FrontCenter |

                    BackCenter,
    };

    enum class SpatializationBehavior : int32_t {
        Unspecified = kUnspecified,
        Auto = 1,
        Never = 2,
    };

    enum class PrivacySensitiveMode : int32_t {
        Unspecified = kUnspecified,
        Disabled = 1,
        Enabled = 2,
    };

    enum class AllowedCapturePolicy : int32_t {
        Unspecified = kUnspecified,
        All = 1,
        System = 2,
        None = 3,
    };

    enum class DeviceType : int32_t {
        BuiltinEarpiece = 1,
        BuiltinSpeaker = 2,
        WiredHeadset = 3,
        WiredHeadphones = 4,
        LineAnalog = 5,
        LineDigital = 6,
        BluetoothSco = 7,
        BluetoothA2dp = 8,
        Hdmi = 9,
        HdmiArc = 10,
        UsbDevice = 11,
        UsbAccessory = 12,
        Dock = 13,
        FM = 14,
        BuiltinMic = 15,
        FMTuner = 16,
        TVTuner = 17,
        Telephony = 18,
        AuxLine = 19,
        IP = 20,
        Bus = 21,
        UsbHeadset = 22,
        HearingAid = 23,
        BuiltinSpeakerSafe = 24,
        RemoteSubmix = 25,
        BleHeadset = 26,
        BleSpeaker = 27,
        HdmiEarc = 29,
        BleBroadcast = 30,
        DockAnalog = 31
    };

    enum class MMapPolicy : int32_t {
        Unspecified = kUnspecified,
        Never = 1,
        Auto,
        Always
    };

    enum class FlushFromAccuracy : int32_t {
        Undefined = 0,
        Accurate = 1,
    };

    enum class FallbackMode : int32_t {
        Default = 0,
        Mute = 1,
        Fail = 2,
    };

    enum class StretchMode : int32_t {
        Default = 0,
        Voice = 1,
    };

    struct PlaybackParameters {
        FallbackMode fallbackMode;

        StretchMode stretchMode;

        float pitch;

        float speed;
    };

    class DefaultStreamValues {
    public:
        static int32_t SampleRate;

        static int32_t FramesPerBurst;

        static int32_t ChannelCount;
    };

    struct FrameTimestamp {
        int64_t position;

        int64_t timestamp;
    };

    class OboeGlobals {
    public:
        static bool areWorkaroundsEnabled() {
            return mWorkaroundsEnabled;
        }

        static void setWorkaroundsEnabled(bool enabled) {
            mWorkaroundsEnabled = enabled;
        }

    private:
        static bool mWorkaroundsEnabled;
    };
}

#endif
