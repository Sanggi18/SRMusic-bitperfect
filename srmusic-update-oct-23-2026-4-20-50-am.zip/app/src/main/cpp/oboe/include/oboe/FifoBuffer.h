#ifndef OBOE_FIFOPROCESSOR_H

#define OBOE_FIFOPROCESSOR_H

#include <memory>
#include <stdint.h>
#include "oboe/Definitions.h"
#include "oboe/FifoControllerBase.h"

namespace oboe {
class FifoBuffer {
public:
    FifoBuffer(uint32_t bytesPerFrame, uint32_t capacityInFrames);

    FifoBuffer(uint32_t   bytesPerFrame,
               uint32_t   capacityInFrames,
               std::atomic<uint64_t>   *readCounterAddress,
               std::atomic<uint64_t>   *writeCounterAddress,
               uint8_t   *dataStorageAddress);

    ~FifoBuffer();

    int32_t convertFramesToBytes(int32_t frames);

    int32_t read(void *destination, int32_t framesToRead);

    int32_t write(const void *source, int32_t framesToWrite);

    uint32_t getBufferCapacityInFrames() const;

    int32_t readNow(void *destination, int32_t numFrames);

    uint32_t getFullFramesAvailable() {
        return mFifo->getFullFramesAvailable();
    }

    uint32_t getBytesPerFrame() const {
        return mBytesPerFrame;
    }

    uint64_t getReadCounter() const {
        return mFifo->getReadCounter();
    }

    void setReadCounter(uint64_t n) {
        mFifo->setReadCounter(n);
    }

    uint64_t getWriteCounter() {
        return mFifo->getWriteCounter();
    }

    void setWriteCounter(uint64_t n) {
        mFifo->setWriteCounter(n);
    }

private:
    uint32_t mBytesPerFrame;

    uint8_t* mStorage;

    bool     mStorageOwned;

    std::unique_ptr<FifoControllerBase> mFifo;

    uint64_t mFramesReadCount;

    uint64_t mFramesUnderrunCount;
};
}

#endif
