#ifndef NATIVEOBOE_FIFOCONTROLLERBASE_H

#define NATIVEOBOE_FIFOCONTROLLERBASE_H

#include <stdint.h>

namespace oboe {
class FifoControllerBase {
public:
    FifoControllerBase(uint32_t totalFrames);

    virtual ~FifoControllerBase() = default;

    uint32_t getFullFramesAvailable() const;

    uint32_t getReadIndex() const;

    void advanceReadIndex(uint32_t numFrames);

    uint32_t getEmptyFramesAvailable() const;

    uint32_t getWriteIndex() const;

    void advanceWriteIndex(uint32_t numFrames);

    uint32_t getFrameCapacity() const { return mTotalFrames; }

    virtual uint64_t getReadCounter() const = 0;

    virtual void setReadCounter(uint64_t n) = 0;

    virtual void incrementReadCounter(uint64_t n) = 0;

    virtual uint64_t getWriteCounter() const = 0;

    virtual void setWriteCounter(uint64_t n) = 0;

    virtual void incrementWriteCounter(uint64_t n) = 0;

private:
    uint32_t mTotalFrames;
};
}

#endif
