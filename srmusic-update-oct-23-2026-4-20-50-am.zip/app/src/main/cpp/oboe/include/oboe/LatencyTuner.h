#ifndef OBOE_LATENCY_TUNER_

#define OBOE_LATENCY_TUNER_

#include <atomic>
#include <cstdint>
#include "oboe/Definitions.h"
#include "oboe/AudioStream.h"

namespace oboe {
class LatencyTuner {
public:
    explicit LatencyTuner(AudioStream &stream);

    explicit LatencyTuner(AudioStream &stream, int32_t maximumBufferSize);

    Result tune();

    void requestReset();

    bool isAtMaximumBufferSize();

    void setMinimumBufferSize(int32_t bufferSize) {
        mMinimumBufferSize = bufferSize;
    }

    int32_t getMinimumBufferSize() const {
        return mMinimumBufferSize;
    }

    void setBufferSizeIncrement(int32_t sizeIncrement) {
        mBufferSizeIncrement = sizeIncrement;
    }

    int32_t getBufferSizeIncrement() const {
        return mBufferSizeIncrement;
    }

private:
    void reset();

    enum class State {
        Idle,
        Active,
        AtMax,
        Unsupported
    } ;

    static constexpr int32_t kIdleCount = 8;

    static constexpr int32_t kDefaultNumBursts = 2;

    AudioStream           &mStream;

    State                 mState = State::Idle;

    int32_t               mMaxBufferSize = 0;

    int32_t               mPreviousXRuns = 0;

    int32_t               mIdleCountDown = 0;

    int32_t               mMinimumBufferSize;

    int32_t               mBufferSizeIncrement;

    std::atomic<int32_t>  mLatencyTriggerRequests{0};

    std::atomic<int32_t>  mLatencyTriggerResponses{0};
};
}

#endif
