#ifndef OBOE_EXTENSIONS_

#define OBOE_EXTENSIONS_

#include <stdint.h>
#include "oboe/Definitions.h"
#include "oboe/AudioStream.h"

namespace oboe {
class OboeExtensions {
public:
    static bool isMMapSupported();

    static bool isMMapEnabled();

    static int32_t setMMapEnabled(bool enabled);

    static bool isMMapUsed(oboe::AudioStream *oboeStream);

    static bool isPartialDataCallbackSupported();
};
}

#endif
