#ifndef OBOE_RESULT_WITH_VALUE_H

#define OBOE_RESULT_WITH_VALUE_H

#include "oboe/Definitions.h"
#include <iostream>
#include <sstream>

namespace oboe {
template <typename T>

class ResultWithValue {
public:
    ResultWithValue(oboe::Result error)
            : mValue{}
            , mError(error) {}

    explicit ResultWithValue(T value)
            : mValue(value)
            , mError(oboe::Result::OK) {}

    ResultWithValue(T value, oboe::Result error)
            : mValue(value)
            , mError(error) {}

    oboe::Result error() const {
        return mError;
    }

    T value() const {
        return mValue;
    }

    explicit operator bool() const { return mError == oboe::Result::OK; }

    bool operator !() const { return mError != oboe::Result::OK; }

    operator Result() const {
        return mError;
    }

    static ResultWithValue<T> createBasedOnSign(T numericResult){
        static_assert(std::is_arithmetic<T>::value,
                      "createBasedOnSign can only be called for numeric types (int or float)");

        if (numericResult >= 0){
            return ResultWithValue<T>(numericResult);
        } else {
            return ResultWithValue<T>(static_cast<Result>(numericResult));
        }
    }

private:
    T             mValue;

    oboe::Result  mError;
};

template <typename T>

std::ostream& operator<<(std::ostream &strm, const ResultWithValue<T> &result) {
    if (!result) {
        strm << convertToText(result.error());
    } else {
        strm << result.value();
    }

   return strm;
}
}

#endif
