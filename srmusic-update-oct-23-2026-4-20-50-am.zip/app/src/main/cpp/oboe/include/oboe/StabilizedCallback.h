#ifndef OBOE_STABILIZEDCALLBACK_H

#define OBOE_STABILIZEDCALLBACK_H

#include <cstdint>
#include "oboe/AudioStream.h"

namespace oboe {
class StabilizedCallback : public AudioStreamCallback {
public:
    explicit StabilizedCallback(AudioStreamCallback *callback);

    DataCallbackResult

    onAudioReady(AudioStream *oboeStream, void *audioData, int32_t numFrames) override;

    void onErrorBeforeClose(AudioStream *oboeStream, Result error) override {
        return mCallback->onErrorBeforeClose(oboeStream, error);
    }

    void onErrorAfterClose(AudioStream *oboeStream, Result error) override {
        mFrameCount = 0;

        mEpochTimeNanos = 0;

        mOpsPerNano = 1;

        return mCallback->onErrorAfterClose(oboeStream, error);
    }

private:
    AudioStreamCallback *mCallback = nullptr;

    int64_t mFrameCount = 0;

    int64_t mEpochTimeNanos = 0;

    double  mOpsPerNano = 1;

    void generateLoad(int64_t durationNanos);
};

#if defined(__i386__) || defined(__x86_64__)

#define cpu_relax() asm volatile("rep; nop" ::: "memory");

#elif defined(__arm__) || defined(__mips__) || defined(__riscv)

    #define cpu_relax() asm volatile("":::"memory")

#elif defined(__aarch64__)

#define cpu_relax() asm volatile("yield" ::: "memory")

#else

#error "cpu_relax is not defined for this architecture"

#endif
}

#endif
