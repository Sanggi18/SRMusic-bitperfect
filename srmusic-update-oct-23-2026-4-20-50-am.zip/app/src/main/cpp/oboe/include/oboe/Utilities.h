#ifndef OBOE_UTILITIES_H

#define OBOE_UTILITIES_H

#include <unistd.h>
#include <sys/types.h>
#include <string>
#include "oboe/Definitions.h"

namespace oboe {
void convertFloatToPcm16(const float *source, int16_t *destination, int32_t numSamples);

void convertPcm16ToFloat(const int16_t *source, float *destination, int32_t numSamples);

int32_t convertFormatToSizeInBytes(AudioFormat format);

template <typename FromType>

const char * convertToText(FromType input);

std::string getPropertyString(const char * name);

int getPropertyInteger(const char * name, int defaultValue);

int getSdkVersion();

bool isAtLeastPreReleaseCodename(const std::string& codename);

int getChannelCountFromChannelMask(ChannelMask channelMask);

bool isCompressedFormat(AudioFormat format);

std::string toString(const PlaybackParameters& parameters);
}

#endif
