#ifndef OBOE_VERSIONINFO_H

#define OBOE_VERSIONINFO_H

#include <cstdint>

#define OBOE_VERSION_MAJOR 1

#define OBOE_VERSION_MINOR 11

#define OBOE_VERSION_PATCH 0

#define OBOE_STRINGIFY(x) #x

#define OBOE_TOSTRING(x) OBOE_STRINGIFY(x)

#define OBOE_VERSION_TEXT \
        OBOE_TOSTRING(OBOE_VERSION_MAJOR) "." \
        OBOE_TOSTRING(OBOE_VERSION_MINOR) "." \
        OBOE_TOSTRING(OBOE_VERSION_PATCH)

#define OBOE_VERSION_NUMBER ((OBOE_VERSION_MAJOR << 24) | (OBOE_VERSION_MINOR << 16) | OBOE_VERSION_PATCH)

namespace oboe {
const char * getVersionText();

struct Version {
    static constexpr uint8_t Major = OBOE_VERSION_MAJOR;

    static constexpr uint8_t Minor = OBOE_VERSION_MINOR;

    static constexpr uint16_t Patch = OBOE_VERSION_PATCH;

    static constexpr const char * Text = OBOE_VERSION_TEXT;

    static constexpr uint32_t Number = OBOE_VERSION_NUMBER;
};
}

#endif
