#ifndef OBOE_STREAM_AAUDIO_H_

#define OBOE_STREAM_AAUDIO_H_

#include <atomic>
#include <shared_mutex>
#include <mutex>
#include <thread>
#include <common/AdpfWrapper.h>
#include "oboe/AudioStreamBuilder.h"
#include "oboe/AudioStream.h"
#include "oboe/Definitions.h"
#include "AAudioLoader.h"

namespace oboe {
class AudioStreamAAudio : public AudioStream {
public:
    AudioStreamAAudio();

    explicit AudioStreamAAudio(const AudioStreamBuilder &builder);

    virtual ~AudioStreamAAudio() = default;

    static bool isSupported();

    Result open() override;

    Result release() override;

    Result close() override;

    Result requestStart() override;

    Result requestPause() override;

    Result requestFlush() override;

    Result requestStop() override;

    ResultWithValue<int32_t> write(const void *buffer,
                  int32_t numFrames,
                  int64_t timeoutNanoseconds) override;

    ResultWithValue<int32_t> read(void *buffer,
                 int32_t numFrames,
                 int64_t timeoutNanoseconds) override;

    ResultWithValue<int32_t> setBufferSizeInFrames(int32_t requestedFrames) override;

    int32_t getBufferSizeInFrames() override;

    ResultWithValue<int32_t> getXRunCount()  override;

    bool isXRunCountSupported() const override { return true; }

    ResultWithValue<double> calculateLatencyMillis() override;

    Result waitForStateChange(StreamState currentState,
                              StreamState *nextState,
                              int64_t timeoutNanoseconds) override;

    Result getTimestamp(clockid_t clockId,
                                       int64_t *framePosition,
                                       int64_t *timeNanoseconds) override;

    StreamState getState() override;

    int32_t getDeviceId() const override;

    std::vector<int32_t> getDeviceIds() const override;

    AudioApi getAudioApi() const override {
        return AudioApi::AAudio;
    }

    DataCallbackResult callOnAudioReady(AAudioStream *stream, void *audioData, int32_t numFrames);

    int32_t callOnPartialAudioReady(AAudioStream *stream, void *audioData, int32_t numFrames);

    bool isMMapUsed();

    void closePerformanceHint() override {
        mAdpfWrapper.close();

        mAdpfOpenAttempted = false;
    }

    oboe::Result reportWorkload(int32_t appWorkload) override {
        if (!isPerformanceHintEnabled()) {
            return oboe::Result::ErrorInvalidState;
        }

        mAdpfWrapper.reportWorkload(appWorkload);

        return oboe::Result::OK;
    }

    oboe::Result notifyWorkloadIncrease(bool cpu, bool gpu, const char* debugName) override {
        if (!isPerformanceHintEnabled()) {
            return oboe::Result::ErrorInvalidState;
        }

        return mAdpfWrapper.notifyWorkloadIncrease(cpu, gpu, debugName);
    }

    oboe::Result notifyWorkloadSpike(bool cpu, bool gpu, const char* debugName) override {
        if (!isPerformanceHintEnabled()) {
            return oboe::Result::ErrorInvalidState;
        }

        return mAdpfWrapper.notifyWorkloadSpike(cpu, gpu, debugName);
    }

    oboe::Result notifyWorkloadReset(bool cpu, bool gpu, const char* debugName) override {
        if (!isPerformanceHintEnabled()) {
            return oboe::Result::ErrorInvalidState;
        }

        return mAdpfWrapper.notifyWorkloadReset(cpu, gpu, debugName);
    }

    Result setOffloadDelayPadding(int32_t delayInFrames, int32_t paddingInFrames) override;

    ResultWithValue<int32_t> getOffloadDelay() override;

    ResultWithValue<int32_t> getOffloadPadding() override;

    Result setOffloadEndOfStream() override;

    ResultWithValue<int64_t> flushFromFrame(
            FlushFromAccuracy accuracy, int64_t positionInFrames) override;

    oboe::Result setPlaybackParameters(const PlaybackParameters& parameters) override;

    ResultWithValue<PlaybackParameters> getPlaybackParameters() override;

protected:
    static void internalErrorCallback(
            AAudioStream *stream,
            void *userData,
            aaudio_result_t error);

    static void internalPresentationEndCallback(
            AAudioStream *stream,
            void *userData);

    static void internalRoutingChangedCallback(
            AAudioStream *stream,
            void *userData,
            const int32_t *deviceIds,
            int32_t numDevices);

    void *getUnderlyingStream() const override {
        return mAAudioStream.load();
    }

    void updateFramesRead() override;

    void updateFramesWritten() override;

    void logUnsupportedAttributes();

    void beginPerformanceHintInCallback() override;

    void endPerformanceHintInCallback(int32_t numFrames) override;

    void onRoutingChanged(std::vector<int32_t> deviceIds);

    std::atomic<bool>    mAdpfOpenAttempted{false};

    AdpfWrapper          mAdpfWrapper;

private:
    Result requestStop_l(AAudioStream *stream);

    void launchStopThread();

    void updateDeviceIds();

private:
    std::atomic<bool>    mCallbackThreadEnabled;

    std::atomic<bool>    mStopThreadAllowed{false};

    std::atomic<AAudioStream *> mAAudioStream{nullptr};

    std::shared_mutex           mAAudioStreamLock;

    static AAudioLoader *mLibLoader;

    AudioStreamErrorCallback mDefaultErrorCallback;

    struct UpdatedDeviceIds {
        std::atomic<int> idx{0};

        std::vector<std::vector<int32_t>> deviceIds{ {}, {} };
    };

    UpdatedDeviceIds mUpdatedDeviceIds;
};
}

#endif
