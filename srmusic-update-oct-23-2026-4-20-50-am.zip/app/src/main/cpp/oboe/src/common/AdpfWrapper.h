#ifndef SYNTHMARK_ADPF_WRAPPER_H

#define SYNTHMARK_ADPF_WRAPPER_H

#include <algorithm>
#include <functional>
#include <stdint.h>
#include <sys/types.h>
#include <unistd.h>
#include <mutex>
#include "oboe/Definitions.h"

namespace oboe {
    struct APerformanceHintManager;

    struct APerformanceHintSession;

    typedef struct APerformanceHintManager APerformanceHintManager;

    typedef struct APerformanceHintSession APerformanceHintSession;

    class AdpfWrapper {
    public:
        int open(pid_t threadId,
                 int64_t targetDurationNanos);

        bool isOpen() const {
            return (mHintSession != nullptr);
        }

        void close();

        void onBeginCallback();

        void onEndCallback(double durationScaler);

        static void setUseAlternative(bool enabled) {
            sUseAlternativeHack = enabled;
        }

        void reportActualDuration(int64_t actualDurationNanos);

        void reportWorkload(int32_t appWorkload);

        oboe::Result notifyWorkloadIncrease(bool cpu, bool gpu, const char* debugName);

        oboe::Result notifyWorkloadReset(bool cpu, bool gpu, const char* debugName);

        oboe::Result notifyWorkloadSpike(bool cpu, bool gpu, const char* debugName);

    private:
        std::mutex mLock;

        APerformanceHintSession *mHintSession = nullptr;

        int64_t mBeginCallbackNanos = 0;

        static bool sUseAlternativeHack;

        int32_t mPreviousWorkload = 0;

        double mNanosPerWorkloadUnit = 0.0;
    };
}

#endif
