#ifndef OBOE_AUDIO_SOURCE_CALLER_H

#define OBOE_AUDIO_SOURCE_CALLER_H

#include "OboeDebug.h"
#include "oboe/Oboe.h"
#include "flowgraph/FlowGraphNode.h"
#include "FixedBlockReader.h"

namespace oboe {
class AudioStreamCallback;

class AudioStream;

class AudioSourceCaller : public flowgraph::FlowGraphSource, public FixedBlockProcessor {
public:
    AudioSourceCaller(int32_t channelCount, int32_t framesPerCallback, int32_t bytesPerSample)
            : FlowGraphSource(channelCount)
            , mBlockReader(*this) {
        mBlockReader.open(channelCount * framesPerCallback * bytesPerSample);
    }

    void setStream(oboe::AudioStream *stream) {
        mStream = stream;
    }

    oboe::AudioStream *getStream() {
        return mStream;
    }

    void setTimeoutNanos(int64_t timeoutNanos) {
        mTimeoutNanos = timeoutNanos;
    }

    int64_t getTimeoutNanos() const {
        return mTimeoutNanos;
    }

    int32_t onProcessFixedBlock(uint8_t *buffer, int32_t numBytes) override;

protected:
    oboe::AudioStream         *mStream = nullptr;

    int64_t                    mTimeoutNanos = 0;

    FixedBlockReader           mBlockReader;
};
}

#endif
