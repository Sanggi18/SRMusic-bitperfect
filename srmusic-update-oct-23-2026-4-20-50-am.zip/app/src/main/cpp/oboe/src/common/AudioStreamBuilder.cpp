#include <sys/types.h>
#include "aaudio/AAudioExtensions.h"
#include "aaudio/AudioStreamAAudio.h"
#include "OboeDebug.h"
#include "oboe/Oboe.h"
#include "oboe/AudioStreamBuilder.h"
#include "opensles/AudioInputStreamOpenSLES.h"
#include "opensles/AudioOutputStreamOpenSLES.h"
#include "opensles/AudioStreamOpenSLES.h"
#include "QuirksManager.h"

#ifndef DISABLE_CONVERSION

#include "FilterAudioStream.h"

#endif

bool oboe::OboeGlobals::mWorkaroundsEnabled = true;

namespace oboe {
int32_t DefaultStreamValues::SampleRate = 48000;

int32_t DefaultStreamValues::FramesPerBurst = 192;

int32_t DefaultStreamValues::ChannelCount = 2;

constexpr int knumBurstsForLowLatencyStreams = 2;

#ifndef OBOE_ENABLE_AAUDIO

#define OBOE_ENABLE_AAUDIO 1

#endif

bool AudioStreamBuilder::isAAudioSupported() {
    return AudioStreamAAudio::isSupported() && OBOE_ENABLE_AAUDIO;
}

bool AudioStreamBuilder::isAAudioRecommended() {
    return (getSdkVersion() >= __ANDROID_API_O_MR1__) && isAAudioSupported();
}

AudioStream *AudioStreamBuilder::build() {
    AudioStream *stream = nullptr;

    if (isAAudioRecommended() && mAudioApi != AudioApi::OpenSLES) {
        stream = new AudioStreamAAudio(*this);
    } else if (isAAudioSupported() && mAudioApi == AudioApi::AAudio) {
        stream = new AudioStreamAAudio(*this);

        LOGE("Creating AAudio stream on 8.0 because it was specified. This is error prone.");
    } else {
        if (getDirection() == oboe::Direction::Output) {
            stream = new AudioOutputStreamOpenSLES(*this);
        } else if (getDirection() == oboe::Direction::Input) {
            stream = new AudioInputStreamOpenSLES(*this);
        }
    }

    return stream;
}

bool AudioStreamBuilder::isCompatible(AudioStreamBase &other) {
    return (getSampleRate() == oboe::Unspecified || getSampleRate() == other.getSampleRate())
           && (getFormat() == (AudioFormat)oboe::Unspecified || getFormat() == other.getFormat())
           && (getFramesPerDataCallback() == oboe::Unspecified || getFramesPerDataCallback() == other.getFramesPerDataCallback())
           && (getChannelCount() == oboe::Unspecified || getChannelCount() == other.getChannelCount());
}

Result AudioStreamBuilder::openStream(AudioStream **streamPP) {
    LOGW("Passing AudioStream pointer deprecated, Use openStream(std::shared_ptr<oboe::AudioStream> &stream) instead.");

    return openStreamInternal(streamPP);
}

Result AudioStreamBuilder::openStreamInternal(AudioStream **streamPP) {
    auto result = isValidConfig();

    if (result != Result::OK) {
        LOGW("%s() invalid config. Error %s", __func__, oboe::convertToText(result));

        return result;
    }

    if (mPartialDataCallback != nullptr &&
        (!OboeExtensions::isPartialDataCallbackSupported() || !willUseAAudio())) {
        LOGE("%s() Partial data callback is not supported.", __func__);

        return Result::ErrorIllegalArgument;
    }

#ifndef OBOE_SUPPRESS_LOG_SPAM

    LOGI("%s() %s -------- %s --------",
         __func__, getDirection() == Direction::Input ? "INPUT" : "OUTPUT", getVersionText());

#endif

    if (streamPP == nullptr) {
        return Result::ErrorNull;
    }

    *streamPP = nullptr;

    AudioStream *streamP = nullptr;

    AudioStreamBuilder childBuilder(*this);

#ifndef DISABLE_CONVERSION

    bool conversionNeeded = QuirksManager::getInstance().isConversionNeeded(*this, childBuilder);

    if (conversionNeeded) {
        if (isPartialDataCallbackSpecified()) {
            LOGW("%s(), partial data callback is not supported when data conversion is required",
                 __func__);

            return Result::ErrorIllegalArgument;
        }

        AudioStream *tempStream;

        result = childBuilder.openStreamInternal(&tempStream);

        if (result != Result::OK) {
            return result;
        }

        if (isCompatible(*tempStream)) {
            *streamPP = tempStream;

            return result;
        } else {
            AudioStreamBuilder parentBuilder = *this;

            if (getFormat() == oboe::AudioFormat::Unspecified) {
                parentBuilder.setFormat(tempStream->getFormat());
            }

            if (getChannelCount() == oboe::Unspecified) {
                parentBuilder.setChannelCount(tempStream->getChannelCount());
            }

            if (getSampleRate() == oboe::Unspecified) {
                parentBuilder.setSampleRate(tempStream->getSampleRate());
            }

            if (getFramesPerDataCallback() == oboe::Unspecified) {
                parentBuilder.setFramesPerCallback(tempStream->getFramesPerDataCallback());
            }

            LOGI("%s() create a FilterAudioStream for data conversion.", __func__);

            std::shared_ptr<AudioStream> childStream(tempStream);

            FilterAudioStream *filterStream = new FilterAudioStream(parentBuilder, childStream);

            childStream->setWeakThis(childStream);

            result = filterStream->configureFlowGraph();

            if (result !=  Result::OK) {
                filterStream->close();

                delete filterStream;
            } else {
                streamP = static_cast<AudioStream *>(filterStream);
            }
        }
    }

#endif

    if (streamP == nullptr) {
        streamP = build();

        if (streamP == nullptr) {
            return Result::ErrorNull;
        }
    }

    bool wasMMapOriginallyEnabled = AAudioExtensions::getInstance().isMMapEnabled();

    bool wasMMapTemporarilyDisabled = false;

    if (wasMMapOriginallyEnabled) {
        bool isMMapSafe = QuirksManager::getInstance().isMMapSafe(childBuilder);

        if (!isMMapSafe) {
            AAudioExtensions::getInstance().setMMapEnabled(false);

            wasMMapTemporarilyDisabled = true;
        }
    }

    result = streamP->open();

    if (wasMMapTemporarilyDisabled) {
        AAudioExtensions::getInstance().setMMapEnabled(wasMMapOriginallyEnabled);
    }

    if (result == Result::OK) {
        if (streamP->getAudioApi() == AudioApi::AAudio) {
            int32_t  optimalBufferSize = -1;

            if (streamP->getDirection() == Direction::Input) {
                optimalBufferSize = streamP->getBufferCapacityInFrames();
            } else if (streamP->getPerformanceMode() == PerformanceMode::LowLatency
                    && streamP->getDirection() == Direction::Output)  {
                optimalBufferSize = streamP->getFramesPerBurst() *

                                        knumBurstsForLowLatencyStreams;
            }

            if (optimalBufferSize >= 0) {
                auto setBufferResult = streamP->setBufferSizeInFrames(optimalBufferSize);

                if (!setBufferResult) {
                    LOGW("Failed to setBufferSizeInFrames(%d). Error was %s",
                         optimalBufferSize,
                         convertToText(setBufferResult.error()));
                }
            }
        }

        *streamPP = streamP;
    } else {
        delete streamP;
    }

    return result;
}

Result AudioStreamBuilder::openManagedStream(oboe::ManagedStream &stream) {
    LOGW("`openManagedStream` is deprecated. Use openStream(std::shared_ptr<oboe::AudioStream> &stream) instead.");

    stream.reset();

    AudioStream *streamptr;

    auto result = openStream(&streamptr);

    stream.reset(streamptr);

    return result;
}

Result AudioStreamBuilder::openStream(std::shared_ptr<AudioStream> &sharedStream) {
    sharedStream.reset();

    AudioStream *streamptr;

    auto result = openStreamInternal(&streamptr);

    if (result == Result::OK) {
        sharedStream.reset(streamptr);

        streamptr->setWeakThis(sharedStream);
    }

    return result;
}
}
