#include <memory>
#include "OboeDebug.h"
#include "DataConversionFlowGraph.h"
#include "SourceFloatCaller.h"
#include "SourceI16Caller.h"
#include "SourceI24Caller.h"
#include "SourceI32Caller.h"
#include <flowgraph/MonoToMultiConverter.h>
#include <flowgraph/MultiToMonoConverter.h>
#include <flowgraph/RampLinear.h>
#include <flowgraph/SinkFloat.h>
#include <flowgraph/SinkI16.h>
#include <flowgraph/SinkI24.h>
#include <flowgraph/SinkI32.h>
#include <flowgraph/SourceFloat.h>
#include <flowgraph/SourceI16.h>
#include <flowgraph/SourceI24.h>
#include <flowgraph/SourceI32.h>
#include <flowgraph/SampleRateConverter.h>

using namespace oboe;

using namespace flowgraph;

using namespace resampler;

void DataConversionFlowGraph::setSource(const void *buffer, int32_t numFrames) {
    mSource->setData(buffer, numFrames);
}

static MultiChannelResampler::Quality convertOboeSRQualityToMCR(SampleRateConversionQuality quality) {
    switch (quality) {
        case SampleRateConversionQuality::Fastest:
            return MultiChannelResampler::Quality::Fastest;

        case SampleRateConversionQuality::Low:
            return MultiChannelResampler::Quality::Low;

        default:
        case SampleRateConversionQuality::Medium:
            return MultiChannelResampler::Quality::Medium;

        case SampleRateConversionQuality::High:
            return MultiChannelResampler::Quality::High;

        case SampleRateConversionQuality::Best:
            return MultiChannelResampler::Quality::Best;
    }
}

Result DataConversionFlowGraph::configure(AudioStream *sourceStream, AudioStream *sinkStream) {
    FlowGraphPortFloatOutput *lastOutput = nullptr;

    bool isOutput = sourceStream->getDirection() == Direction::Output;

    bool isInput = !isOutput;

    mFilterStream = isOutput ? sourceStream : sinkStream;

    AudioFormat sourceFormat = sourceStream->getFormat();

    int32_t sourceChannelCount = sourceStream->getChannelCount();

    int32_t sourceSampleRate = sourceStream->getSampleRate();

    int32_t sourceFramesPerCallback = sourceStream->getFramesPerDataCallback();

    AudioFormat sinkFormat = sinkStream->getFormat();

    int32_t sinkChannelCount = sinkStream->getChannelCount();

    int32_t sinkSampleRate = sinkStream->getSampleRate();

    int32_t sinkFramesPerCallback = sinkStream->getFramesPerDataCallback();

    LOGI("%s() flowgraph converts channels: %d to %d, format: %s to %s"

            ", rate: %d to %d, cbsize: %d to %d, qual = %s",
            __func__,
            sourceChannelCount, sinkChannelCount,
            oboe::convertToText(sourceFormat), oboe::convertToText(sinkFormat),
            sourceSampleRate, sinkSampleRate,
            sourceFramesPerCallback, sinkFramesPerCallback,
            oboe::convertToText(sourceStream->getSampleRateConversionQuality()));

    bool isDataCallbackSpecified = sourceStream->isDataCallbackSpecified();

    if ((isDataCallbackSpecified && isOutput)
        || (!isDataCallbackSpecified && isInput)) {
        int32_t actualSourceFramesPerCallback = (sourceFramesPerCallback == kUnspecified)

                ? sourceStream->getFramesPerBurst()
                : sourceFramesPerCallback;

        switch (sourceFormat) {
            case AudioFormat::Float:
                mSourceCaller = std::make_unique<SourceFloatCaller>(sourceChannelCount,
                                                                    actualSourceFramesPerCallback);

                break;

            case AudioFormat::I16:
                mSourceCaller = std::make_unique<SourceI16Caller>(sourceChannelCount,
                                                                  actualSourceFramesPerCallback);

                break;

            case AudioFormat::I24:
                mSourceCaller = std::make_unique<SourceI24Caller>(sourceChannelCount,
                                                                  actualSourceFramesPerCallback);

                break;

            case AudioFormat::I32:
                mSourceCaller = std::make_unique<SourceI32Caller>(sourceChannelCount,
                                                                  actualSourceFramesPerCallback);

                break;

            default:
                LOGE("%s() Unsupported source caller format = %d", __func__, static_cast<int>(sourceFormat));

                return Result::ErrorIllegalArgument;
        }

        mSourceCaller->setStream(sourceStream);

        lastOutput = &mSourceCaller->output;
    } else {
        switch (sourceFormat) {
            case AudioFormat::Float:
                mSource = std::make_unique<SourceFloat>(sourceChannelCount);

                break;

            case AudioFormat::I16:
                mSource = std::make_unique<SourceI16>(sourceChannelCount);

                break;

            case AudioFormat::I24:
                mSource = std::make_unique<SourceI24>(sourceChannelCount);

                break;

            case AudioFormat::I32:
                mSource = std::make_unique<SourceI32>(sourceChannelCount);

                break;

            default:
                LOGE("%s() Unsupported source format = %d", __func__, static_cast<int>(sourceFormat));

                return Result::ErrorIllegalArgument;
        }

        if (isInput) {
            int32_t actualSinkFramesPerCallback = (sinkFramesPerCallback == kUnspecified)

                    ? sinkStream->getFramesPerBurst()
                    : sinkFramesPerCallback;

            mBlockWriter.open(actualSinkFramesPerCallback * sinkStream->getBytesPerFrame());

            mAppBuffer = std::make_unique<uint8_t[]>(
                    kDefaultBufferSize * sinkStream->getBytesPerFrame());
        }

        lastOutput = &mSource->output;
    }

    if (sourceChannelCount > sinkChannelCount) {
        if (sinkChannelCount == 1) {
            mMultiToMonoConverter = std::make_unique<MultiToMonoConverter>(sourceChannelCount);

            lastOutput->connect(&mMultiToMonoConverter->input);

            lastOutput = &mMultiToMonoConverter->output;
        } else {
            mChannelCountConverter = std::make_unique<ChannelCountConverter>(
                    sourceChannelCount,
                    sinkChannelCount);

            lastOutput->connect(&mChannelCountConverter->input);

            lastOutput = &mChannelCountConverter->output;
        }
    }

    if (sourceSampleRate != sinkSampleRate) {
        mResampler.reset(MultiChannelResampler::make(lastOutput->getSamplesPerFrame(),
                                                     sourceSampleRate,
                                                     sinkSampleRate,
                                                     convertOboeSRQualityToMCR(
                                                             sourceStream->getSampleRateConversionQuality())));

        mRateConverter = std::make_unique<SampleRateConverter>(lastOutput->getSamplesPerFrame(),
                                                               *mResampler.get());

        lastOutput->connect(&mRateConverter->input);

        lastOutput = &mRateConverter->output;
    }

    if (sourceChannelCount < sinkChannelCount) {
        if (sourceChannelCount == 1) {
            mMonoToMultiConverter = std::make_unique<MonoToMultiConverter>(sinkChannelCount);

            lastOutput->connect(&mMonoToMultiConverter->input);

            lastOutput = &mMonoToMultiConverter->output;
        } else {
            mChannelCountConverter = std::make_unique<ChannelCountConverter>(
                    sourceChannelCount,
                    sinkChannelCount);

            lastOutput->connect(&mChannelCountConverter->input);

            lastOutput = &mChannelCountConverter->output;
        }
    }

    switch (sinkFormat) {
        case AudioFormat::Float:
            mSink = std::make_unique<SinkFloat>(sinkChannelCount);

            break;

        case AudioFormat::I16:
            mSink = std::make_unique<SinkI16>(sinkChannelCount);

            break;

        case AudioFormat::I24:
            mSink = std::make_unique<SinkI24>(sinkChannelCount);

            break;

        case AudioFormat::I32:
            mSink = std::make_unique<SinkI32>(sinkChannelCount);

            break;

        default:
            LOGE("%s() Unsupported sink format = %d", __func__, static_cast<int>(sinkFormat));

            return Result::ErrorIllegalArgument;;
    }

    lastOutput->connect(&mSink->input);

    return Result::OK;
}

int32_t DataConversionFlowGraph::read(void *buffer, int32_t numFrames, int64_t timeoutNanos) {
    if (mSourceCaller) {
        mSourceCaller->setTimeoutNanos(timeoutNanos);
    }

    int32_t numRead = mSink->read(buffer, numFrames);

    return numRead;
}

int32_t DataConversionFlowGraph::write(void *inputBuffer, int32_t numFrames) {
    mSource->setData(inputBuffer, numFrames);

    while (true) {
        int32_t framesRead = mSink->read(mAppBuffer.get(), flowgraph::kDefaultBufferSize);

        if (framesRead <= 0) break;

        int32_t bytesRead = mBlockWriter.write(mAppBuffer.get(),
                                               framesRead * mFilterStream->getBytesPerFrame());

        if (bytesRead < 0) return bytesRead;
    }

    return numFrames;
}

int32_t DataConversionFlowGraph::onProcessFixedBlock(uint8_t *buffer, int32_t numBytes) {
    int32_t numFrames = numBytes / mFilterStream->getBytesPerFrame();

    mCallbackResult = mFilterStream->getDataCallback()->onAudioReady(mFilterStream, buffer, numFrames);

    return numBytes;
}
