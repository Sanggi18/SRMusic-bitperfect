#ifndef OBOE_OBOE_FLOW_GRAPH_H

#define OBOE_OBOE_FLOW_GRAPH_H

#include <memory>
#include <stdint.h>
#include <sys/types.h>
#include <flowgraph/ChannelCountConverter.h>
#include <flowgraph/MonoToMultiConverter.h>
#include <flowgraph/MultiToMonoConverter.h>
#include <flowgraph/SampleRateConverter.h>
#include <oboe/Definitions.h>
#include "AudioSourceCaller.h"
#include "FixedBlockWriter.h"

namespace oboe {
class AudioStream;

class AudioSourceCaller;

class DataConversionFlowGraph : public FixedBlockProcessor {
public:
    DataConversionFlowGraph()
    : mBlockWriter(*this) {}

    void setSource(const void *buffer, int32_t numFrames);

    oboe::Result configure(oboe::AudioStream *sourceStream, oboe::AudioStream *sinkStream);

    int32_t read(void *buffer, int32_t numFrames, int64_t timeoutNanos);

    int32_t write(void *buffer, int32_t numFrames);

    int32_t onProcessFixedBlock(uint8_t *buffer, int32_t numBytes) override;

    DataCallbackResult getDataCallbackResult() {
        return mCallbackResult;
    }

private:
    std::unique_ptr<flowgraph::FlowGraphSourceBuffered>    mSource;

    std::unique_ptr<AudioSourceCaller>                 mSourceCaller;

    std::unique_ptr<flowgraph::MonoToMultiConverter>   mMonoToMultiConverter;

    std::unique_ptr<flowgraph::MultiToMonoConverter>   mMultiToMonoConverter;

    std::unique_ptr<flowgraph::ChannelCountConverter>  mChannelCountConverter;

    std::unique_ptr<resampler::MultiChannelResampler>  mResampler;

    std::unique_ptr<flowgraph::SampleRateConverter>    mRateConverter;

    std::unique_ptr<flowgraph::FlowGraphSink>              mSink;

    FixedBlockWriter                                   mBlockWriter;

    DataCallbackResult                                 mCallbackResult = DataCallbackResult::Continue;

    AudioStream                                       *mFilterStream = nullptr;

    std::unique_ptr<uint8_t[]>                         mAppBuffer;
};
}

#endif
