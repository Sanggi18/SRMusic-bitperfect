#include <memory>
#include "OboeDebug.h"
#include "FilterAudioStream.h"

using namespace oboe;

using namespace flowgraph;

Result FilterAudioStream::configureFlowGraph() {
    mFlowGraph = std::make_unique<DataConversionFlowGraph>();

    bool isOutput = getDirection() == Direction::Output;

    AudioStream *sourceStream =  isOutput ? this : mChildStream.get();

    AudioStream *sinkStream =  isOutput ? mChildStream.get() : this;

    mRateScaler = ((double) getSampleRate()) / mChildStream->getSampleRate();

    return mFlowGraph->configure(sourceStream, sinkStream);
}

ResultWithValue<int32_t> FilterAudioStream::write(const void *buffer,
                               int32_t numFrames,
                               int64_t timeoutNanoseconds) {
    int32_t framesWritten = 0;

    mFlowGraph->setSource(buffer, numFrames);

    while (true) {
        int32_t numRead = mFlowGraph->read(mBlockingBuffer.get(),
                getFramesPerBurst(),
                timeoutNanoseconds);

        if (numRead < 0) {
            return ResultWithValue<int32_t>::createBasedOnSign(numRead);
        }

        if (numRead == 0) {
            break;
        }

        auto writeResult = mChildStream->write(mBlockingBuffer.get(),
                                               numRead,
                                               timeoutNanoseconds);

        if (!writeResult) {
            return writeResult;
        }

        framesWritten += writeResult.value();
    }

    return ResultWithValue<int32_t>::createBasedOnSign(framesWritten);
}

ResultWithValue<int32_t> FilterAudioStream::read(void *buffer,
                                                  int32_t numFrames,
                                                  int64_t timeoutNanoseconds) {
    int32_t framesRead = mFlowGraph->read(buffer, numFrames, timeoutNanoseconds);

    return ResultWithValue<int32_t>::createBasedOnSign(framesRead);
}

DataCallbackResult FilterAudioStream::onAudioReady(AudioStream *oboeStream,
                                void *audioData,
                                int32_t numFrames) {
    int32_t framesProcessed;

    if (oboeStream->getDirection() == Direction::Output) {
        framesProcessed = mFlowGraph->read(audioData, numFrames, 0  );
    } else {
        framesProcessed = mFlowGraph->write(audioData, numFrames);
    }

    return (framesProcessed < numFrames)

           ? DataCallbackResult::Stop
           : mFlowGraph->getDataCallbackResult();
}
