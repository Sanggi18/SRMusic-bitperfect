#ifndef AAUDIO_FIXED_BLOCK_ADAPTER_H

#define AAUDIO_FIXED_BLOCK_ADAPTER_H

#include <memory>
#include <stdint.h>
#include <sys/types.h>

class FixedBlockProcessor {
public:
    virtual ~FixedBlockProcessor() = default;

    virtual int32_t onProcessFixedBlock(uint8_t *buffer, int32_t numBytes) = 0;
};

class FixedBlockAdapter

{
public:
    FixedBlockAdapter(FixedBlockProcessor &fixedBlockProcessor)
            : mFixedBlockProcessor(fixedBlockProcessor) {}

    virtual ~FixedBlockAdapter();

    virtual int32_t open(int32_t bytesPerFixedBlock);

    int32_t close();

protected:
    FixedBlockProcessor  &mFixedBlockProcessor;

    std::unique_ptr<uint8_t[]> mStorage;

    int32_t               mSize = 0;

    int32_t               mPosition = 0;
};

#endif
