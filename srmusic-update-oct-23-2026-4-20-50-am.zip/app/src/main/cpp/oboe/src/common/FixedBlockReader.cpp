#include <stdint.h>
#include <memory.h>
#include "FixedBlockAdapter.h"
#include "FixedBlockReader.h"

FixedBlockReader::FixedBlockReader(FixedBlockProcessor &fixedBlockProcessor)
        : FixedBlockAdapter(fixedBlockProcessor) {
    mPosition = mSize;
}

int32_t FixedBlockReader::open(int32_t bytesPerFixedBlock) {
    int32_t result = FixedBlockAdapter::open(bytesPerFixedBlock);

    mPosition = 0;

    mValid = 0;

    return result;
}

int32_t FixedBlockReader::readFromStorage(uint8_t *buffer, int32_t numBytes) {
    int32_t bytesToRead = numBytes;

    int32_t dataAvailable = mValid - mPosition;

    if (bytesToRead > dataAvailable) {
        bytesToRead = dataAvailable;
    }

    memcpy(buffer, mStorage.get() + mPosition, bytesToRead);

    mPosition += bytesToRead;

    return bytesToRead;
}

int32_t FixedBlockReader::read(uint8_t *buffer, int32_t numBytes) {
    int32_t bytesRead;

    int32_t bytesLeft = numBytes;

    while(bytesLeft > 0) {
        if (mPosition < mValid) {
            bytesRead = readFromStorage(buffer, bytesLeft);

            buffer += bytesRead;

            bytesLeft -= bytesRead;
        } else if (bytesLeft >= mSize) {
            bytesRead = mFixedBlockProcessor.onProcessFixedBlock(buffer, mSize);

            if (bytesRead < 0) return bytesRead;

            buffer += bytesRead;

            bytesLeft -= bytesRead;
        } else {
            bytesRead = mFixedBlockProcessor.onProcessFixedBlock(mStorage.get(), mSize);

            if (bytesRead < 0) return bytesRead;

            mPosition = 0;

            mValid = bytesRead;

            if (bytesRead == 0) break;
        }
    }

    return numBytes - bytesLeft;
}
