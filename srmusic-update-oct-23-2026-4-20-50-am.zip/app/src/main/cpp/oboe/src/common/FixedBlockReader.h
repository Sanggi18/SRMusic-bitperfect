#ifndef AAUDIO_FIXED_BLOCK_READER_H

#define AAUDIO_FIXED_BLOCK_READER_H

#include <stdint.h>
#include "FixedBlockAdapter.h"

class FixedBlockReader : public FixedBlockAdapter

{
public:
    FixedBlockReader(FixedBlockProcessor &fixedBlockProcessor);

    virtual ~FixedBlockReader() = default;

    int32_t open(int32_t bytesPerFixedBlock) override;

    int32_t read(uint8_t *buffer, int32_t numBytes);

private:
    int32_t readFromStorage(uint8_t *buffer, int32_t numBytes);

    int32_t               mValid = 0;
};

#endif
