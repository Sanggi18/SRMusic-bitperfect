#include <stdint.h>
#include <memory.h>
#include "FixedBlockAdapter.h"
#include "FixedBlockWriter.h"

FixedBlockWriter::FixedBlockWriter(FixedBlockProcessor &fixedBlockProcessor)
        : FixedBlockAdapter(fixedBlockProcessor) {}

int32_t FixedBlockWriter::writeToStorage(uint8_t *buffer, int32_t numBytes) {
    int32_t bytesToStore = numBytes;

    int32_t roomAvailable = mSize - mPosition;

    if (bytesToStore > roomAvailable) {
        bytesToStore = roomAvailable;
    }

    memcpy(mStorage.get() + mPosition, buffer, bytesToStore);

    mPosition += bytesToStore;

    return bytesToStore;
}

int32_t FixedBlockWriter::write(uint8_t *buffer, int32_t numBytes) {
    int32_t bytesLeft = numBytes;

    if (mPosition > 0) {
        int32_t bytesWritten = writeToStorage(buffer, bytesLeft);

        buffer += bytesWritten;

        bytesLeft -= bytesWritten;

        if (mPosition == mSize) {
            bytesWritten = mFixedBlockProcessor.onProcessFixedBlock(mStorage.get(), mSize);

            if (bytesWritten < 0) return bytesWritten;

            mPosition = 0;

            if (bytesWritten < mSize) {
                return -1;
            }
        }
    }

    while(bytesLeft >= mSize) {
        int32_t bytesWritten = mFixedBlockProcessor.onProcessFixedBlock(buffer, mSize);

        if (bytesWritten < 0) return bytesWritten;

        buffer += bytesWritten;

        bytesLeft -= bytesWritten;
    }

    if (bytesLeft > 0) {
        int32_t bytesWritten = writeToStorage(buffer, bytesLeft);

        bytesLeft -= bytesWritten;
    }

    return numBytes - bytesLeft;
}
