#ifndef AAUDIO_FIXED_BLOCK_WRITER_H

#define AAUDIO_FIXED_BLOCK_WRITER_H

#include <stdint.h>
#include "FixedBlockAdapter.h"

class FixedBlockWriter : public FixedBlockAdapter

{
public:
    FixedBlockWriter(FixedBlockProcessor &fixedBlockProcessor);

    virtual ~FixedBlockWriter() = default;

    int32_t write(uint8_t *buffer, int32_t numBytes);

private:
    int32_t writeToStorage(uint8_t *buffer, int32_t numBytes);
};

#endif
