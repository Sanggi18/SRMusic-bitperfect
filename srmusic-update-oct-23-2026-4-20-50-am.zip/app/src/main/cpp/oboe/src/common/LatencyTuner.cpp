#include "oboe/LatencyTuner.h"

using namespace oboe;

LatencyTuner::LatencyTuner(AudioStream &stream)
        : LatencyTuner(stream, stream.getBufferCapacityInFrames()) {
}

LatencyTuner::LatencyTuner(oboe::AudioStream &stream, int32_t maximumBufferSize)
        : mStream(stream)
        , mMaxBufferSize(maximumBufferSize) {
    int32_t burstSize = stream.getFramesPerBurst();

    setMinimumBufferSize(kDefaultNumBursts * burstSize);

    setBufferSizeIncrement(burstSize);

    reset();
}

Result LatencyTuner::tune() {
    if (mState == State::Unsupported) {
        return Result::ErrorUnimplemented;
    }

    Result result = Result::OK;

    int32_t numRequests = mLatencyTriggerRequests.load();

    if (numRequests != mLatencyTriggerResponses.load()) {
        mLatencyTriggerResponses.store(numRequests);

        reset();
    }

    if (mState == State::Idle && --mIdleCountDown <= 0) {
        mState = State::Active;
    }

    if (mState == State::Active) {
        auto xRunCountResult = mStream.getXRunCount();

        if (xRunCountResult == Result::OK) {
            if ((xRunCountResult.value() - mPreviousXRuns) > 0) {
                mPreviousXRuns = xRunCountResult.value();

                int32_t oldBufferSize = mStream.getBufferSizeInFrames();

                int32_t requestedBufferSize = oldBufferSize + getBufferSizeIncrement();

                if (requestedBufferSize > mMaxBufferSize) requestedBufferSize = mMaxBufferSize;

                auto setBufferResult = mStream.setBufferSizeInFrames(requestedBufferSize);

                if (setBufferResult != Result::OK) {
                    result = setBufferResult;

                    mState = State::Unsupported;
                } else if (setBufferResult.value() == oldBufferSize) {
                    mState = State::AtMax;
                }
            }
        } else {
            mState = State::Unsupported;
        }
    }

    if (mState == State::Unsupported) {
        result = Result::ErrorUnimplemented;
    }

    if (mState == State::AtMax) {
        result = Result::OK;
    }

    return result;
}

void LatencyTuner::requestReset() {
    if (mState != State::Unsupported) {
        mLatencyTriggerRequests++;
    }
}

void LatencyTuner::reset() {
    mState = State::Idle;

    mIdleCountDown = kIdleCount;

    mStream.setBufferSizeInFrames(getMinimumBufferSize());
}

bool LatencyTuner::isAtMaximumBufferSize() {
    return mState == State::AtMax;
}
