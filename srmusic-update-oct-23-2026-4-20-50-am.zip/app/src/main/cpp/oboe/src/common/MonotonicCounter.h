#ifndef COMMON_MONOTONIC_COUNTER_H

#define COMMON_MONOTONIC_COUNTER_H

#include <cstdint>

class MonotonicCounter {
public:
    MonotonicCounter() {}

    virtual ~MonotonicCounter() {}

    int64_t get() const {
        return mCounter64;
    }

    void set(int64_t counter) {
        mCounter64 = counter;
    }

    int64_t increment(int64_t delta) {
        if (delta > 0) {
            mCounter64 += delta;
        }

        return mCounter64;
    }

    int64_t update32(int32_t counter32) {
        int32_t delta = counter32 - mCounter32;

        if (delta > 0) {
            mCounter64 += delta;

            mCounter32 = counter32;
        }

        return mCounter64;
    }

    void reset32() {
        mCounter32 = 0;
    }

    void roundUp64(int32_t period) {
        if (period > 0) {
            int64_t numPeriods = (mCounter64 + period - 1) / period;

            mCounter64 = numPeriods * period;
        }
    }

private:
    int64_t mCounter64 = 0;

    int32_t mCounter32 = 0;
};

#endif
