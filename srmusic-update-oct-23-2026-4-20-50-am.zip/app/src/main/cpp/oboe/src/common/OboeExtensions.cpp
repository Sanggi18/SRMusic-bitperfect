#include "oboe/OboeExtensions.h"
#include "aaudio/AAudioExtensions.h"

using namespace oboe;

bool OboeExtensions::isMMapSupported(){
    return AAudioExtensions::getInstance().isMMapSupported();
}

bool OboeExtensions::isMMapEnabled(){
    return AAudioExtensions::getInstance().isMMapEnabled();
}

int32_t OboeExtensions::setMMapEnabled(bool enabled){
    return AAudioExtensions::getInstance().setMMapEnabled(enabled);
}

bool OboeExtensions::isMMapUsed(oboe::AudioStream *oboeStream){
    return AAudioExtensions::getInstance().isMMapUsed(oboeStream);
}

bool OboeExtensions::isPartialDataCallbackSupported() {
    return AAudioExtensions::getInstance().isPartialDataCallbackSupported();
}
