#include <oboe/AudioStreamBuilder.h>
#include <oboe/Oboe.h>
#include <oboe/Utilities.h>
#include "OboeDebug.h"
#include "QuirksManager.h"

using namespace oboe;

int32_t QuirksManager::DeviceQuirks::clipBufferSize(AudioStream &stream,
            int32_t requestedSize) {
    if (!OboeGlobals::areWorkaroundsEnabled()) {
        return requestedSize;
    }

    int bottomMargin = kDefaultBottomMarginInBursts;

    int topMargin = kDefaultTopMarginInBursts;

    if (isMMapUsed(stream)) {
        if (stream.getSharingMode() == SharingMode::Exclusive) {
            bottomMargin = getExclusiveBottomMarginInBursts();

            topMargin = getExclusiveTopMarginInBursts();
        }
    } else {
        bottomMargin = kLegacyBottomMarginInBursts;
    }

    int32_t burst = stream.getFramesPerBurst();

    int32_t minSize = bottomMargin * burst;

    int32_t adjustedSize = requestedSize;

    if (adjustedSize < minSize ) {
        adjustedSize = minSize;
    } else {
        int32_t maxSize = stream.getBufferCapacityInFrames() - (topMargin * burst);

        if (adjustedSize > maxSize ) {
            adjustedSize = maxSize;
        }
    }

    return adjustedSize;
}

bool QuirksManager::DeviceQuirks::isAAudioMMapPossible(const AudioStreamBuilder &builder) const {
    bool isSampleRateCompatible =
            builder.getSampleRate() == oboe::Unspecified
            || builder.getSampleRate() == kCommonNativeRate
            || builder.getSampleRateConversionQuality() != SampleRateConversionQuality::None;

    return builder.getPerformanceMode() == PerformanceMode::LowLatency
            && isSampleRateCompatible
            && builder.getChannelCount() <= kChannelCountStereo;
}

bool QuirksManager::DeviceQuirks::shouldConvertFloatToI16ForOutputStreams() {
    std::string productManufacturer = getPropertyString("ro.product.manufacturer");

    if (getSdkVersion() < __ANDROID_API_L__) {
        return true;
    } else if ((productManufacturer == "vivo") && (getSdkVersion() < __ANDROID_API_M__)) {
        return true;
    }

    return false;
}

class SamsungExynosDeviceQuirks : public  QuirksManager::DeviceQuirks {
public:
    SamsungExynosDeviceQuirks() {
        std::string chipname = getPropertyString("ro.hardware.chipname");

        isExynos9810 = (chipname == "exynos9810");

        isExynos990 = (chipname == "exynos990");

        isExynos850 = (chipname == "exynos850");

        mBuildChangelist = getPropertyInteger("ro.build.changelist", 0);
    }

    virtual ~SamsungExynosDeviceQuirks() = default;

    int32_t getExclusiveBottomMarginInBursts() const override {
        return kBottomMargin;
    }

    int32_t getExclusiveTopMarginInBursts() const override {
        return kTopMargin;
    }

    bool isMonoMMapActuallyStereo() const override {
        return isExynos9810 || isExynos850;
    }

    bool isAAudioMMapPossible(const AudioStreamBuilder &builder) const override {
        return DeviceQuirks::isAAudioMMapPossible(builder)
                && builder.getInputPreset() != oboe::InputPreset::Camcorder;
    }

    bool isMMapSafe(const AudioStreamBuilder &builder) override {
        const bool isInput = builder.getDirection() == Direction::Input;

        bool isRecordingCorrupted = isInput
            && isExynos990
            && mBuildChangelist < 19350896;

        bool wouldRecordSilence = isInput
            && isExynos9810
            && mBuildChangelist <= 18847185
            && (builder.getInputPreset() != InputPreset::VoiceCommunication);

        if (wouldRecordSilence){
            LOGI("QuirksManager::%s() Requested stream configuration would result in silence on "

                 "this device. Switching off MMAP.", __func__);
        }

        return !isRecordingCorrupted && !wouldRecordSilence;
    }

private:
    static constexpr int32_t kBottomMargin = 2;

    static constexpr int32_t kTopMargin = 1;

    bool isExynos9810 = false;

    bool isExynos990 = false;

    bool isExynos850 = false;

    int mBuildChangelist = 0;
};

class QualcommDeviceQuirks : public  QuirksManager::DeviceQuirks {
public:
    QualcommDeviceQuirks() {
        std::string modelName = getPropertyString("ro.soc.model");

        isSM8150 = (modelName == "SDM8150");
    }

    virtual ~QualcommDeviceQuirks() = default;

    int32_t getExclusiveBottomMarginInBursts() const override {
        return kBottomMargin;
    }

    bool isMMapSafe(const AudioStreamBuilder &builder) override {
        bool isMMapBroken = false;

        if (isSM8150 && (getSdkVersion() <= __ANDROID_API_P__)) {
            LOGI("QuirksManager::%s() MMAP not actually supported on this chip."

                 " Switching off MMAP.", __func__);

            isMMapBroken = true;
        }

        return !isMMapBroken;
    }

private:
    bool isSM8150 = false;

    static constexpr int32_t kBottomMargin = 1;
};

QuirksManager::QuirksManager() {
    std::string productManufacturer = getPropertyString("ro.product.manufacturer");

    if (productManufacturer == "samsung") {
        std::string arch = getPropertyString("ro.arch");

        bool isExynos = (arch.rfind("exynos", 0) == 0);

        if (isExynos) {
            mDeviceQuirks = std::make_unique<SamsungExynosDeviceQuirks>();
        }
    }

    if (!mDeviceQuirks) {
        std::string socManufacturer = getPropertyString("ro.soc.manufacturer");

        if (socManufacturer == "Qualcomm") {
            mDeviceQuirks = std::make_unique<QualcommDeviceQuirks>();
        } else {
            mDeviceQuirks = std::make_unique<DeviceQuirks>();
        }
    }
}

bool QuirksManager::isConversionNeeded(
        const AudioStreamBuilder &builder,
        AudioStreamBuilder &childBuilder) {
    bool conversionNeeded = false;

    const bool isLowLatency = builder.getPerformanceMode() == PerformanceMode::LowLatency;

    const bool isInput = builder.getDirection() == Direction::Input;

    const bool isFloat = builder.getFormat() == AudioFormat::Float;

    const bool isIEC61937 = builder.getFormat() == AudioFormat::IEC61937;

    const bool isCompressed = isCompressedFormat(builder.getFormat());

    if (isIEC61937) {
        LOGI("QuirksManager::%s() conversion not needed for IEC61937", __func__);

        return false;
    }

    if (isCompressed) {
        LOGI("QuirksManager::%s() conversion not needed for compressed format %d",
             __func__, builder.getFormat());

        return false;
    }

    if (OboeGlobals::areWorkaroundsEnabled()
            && builder.willUseAAudio()
            && builder.isDataCallbackSpecified()
            && builder.getFramesPerDataCallback() != 0
            && getSdkVersion() <= __ANDROID_API_R__) {
        LOGI("QuirksManager::%s() avoid setFramesPerCallback(n>0)", __func__);

        childBuilder.setFramesPerCallback(oboe::Unspecified);

        conversionNeeded = true;
    }

    if (builder.getSampleRate() != oboe::Unspecified
            && builder.getSampleRateConversionQuality() != SampleRateConversionQuality::None
            && isLowLatency
            ) {
        childBuilder.setSampleRate(oboe::Unspecified);

        conversionNeeded = true;
    }

    if (OboeGlobals::areWorkaroundsEnabled()
            && isFloat
            && isInput
            && builder.isFormatConversionAllowed()
            && isLowLatency
            && (!builder.willUseAAudio() || (getSdkVersion() < __ANDROID_API_P__))
            ) {
        childBuilder.setFormat(AudioFormat::I16);

        conversionNeeded = true;

        LOGI("QuirksManager::%s() forcing internal format to I16 for low latency", __func__);
    }

    if (OboeGlobals::areWorkaroundsEnabled()
            && isFloat
            && !isInput
            && builder.isFormatConversionAllowed()
            && mDeviceQuirks->shouldConvertFloatToI16ForOutputStreams()
            ) {
        childBuilder.setFormat(AudioFormat::I16);

        conversionNeeded = true;

        LOGI("QuirksManager::%s() float was requested but not supported on pre-L devices "

             "and some devices like Vivo devices may have issues on L devices, "

             "creating an underlying I16 stream and using format conversion to provide a float "

             "stream", __func__);
    }

    if (OboeGlobals::areWorkaroundsEnabled()
            && builder.isChannelConversionAllowed()
            && builder.getChannelCount() == kChannelCountStereo
            && isInput
            && isLowLatency
            && (!builder.willUseAAudio() && (getSdkVersion() == __ANDROID_API_O__))
            ) {
        childBuilder.setChannelCount(kChannelCountMono);

        conversionNeeded = true;

        LOGI("QuirksManager::%s() using mono internally for low latency on O", __func__);
    } else if (OboeGlobals::areWorkaroundsEnabled()
               && builder.getChannelCount() == kChannelCountMono
               && isInput
               && mDeviceQuirks->isMonoMMapActuallyStereo()
               && builder.willUseAAudio()
               && mDeviceQuirks->isAAudioMMapPossible(builder)
               ) {
        childBuilder.setChannelCount(kChannelCountStereo);

        conversionNeeded = true;

        LOGI("QuirksManager::%s() using stereo internally to avoid broken mono", __func__);
    }

    return conversionNeeded;
}

bool QuirksManager::isMMapSafe(AudioStreamBuilder &builder) {
    if (!OboeGlobals::areWorkaroundsEnabled()) return true;

    return mDeviceQuirks->isMMapSafe(builder);
}
