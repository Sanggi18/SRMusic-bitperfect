#ifndef OBOE_QUIRKS_MANAGER_H

#define OBOE_QUIRKS_MANAGER_H

#include <memory>
#include <oboe/AudioStreamBuilder.h>
#include <aaudio/AudioStreamAAudio.h>

#ifndef __ANDROID_API_R__

#define __ANDROID_API_R__ 30

#endif

namespace oboe {
class QuirksManager {
public:
    static QuirksManager &getInstance() {
        static QuirksManager instance;

        return instance;
    }

    QuirksManager();

    virtual ~QuirksManager() = default;

    bool isConversionNeeded(const AudioStreamBuilder &builder, AudioStreamBuilder &childBuilder);

    static bool isMMapUsed(AudioStream &stream) {
        bool answer = false;

        if (stream.getAudioApi() == AudioApi::AAudio) {
            AudioStreamAAudio *streamAAudio =
                    reinterpret_cast<AudioStreamAAudio *>(&stream);

            answer = streamAAudio->isMMapUsed();
        }

        return answer;
    }

    virtual int32_t clipBufferSize(AudioStream &stream, int32_t bufferSize) {
        return mDeviceQuirks->clipBufferSize(stream, bufferSize);
    }

    class DeviceQuirks {
    public:
        virtual ~DeviceQuirks() = default;

        int32_t clipBufferSize(AudioStream &stream, int32_t requestedSize);

        virtual int32_t getExclusiveBottomMarginInBursts() const {
            return kDefaultBottomMarginInBursts;
        }

        virtual int32_t getExclusiveTopMarginInBursts() const {
            return kDefaultTopMarginInBursts;
        }

        virtual bool isMonoMMapActuallyStereo() const {
            return false;
        }

        virtual bool isAAudioMMapPossible(const AudioStreamBuilder &builder) const;

        virtual bool isMMapSafe(const AudioStreamBuilder &   ) {
            return true;
        }

        static bool shouldConvertFloatToI16ForOutputStreams();

        static constexpr int32_t kDefaultBottomMarginInBursts = 0;

        static constexpr int32_t kDefaultTopMarginInBursts = 0;

        static constexpr int32_t kLegacyBottomMarginInBursts = 1;

        static constexpr int32_t kCommonNativeRate = 48000;
    };

    bool isMMapSafe(AudioStreamBuilder &builder);

private:
    static constexpr int32_t kChannelCountMono = 1;

    static constexpr int32_t kChannelCountStereo = 2;

    std::unique_ptr<DeviceQuirks> mDeviceQuirks{};
};
}

#endif
