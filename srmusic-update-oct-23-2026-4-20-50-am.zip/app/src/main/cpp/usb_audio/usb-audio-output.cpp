#include "usb-audio-output.h"
#include <jni.h>
#include <android/log.h>
#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <new>
#include <unistd.h>
#include <time.h>
#include <sys/ioctl.h>
#include <linux/usbdevice_fs.h>

#ifndef USBDEVFS_URB_ISO_ASAP

#define USBDEVFS_URB_ISO_ASAP 0x02

#endif

#include "../terminal_logger.h"
#include <cstdarg>

#define TAG "UsbAudioOutput"

static inline void usb_diag_log(const char* prio, const char* fmt, ...) {
    char buf[512];

    va_list args;

    va_start(args, fmt);

    vsnprintf(buf, sizeof(buf), fmt, args);

    va_end(args);

    terminal_log_diag(TAG, prio, buf);
}

#define LOGI(...) do { __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__); usb_diag_log("I", __VA_ARGS__); } while(0)

#define LOGW(...) do { __android_log_print(ANDROID_LOG_WARN,  TAG, __VA_ARGS__); usb_diag_log("W", __VA_ARGS__); } while(0)

#define LOGE(...) do { __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__); usb_diag_log("E", __VA_ARGS__); } while(0)

static inline float clampf(float v) { return v > 1.0f ? 1.0f : (v < -1.0f ? -1.0f : v); }

static void convertFloatToInt16(const float *src, uint8_t *dst, int n) {
    auto *out = reinterpret_cast<int16_t *>(dst);

    for (int i = 0; i < n; i++) {
        float s = clampf(src[i]) * 32768.0f;

        if (s > 32767.0f) s = 32767.0f;

        if (s < -32768.0f) s = -32768.0f;

        out[i] = (int16_t)s;
    }
}

static void convertFloatToInt24(const float *src, uint8_t *dst, int n) {
    for (int i = 0; i < n; i++) {
        float s = clampf(src[i]) * 8388608.0f;

        if (s > 8388607.0f) s = 8388607.0f;

        if (s < -8388608.0f) s = -8388608.0f;

        int32_t v = (int32_t)s;

        dst[i*3] = v & 0xFF; dst[i*3+1] = (v>>8) & 0xFF; dst[i*3+2] = (v>>16) & 0xFF;
    }
}

static void convertFloatToInt32(const float *src, uint8_t *dst, int n) {
    auto *out = reinterpret_cast<int32_t *>(dst);

    for (int i = 0; i < n; i++) {
        double s = (double)clampf(src[i]) * 2147483648.0;

        if (s > 2147483647.0) s = 2147483647.0;

        if (s < -2147483648.0) s = -2147483648.0;

        out[i] = (int32_t)s;
    }
}

static bool allocRing(UsbAudioContext *ctx) {
    size_t urbStructSize = sizeof(struct usbdevfs_urb) +
                           USB_AUDIO_PACKETS_PER_URB * sizeof(struct usbdevfs_iso_packet_desc);

    for (int i = 0; i < USB_AUDIO_NUM_URBS; i++) {
        ctx->ring[i].urb = (struct usbdevfs_urb *)calloc(1, urbStructSize);

        ctx->ring[i].buffer = (uint8_t *)malloc(USB_AUDIO_URB_BUFFER_SIZE);

        ctx->ring[i].dataLength = 0;

        if (!ctx->ring[i].urb || !ctx->ring[i].buffer) {
            LOGE("allocRing: OOM at slot %d", i);

            for (int j = 0; j <= i; j++) {
                free(ctx->ring[j].urb);

                free(ctx->ring[j].buffer);
            }

            return false;
        }
    }

    ctx->ringAllocated = true;

    return true;
}

static void freeRing(UsbAudioContext *ctx) {
    if (!ctx->ringAllocated) return;

    for (int i = 0; i < USB_AUDIO_NUM_URBS; i++) {
        free(ctx->ring[i].urb);

        free(ctx->ring[i].buffer);

        ctx->ring[i].urb = nullptr;

        ctx->ring[i].buffer = nullptr;
    }

    ctx->ringAllocated = false;
}

static double readFeedback(int fd, int ep) {
    uint8_t fb[4] = {};

    size_t sz = sizeof(struct usbdevfs_urb) + sizeof(struct usbdevfs_iso_packet_desc);

    auto *u = (struct usbdevfs_urb *)calloc(1, sz);

    if (!u) return 0;

    u->type = USBDEVFS_URB_TYPE_ISO;

    u->flags = USBDEVFS_URB_ISO_ASAP;

    u->endpoint = (unsigned char)ep;

    u->buffer = fb;

    u->buffer_length = 4;

    u->number_of_packets = 1;

    u->iso_frame_desc[0].length = 4;

    if (ioctl(fd, USBDEVFS_SUBMITURB, u) < 0) { free(u); return 0; }

    struct usbdevfs_urb *c = nullptr;

    usleep(2000);

    if (ioctl(fd, USBDEVFS_REAPURBNDELAY, &c) < 0) {
        ioctl(fd, USBDEVFS_DISCARDURB, u);

        ioctl(fd, USBDEVFS_REAPURBNDELAY, &c);

        free(u); return 0;
    }

    double r = 0;

    if (u->iso_frame_desc[0].actual_length >= 4) {
        uint32_t raw = fb[0] | (fb[1]<<8) | (fb[2]<<16) | (fb[3]<<24);

        r = raw / 65536.0;
    }

    free(u);

    return r;
}

static bool allocFeedbackUrb(UsbAudioContext *ctx) {
    size_t sz = sizeof(struct usbdevfs_urb) + sizeof(struct usbdevfs_iso_packet_desc);

    ctx->feedbackUrb = (struct usbdevfs_urb *)calloc(1, sz);

    if (!ctx->feedbackUrb) return false;

    ctx->feedbackInFlight = false;

    memset(ctx->feedbackBuffer, 0, sizeof(ctx->feedbackBuffer));

    return true;
}

static bool submitFeedbackUrb(UsbAudioContext *ctx) {
    if (ctx->endpointFeedback <= 0 || !ctx->feedbackUrb || ctx->feedbackInFlight)

        return false;

    struct usbdevfs_urb *u = ctx->feedbackUrb;

    size_t sz = sizeof(struct usbdevfs_urb) + sizeof(struct usbdevfs_iso_packet_desc);

    memset(u, 0, sz);

    u->type = USBDEVFS_URB_TYPE_ISO;

    u->flags = USBDEVFS_URB_ISO_ASAP;

    u->endpoint = (unsigned char)ctx->endpointFeedback;

    u->buffer = ctx->feedbackBuffer;

    u->buffer_length = 4;

    u->number_of_packets = 1;

    u->iso_frame_desc[0].length = 4;

    if (ioctl(ctx->fd, USBDEVFS_SUBMITURB, u) < 0) {
        LOGW("submitFeedbackUrb: failed errno=%d (%s)", errno, strerror(errno));

        return false;
    }

    ctx->feedbackInFlight = true;

    return true;
}

static int64_t g_feedbackCount = 0;

static void handleFeedbackCompletion(UsbAudioContext *ctx) {
    ctx->feedbackInFlight = false;

    g_feedbackCount++;

    if (ctx->feedbackUrb->iso_frame_desc[0].actual_length >= 4) {
        uint8_t *fb = ctx->feedbackBuffer;

        uint32_t raw = fb[0] | (fb[1] << 8) | (fb[2] << 16) | (fb[3] << 24);

        double newFpmf = raw / 65536.0;

        double nominal = ctx->sampleRate / 8000.0;

        if (newFpmf > nominal * 0.99 && newFpmf < nominal * 1.01) {
            ctx->calibratedFpmf = ctx->calibratedFpmf * 0.995 + newFpmf * 0.005;

            if (g_feedbackCount % 10000 == 0) {
                LOGI("Feedback #%lld: fpmf=%.4f (%.1f Hz)",
                     (long long)g_feedbackCount, ctx->calibratedFpmf, ctx->calibratedFpmf * 8000.0);
            }
        }
    }

    submitFeedbackUrb(ctx);
}

static int submitRingUrb(UsbAudioContext *ctx, const int *pktSizes, int numPackets, int totalBytes) {
    UrbSlot *slot = &ctx->ring[ctx->submitIdx];

    struct usbdevfs_urb *u = slot->urb;

    size_t clearSize = sizeof(struct usbdevfs_urb) +
                       numPackets * sizeof(struct usbdevfs_iso_packet_desc);

    memset(u, 0, clearSize);

    u->type = USBDEVFS_URB_TYPE_ISO;

    u->flags = USBDEVFS_URB_ISO_ASAP;

    u->endpoint = (unsigned char)ctx->endpointOut;

    u->buffer = slot->buffer;

    u->buffer_length = totalBytes;

    u->number_of_packets = numPackets;

    for (int i = 0; i < numPackets; i++)

        u->iso_frame_desc[i].length = (unsigned)pktSizes[i];

    slot->dataLength = totalBytes;

    int ret = ioctl(ctx->fd, USBDEVFS_SUBMITURB, u);

    if (ret < 0) {
        LOGE("SUBMITURB FAILED slot=%d ep=0x%02x bytes=%d pkts=%d errno=%d (%s)",
             ctx->submitIdx, ctx->endpointOut, totalBytes, numPackets, errno, strerror(errno));

        return -1;
    }

    ctx->submitIdx = (ctx->submitIdx + 1) % USB_AUDIO_NUM_URBS;

    ctx->urbsInFlight++;

    return 0;
}

static int reapOldestUrb(UsbAudioContext *ctx, int timeoutMs) {
    struct usbdevfs_urb *c = nullptr;

    int iterations = timeoutMs * 8;

    for (int i = 0; i < iterations; i++) {
        int ret = ioctl(ctx->fd, USBDEVFS_REAPURBNDELAY, &c);

        if (ret == 0 && c != nullptr) {
            if (c == ctx->feedbackUrb) {
                handleFeedbackCompletion(ctx);

                c = nullptr;

                continue;
            }

            ctx->reapIdx = (ctx->reapIdx + 1) % USB_AUDIO_NUM_URBS;

            ctx->urbsInFlight--;

            return 0;
        }

        if (ret < 0 && errno != EAGAIN) {
            LOGE("reapOldestUrb: error errno=%d (%s)", errno, strerror(errno));

            return -1;
        }

        usleep(125);
    }

    return -2;
}

static int drainAllUrbs(UsbAudioContext *ctx) {
    int drained = 0;

    int initialCount = ctx->urbsInFlight;

    LOGI("drainAllUrbs: draining %d URBs (feedback=%s)...",
         initialCount, ctx->feedbackInFlight ? "in-flight" : "idle");

    if (ctx->feedbackInFlight && ctx->feedbackUrb) {
        ioctl(ctx->fd, USBDEVFS_DISCARDURB, ctx->feedbackUrb);

        struct usbdevfs_urb *c = nullptr;

        for (int i = 0; i < 50; i++) {
            if (ioctl(ctx->fd, USBDEVFS_REAPURBNDELAY, &c) == 0 && c == ctx->feedbackUrb) {
                break;
            }

            usleep(100);
        }

        ctx->feedbackInFlight = false;
    }

    while (ctx->urbsInFlight > 0) {
        int result = reapOldestUrb(ctx, 500);

        if (result == 0) {
            drained++;
        } else {
            break;
        }
    }

    if (ctx->urbsInFlight > 0) {
        LOGW("drainAllUrbs: %d/%d reaped naturally, discarding remaining %d",
             drained, initialCount, ctx->urbsInFlight);

        int toDiscard = ctx->urbsInFlight;

        for (int i = 0; i < toDiscard; i++) {
            int slotIdx = (ctx->reapIdx + i) % USB_AUDIO_NUM_URBS;

            ioctl(ctx->fd, USBDEVFS_DISCARDURB, ctx->ring[slotIdx].urb);
        }

        int reaped = 0;

        for (int attempt = 0; attempt < 500 && reaped < toDiscard; attempt++) {
            struct usbdevfs_urb *c = nullptr;

            int ret = ioctl(ctx->fd, USBDEVFS_REAPURBNDELAY, &c);

            if (ret == 0 && c != nullptr) {
                reaped++;
            } else if (ret < 0 && errno != EAGAIN) {
                LOGE("drainAllUrbs: reap error errno=%d", errno);

                break;
            } else {
                usleep(1000);
            }
        }

        LOGI("drainAllUrbs: discarded %d, reaped %d completions", toDiscard, reaped);

        drained += reaped;

        for (int i = 0; i < 10; i++) {
            struct usbdevfs_urb *c = nullptr;

            if (ioctl(ctx->fd, USBDEVFS_REAPURBNDELAY, &c) == 0 && c != nullptr) {
                LOGW("drainAllUrbs: flushed stale completion %p", c);

                drained++;
            } else {
                break;
            }
        }
    }

    ctx->urbsInFlight = 0;

    ctx->submitIdx = 0;

    ctx->reapIdx = 0;

    LOGI("drainAllUrbs: drained %d/%d, ring reset", drained, initialCount);

    return drained;
}

void submitPcmToUrbs(UsbAudioContext *ctx, const uint8_t *pcmData, int totalBytes);

extern "C" {
JNIEXPORT jlong JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioCreate(
        JNIEnv *, jobject, jint fd, jint ifId, jint epOut, jint epFb,
        jint rate, jint ch, jint bits, jint maxPkt) {
    LOGI("Create: fd=%d ep=0x%02x rate=%d ch=%d bits=%d maxPkt=%d",
         fd, epOut, rate, ch, bits, maxPkt);

    auto *ctx = new(std::nothrow) UsbAudioContext();

    if (!ctx) return 0;

    ctx->fd = fd;

    ctx->interfaceId = ifId;

    ctx->endpointOut = epOut;

    ctx->endpointFeedback = epFb;

    ctx->sampleRate = rate;

    ctx->channelCount = ch;

    ctx->bitDepth = bits;

    ctx->bytesPerSample = bits / 8;

    ctx->bytesPerFrame = (bits / 8) * ch;

    ctx->maxPacketSize = maxPkt;

    ctx->running.store(false);

    ctx->transferBuffer = nullptr;

    ctx->transferBufferCapacity = 0;

    ctx->mergeBuffer = nullptr;

    ctx->mergeBufferCapacity = 0;

    ctx->framesWritten = 0;

    ctx->interfaceClaimed = true;

    ctx->submitIdx = 0;

    ctx->reapIdx = 0;

    ctx->urbsInFlight = 0;

    ctx->ringAllocated = false;

    ctx->frameAccumulator = 0.0;

    ctx->calibratedFpmf = rate / 8000.0;

    ctx->residualBytes = 0;

    memset(ctx->residualBuffer, 0, sizeof(ctx->residualBuffer));

    memset(ctx->ring, 0, sizeof(ctx->ring));

    ctx->feedbackUrb = nullptr;

    ctx->feedbackInFlight = false;

    memset(ctx->feedbackBuffer, 0, sizeof(ctx->feedbackBuffer));

    if (!allocRing(ctx)) {
        delete ctx;

        return 0;
    }

    if (!allocFeedbackUrb(ctx)) {
        freeRing(ctx);

        delete ctx;

        return 0;
    }

    return reinterpret_cast<jlong>(ctx);
}

JNIEXPORT jboolean JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioSetAltSetting(
        JNIEnv *, jobject, jlong h, jint alt) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return JNI_FALSE;

    struct usbdevfs_setinterface si = {};

    si.interface = (unsigned)ctx->interfaceId;

    si.altsetting = (unsigned)alt;

    int r = ioctl(ctx->fd, USBDEVFS_SETINTERFACE, &si);

    LOGI("setAlt(%d,%d): ret=%d errno=%d", ctx->interfaceId, alt, r, errno);

    return r >= 0 ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioSetSampleRate(
        JNIEnv *, jobject, jlong h, jint rate, jint csId) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return JNI_FALSE;

    ctx->sampleRate = rate;

    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioStart(
        JNIEnv *, jobject, jlong h) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return JNI_FALSE;

    ctx->running.store(true);

    ctx->framesWritten = 0;

    ctx->submitIdx = 0;

    ctx->reapIdx = 0;

    ctx->urbsInFlight = 0;

    ctx->frameAccumulator = 0.0;

    ctx->residualBytes = 0;

    double nominalFpmf = ctx->sampleRate / 8000.0;

    ctx->calibratedFpmf = nominalFpmf;

    if (ctx->endpointFeedback > 0) {
        double fb = readFeedback(ctx->fd, ctx->endpointFeedback);

        if (fb > 0) {
            ctx->calibratedFpmf = fb;

            LOGI("Start: initial feedback=%.4f fpmf (%.1f Hz), nominal=%.4f (%.1f Hz)",
                 fb, fb * 8000.0, nominalFpmf, nominalFpmf * 8000.0);
        } else {
            LOGW("Start: feedback not responding, using nominal %.4f fpmf", nominalFpmf);
        }

        submitFeedbackUrb(ctx);
    }

    LOGI("Start: rate=%d ch=%d bits=%d ring=%d slots×%dpkt fpmf=%.4f feedback=%s",
         ctx->sampleRate, ctx->channelCount, ctx->bitDepth,
         USB_AUDIO_NUM_URBS, USB_AUDIO_PACKETS_PER_URB,
         ctx->calibratedFpmf,
         ctx->feedbackInFlight ? "continuous" : "one-shot");

    return JNI_TRUE;
}

JNIEXPORT void JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioWrite(
        JNIEnv *env, jobject, jlong h, jfloatArray pcm) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx || !ctx->running.load()) return;

    jint totalSamples = env->GetArrayLength(pcm);

    if (totalSamples <= 0) return;

    int totalFrames = totalSamples / ctx->channelCount;

    int totalBytes = totalSamples * ctx->bytesPerSample;

    if (!ctx->transferBuffer || ctx->transferBufferCapacity < totalBytes) {
        free(ctx->transferBuffer);

        ctx->transferBuffer = (uint8_t *)malloc(totalBytes);

        ctx->transferBufferCapacity = totalBytes;
    }

    struct timespec writeStart, writeEnd;

    clock_gettime(CLOCK_MONOTONIC, &writeStart);

    static long writeCallCount = 0;

    writeCallCount++;

    jfloat *f = env->GetFloatArrayElements(pcm, nullptr);

    if (!f) return;

    switch (ctx->bitDepth) {
        case 16: convertFloatToInt16(f, ctx->transferBuffer, totalSamples); break;

        case 24: convertFloatToInt24(f, ctx->transferBuffer, totalSamples); break;

        case 32: convertFloatToInt32(f, ctx->transferBuffer, totalSamples); break;

        default: env->ReleaseFloatArrayElements(pcm, f, JNI_ABORT); return;
    }

    env->ReleaseFloatArrayElements(pcm, f, JNI_ABORT);

    submitPcmToUrbs(ctx, ctx->transferBuffer, totalBytes);

    ctx->framesWritten += totalFrames;

    clock_gettime(CLOCK_MONOTONIC, &writeEnd);

    long writeUs = (writeEnd.tv_sec - writeStart.tv_sec) * 1000000L +
                   (writeEnd.tv_nsec - writeStart.tv_nsec) / 1000L;

    if (writeUs > 10000 || writeCallCount % 100 == 0) {
        LOGI("nativeWrite #%ld: %d samples, %ldus (%.1fms), inflight=%d",
             writeCallCount, totalSamples, writeUs, writeUs / 1000.0, ctx->urbsInFlight);
    }

    if (ctx->framesWritten % ctx->sampleRate < (int64_t)totalFrames) {
        LOGI("Write: %lld frames (~%.0f sec) inflight=%d fpmf=%.4f (%.1f Hz)",
             (long long)ctx->framesWritten, (double)ctx->framesWritten/ctx->sampleRate,
             ctx->urbsInFlight, ctx->calibratedFpmf, ctx->calibratedFpmf * 8000.0);
    }
}

JNIEXPORT void JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioStop(
        JNIEnv *, jobject, jlong h) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return;

    ctx->running.store(false);

    LOGI("Stop: %lld frames, %d URBs in flight",
         (long long)ctx->framesWritten, ctx->urbsInFlight);
}

JNIEXPORT void JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeFlush(
        JNIEnv *, jobject, jlong h) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return;

    ctx->frameAccumulator = 0.0;

    ctx->residualBytes = 0;

    ctx->framesWritten = 0;

    LOGI("Flush: frameAccumulator, residual, and framesWritten reset");
}

JNIEXPORT jint JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeDrainUrbs(
        JNIEnv *, jobject, jlong h) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return 0;

    ctx->running.store(false);

    return drainAllUrbs(ctx);
}

JNIEXPORT void JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioDestroy(
        JNIEnv *, jobject, jlong h) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return;

    ctx->running.store(false);

    if (ctx->urbsInFlight > 0) {
        drainAllUrbs(ctx);
    }

    freeRing(ctx);

    free(ctx->feedbackUrb);

    ctx->feedbackUrb = nullptr;

    free(ctx->transferBuffer);

    ctx->transferBuffer = nullptr;

    free(ctx->mergeBuffer);

    ctx->mergeBuffer = nullptr;

    LOGI("Destroy: %lld frames total", (long long)ctx->framesWritten);

    delete ctx;
}

JNIEXPORT jboolean JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeIsRunning(
        JNIEnv *, jobject, jlong h) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return JNI_FALSE;

    return ctx->running.load() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jlong JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeGetFramesWritten(
        JNIEnv *, jobject, jlong h) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx) return 0;

    return (jlong)ctx->framesWritten;
}

JNIEXPORT jint JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbReset(
        JNIEnv *, jclass, jint fd) {
    LOGI("USBDEVFS_RESET fd=%d", fd);

    int ret = ioctl(fd, USBDEVFS_RESET, 0);

    if (ret < 0) { LOGE("RESET FAILED errno=%d", errno); return ret; }

    LOGI("RESET OK, claiming interfaces...");

    struct usbdevfs_ioctl cmd = {}; cmd.ifno = 0; cmd.ioctl_code = USBDEVFS_DISCONNECT;

    ioctl(fd, USBDEVFS_IOCTL, &cmd);

    int i0 = 0; ioctl(fd, USBDEVFS_CLAIMINTERFACE, &i0);

    cmd.ifno = 1; ioctl(fd, USBDEVFS_IOCTL, &cmd);

    int i1 = 1; ioctl(fd, USBDEVFS_CLAIMINTERFACE, &i1);

    struct usbdevfs_setinterface si = {}; si.interface = 1; si.altsetting = 0;

    ioctl(fd, USBDEVFS_SETINTERFACE, &si);

    return 0;
}
}

void padInt16ToInt32(const uint8_t *src, uint8_t *dst, int numSamples) {
    auto *out = reinterpret_cast<int32_t *>(dst);

    auto *in16 = reinterpret_cast<const int16_t *>(src);

    for (int i = 0; i < numSamples; i++) out[i] = (int32_t)in16[i] << 16;
}

void shiftInt32From24(const uint8_t *src, uint8_t *dst, int numSamples) {
    auto *out = reinterpret_cast<int32_t *>(dst);

    auto *in32 = reinterpret_cast<const int32_t *>(src);

    for (int i = 0; i < numSamples; i++) out[i] = in32[i] << 8;
}

void padInt24ToInt32(const uint8_t *src, uint8_t *dst, int numSamples) {
    auto *out = reinterpret_cast<int32_t *>(dst);

    for (int i = 0; i < numSamples; i++) {
        int32_t s = src[i*3] | (src[i*3+1] << 8) | (src[i*3+2] << 16);

        if (s & 0x800000) s |= 0xFF000000;

        out[i] = s << 8;
    }
}

void submitPcmToUrbs(UsbAudioContext *ctx, const uint8_t *pcmData, int totalBytes) {
    const uint8_t *data = pcmData;

    int dataLen = totalBytes;

    if (ctx->residualBytes > 0 && totalBytes > 0) {
        dataLen = ctx->residualBytes + totalBytes;

        if (!ctx->mergeBuffer || ctx->mergeBufferCapacity < dataLen) {
            free(ctx->mergeBuffer);

            ctx->mergeBuffer = (uint8_t *)malloc(dataLen + 4096);

            ctx->mergeBufferCapacity = dataLen + 4096;
        }

        if (ctx->mergeBuffer) {
            memcpy(ctx->mergeBuffer, ctx->residualBuffer, ctx->residualBytes);

            memcpy(ctx->mergeBuffer + ctx->residualBytes, pcmData, totalBytes);

            data = ctx->mergeBuffer;
        }

        ctx->residualBytes = 0;
    }

    int offset = 0;

    double fpmf = ctx->calibratedFpmf;

    while (offset < dataLen && ctx->running.load()) {
        int pktSizes[USB_AUDIO_PACKETS_PER_URB];

        int numPackets = 0;

        int urbBytes = 0;

        for (int p = 0; p < USB_AUDIO_PACKETS_PER_URB; p++) {
            int remaining = dataLen - offset - urbBytes;

            if (remaining <= 0) break;

            ctx->frameAccumulator += fpmf;

            int frames = (int)ctx->frameAccumulator;

            ctx->frameAccumulator -= frames;

            int b = frames * ctx->bytesPerFrame;

            if (b > remaining) {
                break;
            }

            pktSizes[p] = b;

            urbBytes += b;

            numPackets++;
        }

        if (numPackets <= 0 || urbBytes <= 0) break;

        if (numPackets < USB_AUDIO_PACKETS_PER_URB) {
            int leftover = dataLen - offset;

            if (leftover > 0 && leftover < (int)sizeof(ctx->residualBuffer)) {
                memcpy(ctx->residualBuffer, data + offset, leftover);

                ctx->residualBytes = leftover;
            }

            break;
        }

        if (ctx->urbsInFlight >= USB_AUDIO_NUM_URBS) {
            int result = reapOldestUrb(ctx, 200);

            if (result == -2) {
                LOGE("submitPcmToUrbs: reap timeout, inflight=%d", ctx->urbsInFlight);

                drainAllUrbs(ctx);

                ctx->running.store(false);

                return;
            } else if (result < 0) {
                ctx->running.store(false);

                return;
            }
        }

        UrbSlot *slot = &ctx->ring[ctx->submitIdx];

        memcpy(slot->buffer, data + offset, urbBytes);

        if (submitRingUrb(ctx, pktSizes, numPackets, urbBytes) < 0) {
            LOGE("submitPcmToUrbs: submit failed, stopping stream");

            ctx->running.store(false);

            return;
        }

        offset += urbBytes;
    }

    int leftover = dataLen - offset;

    if (leftover > 0 && leftover < (int)sizeof(ctx->residualBuffer) && ctx->residualBytes == 0) {
        memcpy(ctx->residualBuffer, data + offset, leftover);

        ctx->residualBytes = leftover;
    }
}

extern "C" {
JNIEXPORT void JNICALL

Java_com_example_core_audio_usb_UsbAudioStream_nativeUsbAudioWriteRaw(
        JNIEnv *env, jobject, jlong h, jbyteArray pcm, jint inputBitDepth) {
    auto *ctx = reinterpret_cast<UsbAudioContext *>(h);

    if (!ctx || !ctx->running.load()) return;

    jint inputBytes = env->GetArrayLength(pcm);

    if (inputBytes <= 0) return;

    int inputBps = inputBitDepth / 8;

    int totalSamples = inputBytes / inputBps;

    int totalFrames = totalSamples / ctx->channelCount;

    int outputBytes = totalSamples * ctx->bytesPerSample;

    if (!ctx->transferBuffer || ctx->transferBufferCapacity < outputBytes) {
        free(ctx->transferBuffer);

        ctx->transferBuffer = (uint8_t *)malloc(outputBytes);

        ctx->transferBufferCapacity = outputBytes;
    }

    static long writeRawCallCount = 0;

    writeRawCallCount++;

    struct timespec writeStart, writeEnd;

    clock_gettime(CLOCK_MONOTONIC, &writeStart);

    jbyte *rawData = env->GetByteArrayElements(pcm, nullptr);

    if (!rawData) return;

    if (inputBitDepth == ctx->bitDepth) {
        memcpy(ctx->transferBuffer, rawData, inputBytes);
    } else if (inputBitDepth == 16 && ctx->bitDepth == 32) {
        padInt16ToInt32((uint8_t *)rawData, ctx->transferBuffer, totalSamples);
    } else if (inputBitDepth == 24 && ctx->bitDepth == 32) {
        padInt24ToInt32((uint8_t *)rawData, ctx->transferBuffer, totalSamples);
    } else if (inputBitDepth == 32 && ctx->bitDepth == 32) {
        shiftInt32From24((uint8_t *)rawData, ctx->transferBuffer, totalSamples);
    } else {
        LOGE("WriteRaw: unsupported bit-depth conversion %d → %d", inputBitDepth, ctx->bitDepth);

        env->ReleaseByteArrayElements(pcm, rawData, JNI_ABORT);

        return;
    }

    env->ReleaseByteArrayElements(pcm, rawData, JNI_ABORT);

    submitPcmToUrbs(ctx, ctx->transferBuffer, outputBytes);

    ctx->framesWritten += totalFrames;

    clock_gettime(CLOCK_MONOTONIC, &writeEnd);

    long writeUs = (writeEnd.tv_sec - writeStart.tv_sec) * 1000000L +
                   (writeEnd.tv_nsec - writeStart.tv_nsec) / 1000L;

    if (writeUs > 10000 || writeRawCallCount % 100 == 0) {
        LOGI("nativeWrite #%ld: %d samples, %ldus (%.1fms), inflight=%d",
             writeRawCallCount, totalSamples, writeUs, writeUs / 1000.0, ctx->urbsInFlight);
    }

    if (ctx->framesWritten % ctx->sampleRate < (int64_t)totalFrames) {
        LOGI("Write: %lld frames (~%.0f sec) inflight=%d fpmf=%.4f (%.1f Hz)",
             (long long)ctx->framesWritten, (double)ctx->framesWritten/ctx->sampleRate,
             ctx->urbsInFlight, ctx->calibratedFpmf, ctx->calibratedFpmf * 8000.0);
    }
}
}
