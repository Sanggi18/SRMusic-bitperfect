package com.example.core.audio.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.util.Log
import com.example.core.audio.AudioTerminalLogger

class UsbAudioDevice private constructor(private val context: Context) {
    private var usbManager: UsbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    private var connection: UsbDeviceConnection? = null

    private var currentDevice: UsbDevice? = null

    private var claimedInterface: UsbInterface? = null

    private var claimedControlInterface: UsbInterface? = null

    private var claimedStreamingInterface: UsbInterface? = null

    private val deviceLock = Any()

    companion object {
        private const val TAG = "UsbAudioDevice"

        private const val ACTION_USB_PERMISSION_SUFFIX = ".USB_AUDIO_PERMISSION"

        @Volatile
        private var instance: UsbAudioDevice? = null

        fun getInstance(context: Context): UsbAudioDevice {
            return instance ?: synchronized(this) {
                instance ?: UsbAudioDevice(context.applicationContext).also { instance = it }
            }
        }
    }

    private var lastLoggedScanSignature: String = ""

    private var lastLoggedScanTime: Long = 0L

    fun findUsbAudioDevice(): UsbDevice? {
        val devices = usbManager.deviceList.values

        val currentSig = devices.joinToString(";") { "${it.deviceName}:${it.vendorId}:${it.productId}:${hasPermission(it)}" }

        val now = System.currentTimeMillis()

        val shouldLog = currentSig != lastLoggedScanSignature || (now - lastLoggedScanTime > 3000L)

        if (shouldLog) {
            lastLoggedScanSignature = currentSig

            lastLoggedScanTime = now

            AudioTerminalLogger.log("scanAndRequestPermission: Found ${devices.size} USB devices.")
        }

        for (device in devices) {
            val isAudio = (0 until device.interfaceCount).any { i ->
                val iface = device.getInterface(i)

                iface.interfaceClass == UsbConstants.USB_CLASS_AUDIO
            }

            val vidHex = "0x" + device.vendorId.toString(16).uppercase().padStart(4, '0')

            val pidHex = "0x" + device.productId.toString(16).uppercase().padStart(4, '0')

            val devName = device.productName ?: device.deviceName

            if (shouldLog) {
                AudioTerminalLogger.log("  Device: '${device.deviceName}' ($devName) VID=$vidHex PID=$pidHex isAudio=$isAudio")
            }

            for (i in 0 until device.interfaceCount) {
                val iface = device.getInterface(i)

                if (iface.interfaceClass == UsbConstants.USB_CLASS_AUDIO &&
                    iface.interfaceSubclass == 2) {
                    val hasPerm = hasPermission(device)

                    if (shouldLog) {
                        AudioTerminalLogger.log("Audio Device Selected: $devName (${device.deviceName}), hasPermission=$hasPerm")
                    }

                    Log.i(TAG, "Found USB audio device: $devName " +
                            "(vendor=$vidHex, product=$pidHex)")

                    return device
                }
            }
        }

        Log.d(TAG, "No USB audio device found")

        return null
    }

    fun hasPermission(device: UsbDevice): Boolean {
        return usbManager.hasPermission(device)
    }

    fun requestPermission(device: UsbDevice, callback: (Boolean) -> Unit) {
        val devName = device.productName ?: device.deviceName

        if (usbManager.hasPermission(device)) {
            Log.i(TAG, "Permission already granted for $devName")

            AudioTerminalLogger.log("Permission already granted for $devName")

            callback(true)

            return
        }

        AudioTerminalLogger.log("closeDevice() called. Current connection: $connection")

        AudioTerminalLogger.log("Requesting USB permission popup for $devName...")

        val intent = Intent(context.packageName + ACTION_USB_PERMISSION_SUFFIX)

        intent.setPackage(context.packageName)

        val permissionIntent = PendingIntent.getBroadcast(
                context, 0,
                intent,
                PendingIntent.FLAG_MUTABLE
        )

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (intent.action == context.packageName + ACTION_USB_PERMISSION_SUFFIX) {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)

                    Log.i(TAG, "USB permission result: granted=$granted for $devName")

                    AudioTerminalLogger.log("ACTION_USB_PERMISSION intent received. Extra device: $devName, granted: $granted")

                    if (granted) {
                        AudioTerminalLogger.log("Target audio device resolved: $devName (${device.deviceName})")

                        AudioTerminalLogger.log("Permission granted! Opening device $devName...")
                    }

                    try {
                        context.unregisterReceiver(this)
                    } catch (_: Exception) {}

                    callback(granted)
                }
            }
        }

        val filter = IntentFilter(context.packageName + ACTION_USB_PERMISSION_SUFFIX)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }

        usbManager.requestPermission(device, permissionIntent)

        Log.i(TAG, "Permission requested for $devName")
    }

    private var cachedDeviceInfo: UsbAudioDeviceInfo? = null

    fun openDevice(device: UsbDevice): UsbAudioDeviceInfo? {
        val cached = cachedDeviceInfo

        if (cached != null && connection != null) {
            Log.i(TAG, "Device already open, reusing fd=${cached.fd}")

            return cached
        }

        closeDevice()

        val devName = device.productName ?: device.deviceName

        AudioTerminalLogger.log("openDevice called for: $devName (interfaces: ${device.interfaceCount})")

        val conn = usbManager.openDevice(device)

        if (conn == null) {
            Log.e(TAG, "Failed to open device $devName")

            AudioTerminalLogger.log("Failed to open device $devName")

            return null
        }

        val fd = conn.fileDescriptor

        AudioTerminalLogger.log("usbManager.openDevice SUCCESS: FD=$fd")

        var streamingInterface: UsbInterface? = null

        var endpointOut = -1

        var endpointFeedback = -1

        var maxPacketSize = 0

        var altSettingCount = 0

        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)

            if (iface.interfaceClass == UsbConstants.USB_CLASS_AUDIO &&
                iface.interfaceSubclass == 2) {
                altSettingCount++
                if (iface.endpointCount > 0 && streamingInterface == null) {
                    streamingInterface = iface

                    for (e in 0 until iface.endpointCount) {
                        val ep = iface.getEndpoint(e)

                        when {
                            ep.type == UsbConstants.USB_ENDPOINT_XFER_ISOC &&
                                    ep.direction == UsbConstants.USB_DIR_OUT -> {
                                endpointOut = ep.address

                                maxPacketSize = ep.maxPacketSize

                                Log.i(TAG, "Found ISO OUT endpoint: address=0x${ep.address.toString(16)}, " +
                                        "maxPacket=$maxPacketSize, interval=${ep.interval}")
                            }

                            ep.type == UsbConstants.USB_ENDPOINT_XFER_ISOC &&
                                    ep.direction == UsbConstants.USB_DIR_IN -> {
                                endpointFeedback = ep.address

                                Log.i(TAG, "Found ISO IN (feedback) endpoint: address=0x${ep.address.toString(16)}, " +
                                        "interval=${ep.interval}")
                            }
                        }
                    }
                }
            }
        }

        if (streamingInterface == null || endpointOut < 0) {
            Log.e(TAG, "No suitable AudioStreaming interface/endpoint found")

            conn.close()

            return null
        }

        val controlInterface = (0 until device.interfaceCount)
                .map { device.getInterface(it) }
                .firstOrNull { it.interfaceClass == UsbConstants.USB_CLASS_AUDIO && it.interfaceSubclass == 1 }

        if (controlInterface != null) {
            val claimed = conn.claimInterface(controlInterface, true)

            Log.i(TAG, "Claimed AudioControl interface ${controlInterface.id} force=true: $claimed")

            AudioTerminalLogger.log("  Iface ${controlInterface.id} (cls=1 sub=1) claimInterface(force=true): $claimed")

            if (claimed) claimedControlInterface = controlInterface
        }

        val claimed = conn.claimInterface(streamingInterface, true)

        Log.i(TAG, "Claimed AudioStreaming interface ${streamingInterface.id} force=true: $claimed " +
                "(alt=${streamingInterface.alternateSetting}, endpoints=${streamingInterface.endpointCount})")

        AudioTerminalLogger.log("  Iface ${streamingInterface.id} (cls=1 sub=2) claimInterface(force=true): $claimed")

        if (!claimed) {
            Log.e(TAG, "Failed to claim streaming interface — kernel driver may still be active")

            claimedControlInterface?.let {
                try { conn.releaseInterface(it) } catch (_: Exception) {}
            }

            claimedControlInterface = null

            conn.close()

            return null
        }

        claimedStreamingInterface = streamingInterface

        claimedInterface = streamingInterface

        AudioTerminalLogger.log("Invoking onDeviceReady with FD $fd...")

        val zeroAlt = (0 until device.interfaceCount)
                .map { device.getInterface(it) }
                .firstOrNull { it.interfaceClass == UsbConstants.USB_CLASS_AUDIO &&
                        it.interfaceSubclass == 2 && it.alternateSetting == 0 }

        if (zeroAlt != null) {
            conn.setInterface(zeroAlt)

            Log.i(TAG, "Reset streaming to alt=0 (zero-bandwidth)")
        }

        Thread.sleep(100)

        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)

            if (iface.interfaceClass == UsbConstants.USB_CLASS_AUDIO && iface.interfaceSubclass == 2) {
                Log.d(TAG, "  AudioStreaming alt=${iface.alternateSetting}: " +
                        "id=${iface.id}, endpoints=${iface.endpointCount}")
            }
        }

        val interfaceId = streamingInterface.id

        Log.i(TAG, "Device opened: ${device.productName}, fd=$fd, " +
                "iface=$interfaceId, epOut=0x${endpointOut.toString(16)}, " +
                "epFb=0x${endpointFeedback.toString(16)}, " +
                "maxPacket=$maxPacketSize, altSettings=$altSettingCount")

        connection = conn

        currentDevice = device

        val clockSourceId = parseClockSourceId(conn)

        val (bestAlt, bestBits) = parseBestAltSetting(conn)

        val featureUnitId = parseFeatureUnitId(conn)

        Log.i(TAG, "Auto-detected: clockSourceId=0x${clockSourceId.toString(16)}, " +
                "bestAlt=$bestAlt, bestBits=$bestBits, featureUnitId=0x${featureUnitId.toString(16)}")

        val info = UsbAudioDeviceInfo(
                connection = conn,
                fd = fd,
                deviceName = device.productName ?: "USB Audio Device",
                interfaceId = interfaceId,
                endpointOutAddress = endpointOut,
                endpointFeedbackAddress = endpointFeedback,
                maxPacketSize = maxPacketSize,
                altSettingCount = altSettingCount,
                clockSourceId = clockSourceId,
                bestAltSetting = bestAlt,
                bestBitDepth = bestBits,
                featureUnitId = featureUnitId,
                audioControlInterfaceId = controlInterface?.id ?: 0
        )

        cachedDeviceInfo = info

        return info
    }

    fun resetAndReopen() {
        val conn = connection ?: return

        val fd = conn.fileDescriptor

        Log.i(TAG, "Performing REAL USBDEVFS_RESET on fd=$fd...")

        val ret = UsbAudioStream.nativeUsbReset(fd)

        Log.i(TAG, "USBDEVFS_RESET result: $ret")

        cachedDeviceInfo = null

        claimedInterface = null

        claimedStreamingInterface = null

        claimedControlInterface = null
    }

    private fun parseClockSourceId(conn: UsbDeviceConnection): Int {
        val raw = conn.rawDescriptors ?: return -1

        var i = 0

        var inAudioControl = false

        while (i + 1 < raw.size) {
            val bLength = raw[i].toInt() and 0xFF

            if (bLength < 2) break

            if (i + bLength > raw.size) break

            val bDescriptorType = raw[i + 1].toInt() and 0xFF

            if (bDescriptorType == 0x04 && bLength >= 9) {
                val bInterfaceClass = raw[i + 5].toInt() and 0xFF

                val bInterfaceSubClass = raw[i + 6].toInt() and 0xFF

                inAudioControl = (bInterfaceClass == 1 && bInterfaceSubClass == 1)
            }

            if (inAudioControl && bDescriptorType == 0x24 && bLength >= 3) {
                val bDescriptorSubtype = raw[i + 2].toInt() and 0xFF

                if (bDescriptorSubtype == 0x0A && bLength >= 5) {
                    val bClockID = raw[i + 3].toInt() and 0xFF

                    Log.i(TAG, "parseClockSourceId: found CLOCK_SOURCE bClockID=0x${bClockID.toString(16)}")

                    return bClockID
                }
            }

            i += bLength
        }

        Log.w(TAG, "parseClockSourceId: no CLOCK_SOURCE descriptor found")

        return -1
    }

    private fun parseFeatureUnitId(conn: UsbDeviceConnection): Int {
        val raw = conn.rawDescriptors ?: return -1

        var i = 0

        var inAudioControl = false

        var isUac2 = false

        while (i + 1 < raw.size) {
            val bLength = raw[i].toInt() and 0xFF

            if (bLength < 2 || i + bLength > raw.size) break

            val bDescriptorType = raw[i + 1].toInt() and 0xFF

            if (bDescriptorType == 0x04 && bLength >= 9) {
                val bInterfaceClass = raw[i + 5].toInt() and 0xFF

                val bInterfaceSubClass = raw[i + 6].toInt() and 0xFF

                inAudioControl = (bInterfaceClass == 1 && bInterfaceSubClass == 1)
            }

            if (inAudioControl && bDescriptorType == 0x24 && bLength >= 6) {
                val bDescriptorSubtype = raw[i + 2].toInt() and 0xFF

                if (bDescriptorSubtype == 0x01 && bLength >= 5) {
                    val bcdADC = (raw[i + 3].toInt() and 0xFF) or ((raw[i + 4].toInt() and 0xFF) shl 8)

                    isUac2 = (bcdADC >= 0x0200)
                } else if (bDescriptorSubtype == 0x06) {
                    val unitId = raw[i + 3].toInt() and 0xFF

                    var hasVolume = false

                    if (isUac2) {
                        if (bLength >= 9) {
                            val masterControls = raw[i + 5].toInt() and 0xFF

                            if ((masterControls and 0x0C) != 0) {
                                hasVolume = true
                            } else if (bLength >= 13) {
                                val ch1Controls = raw[i + 9].toInt() and 0xFF

                                if ((ch1Controls and 0x0C) != 0) hasVolume = true
                            }
                        }
                    } else {
                        val bControlSize = raw[i + 5].toInt() and 0xFF

                        if (bLength >= 6 + bControlSize && bControlSize > 0) {
                            val masterControls = raw[i + 6].toInt() and 0xFF

                            if ((masterControls and 0x02) != 0) {
                                hasVolume = true
                            } else if (bLength >= 6 + (bControlSize * 2)) {
                                val ch1Controls = raw[i + 6 + bControlSize].toInt() and 0xFF

                                if ((ch1Controls and 0x02) != 0) hasVolume = true
                            }
                        }
                    }

                    if (hasVolume) {
                        Log.i(TAG, "parseFeatureUnitId: found Feature Unit 0x${unitId.toString(16)} with volume support (uac2=$isUac2)")

                        return unitId
                    }
                }
            }

            i += bLength
        }

        Log.d(TAG, "parseFeatureUnitId: no Feature Unit with volume support found")

        return -1
    }

    private var parsedAltSettings: List<Pair<Int, Int>> = emptyList()

    private fun parseBestAltSetting(conn: UsbDeviceConnection): Pair<Int, Int> {
        val raw = conn.rawDescriptors ?: return Pair(1, 16)

        val altSettings = mutableListOf<Pair<Int, Int>>()

        var i = 0

        var currentAlt = 0

        var inAudioStreaming = false

        var bestAlt = 1

        var bestBits = 16

        while (i + 1 < raw.size) {
            val bLength = raw[i].toInt() and 0xFF

            if (bLength < 2) break

            if (i + bLength > raw.size) break

            val bDescriptorType = raw[i + 1].toInt() and 0xFF

            if (bDescriptorType == 0x04 && bLength >= 9) {
                val bInterfaceClass = raw[i + 5].toInt() and 0xFF

                val bInterfaceSubClass = raw[i + 6].toInt() and 0xFF

                val bAlternateSetting = raw[i + 3].toInt() and 0xFF

                inAudioStreaming = (bInterfaceClass == 1 && bInterfaceSubClass == 2)

                if (inAudioStreaming) currentAlt = bAlternateSetting
            }

            if (inAudioStreaming && bDescriptorType == 0x24 && bLength >= 6) {
                val bDescriptorSubtype = raw[i + 2].toInt() and 0xFF

                if (bDescriptorSubtype == 0x02) {
                    val bSubslotSize = raw[i + 4].toInt() and 0xFF

                    val bBitResolution = raw[i + 5].toInt() and 0xFF

                    Log.i(TAG, "parseBestAltSetting: alt=$currentAlt subslotSize=$bSubslotSize bitResolution=$bBitResolution")

                    if (currentAlt > 0) {
                        altSettings.add(Pair(currentAlt, bBitResolution))
                    }

                    if (bBitResolution > bestBits && currentAlt > 0) {
                        bestBits = bBitResolution

                        bestAlt = currentAlt
                    }
                }
            }

            i += bLength
        }

        parsedAltSettings = altSettings

        Log.i(TAG, "parseBestAltSetting: best alt=$bestAlt bits=$bestBits, all=$altSettings")

        return Pair(bestAlt, bestBits)
    }

    fun findAltSettingForBitDepth(targetBitDepth: Int): Pair<Int, Int> {
        if (parsedAltSettings.isEmpty()) {
            val info = cachedDeviceInfo ?: return Pair(1, 16)

            return Pair(info.bestAltSetting, info.bestBitDepth)
        }

        val exact = parsedAltSettings.firstOrNull { it.second == targetBitDepth }

        if (exact != null) {
            Log.i(TAG, "findAltSettingForBitDepth($targetBitDepth): exact match alt=${exact.first}")

            return exact
        }

        val higher = parsedAltSettings
                .filter { it.second > targetBitDepth }
                .minByOrNull { it.second }

        if (higher != null) {
            Log.i(TAG, "findAltSettingForBitDepth($targetBitDepth): next higher alt=${higher.first} bits=${higher.second}")

            return higher
        }

        val best = parsedAltSettings.maxByOrNull { it.second } ?: Pair(1, 16)

        Log.i(TAG, "findAltSettingForBitDepth($targetBitDepth): fallback to best alt=${best.first} bits=${best.second}")

        return best
    }

    fun closeDevice() = synchronized(deviceLock) {
        cachedDeviceInfo = null

        claimedStreamingInterface?.let { iface ->
            try { connection?.releaseInterface(iface) } catch (_: Exception) {}

            claimedStreamingInterface = null
        }

        claimedInterface = null

        claimedControlInterface?.let { iface ->
            try { connection?.releaseInterface(iface) } catch (_: Exception) {}

            claimedControlInterface = null
        }

        try { connection?.close() } catch (_: Exception) {}

        connection = null

        currentDevice = null

        Log.i(TAG, "USB device closed and all interfaces released")
    }

    fun hasHardwareVolumeSupport(): Boolean {
        val info = cachedDeviceInfo ?: return false

        return info.featureUnitId > 0
    }

    fun setHardwareVolume(volumeRatio: Float): Boolean = synchronized(deviceLock) {
        val conn = connection ?: run {
            Log.w(TAG, "setHardwareVolume: connection is null")

            return false
        }

        val info = cachedDeviceInfo ?: run {
            Log.w(TAG, "setHardwareVolume: cachedDeviceInfo is null")

            return false
        }

        val fuId = info.featureUnitId

        if (fuId <= 0) {
            Log.w(TAG, "setHardwareVolume: no valid Feature Unit with volume support")

            return false
        }

        val clampedVol = volumeRatio.coerceIn(0f, 1f)

        val val16: Short = if (clampedVol <= 0.0001f) {
            (-24576).toShort()
        } else {
            val db = (20.0 * kotlin.math.log10(clampedVol.toDouble())).coerceIn(-96.0, 0.0)

            (db * 256.0).toInt().toShort()
        }

        val data = ByteArray(2)

        data[0] = (val16.toInt() and 0xFF).toByte()

        data[1] = ((val16.toInt() shr 8) and 0xFF).toByte()

        val ctrlIface = info.audioControlInterfaceId

        val wIndex = (fuId shl 8) or (ctrlIface and 0xFF)

        val ret = conn.controlTransfer(
            0x21,
            0x01,
            0x0200,
            wIndex,
            data,
            data.size,
            250
        )

        if (ret == data.size) {
            Log.i(TAG, "setHardwareVolume($clampedVol): SUCCESS master channel (ret=$ret, dB=${val16.toFloat() / 256f})")

            return true
        }

        val ret1 = conn.controlTransfer(0x21, 0x01, 0x0201, wIndex, data, data.size, 250)

        val ret2 = conn.controlTransfer(0x21, 0x01, 0x0202, wIndex, data, data.size, 250)

        if (ret1 == data.size && ret2 == data.size) {
            Log.i(TAG, "setHardwareVolume($clampedVol): SUCCESS ch1/ch2 (ret1=$ret1, ret2=$ret2, dB=${val16.toFloat() / 256f})")

            return true
        }

        Log.w(TAG, "setHardwareVolume($clampedVol) failed for featureUnitId=0x${fuId.toString(16)} (master ret=$ret, ch1=$ret1, ch2=$ret2, expected=${data.size})")

        return false
    }

    fun setSampleRate(sampleRateHz: Int): Boolean {
        val conn = connection ?: return false

        val data = ByteArray(4)

        data[0] = (sampleRateHz and 0xFF).toByte()

        data[1] = ((sampleRateHz shr 8) and 0xFF).toByte()

        data[2] = ((sampleRateHz shr 16) and 0xFF).toByte()

        data[3] = ((sampleRateHz shr 24) and 0xFF).toByte()

        val detectedId = cachedDeviceInfo?.clockSourceId ?: -1

        val clockSourceIds = if (detectedId > 0) {
            intArrayOf(detectedId)
        } else {
            intArrayOf(0x05, 0x09, 0x0A, 0x0B, 0x0C, 0x0D,
                    0x28, 0x29, 0x2A, 0x06, 0x07, 0x08,
                    0x10, 0x11, 0x12, 0x20, 0x21, 0x22)
        }

        for (csId in clockSourceIds) {
            val wIndex = (csId shl 8) or 0

            val ret = conn.controlTransfer(
                    0x21,
                    0x01,
                    0x0100,
                    wIndex,
                    data,
                    data.size,
                    1000
            )

            if (ret >= 0) {
                Log.i(TAG, "setSampleRate($sampleRateHz Hz): SUCCESS with clockSourceId=0x${csId.toString(16)} (wIndex=0x${wIndex.toString(16)}, ret=$ret)")

                return true
            }
        }

        Log.w(TAG, "setSampleRate($sampleRateHz Hz): all clock source IDs failed, DAC may auto-detect")

        return false
    }

    fun readSampleRate(): Int {
        val conn = connection ?: return -1

        val data = ByteArray(4)

        val detectedId = cachedDeviceInfo?.clockSourceId ?: -1

        val clockSourceIds = if (detectedId > 0) intArrayOf(detectedId)

                else intArrayOf(0x05, 0x09, 0x0A, 0x0B, 0x0C, 0x28, 0x29)

        for (csId in clockSourceIds) {
            val wIndex = (csId shl 8) or 0

            val ret = conn.controlTransfer(
                    0xA1,
                    0x01,
                    0x0100,
                    wIndex,
                    data,
                    data.size,
                    1000
            )

            if (ret >= 4) {
                val rate = (data[0].toInt() and 0xFF) or

                        ((data[1].toInt() and 0xFF) shl 8) or

                        ((data[2].toInt() and 0xFF) shl 16) or

                        ((data[3].toInt() and 0xFF) shl 24)

                Log.i(TAG, "readSampleRate: GET_CUR clockSourceId=0x${csId.toString(16)} " +
                        "returned $rate Hz (raw=${data.joinToString(",") { "0x${(it.toInt() and 0xFF).toString(16)}" }})")

                return rate
            }
        }

        Log.w(TAG, "readSampleRate: all GET_CUR attempts failed")

        return -1
    }

    fun readClockValid(): Boolean {
        val conn = connection ?: return false

        val data = ByteArray(1)

        val detectedId = cachedDeviceInfo?.clockSourceId ?: -1

        val clockSourceIds = if (detectedId > 0) intArrayOf(detectedId)

                else intArrayOf(0x05, 0x09, 0x0A, 0x0B, 0x0C, 0x28, 0x29)

        for (csId in clockSourceIds) {
            val wIndex = (csId shl 8) or 0

            val ret = conn.controlTransfer(
                    0xA1,
                    0x01,
                    0x0200,
                    wIndex,
                    data,
                    data.size,
                    1000
            )

            if (ret >= 1) {
                val valid = data[0].toInt() and 0x01

                Log.i(TAG, "readClockValid: clockSourceId=0x${csId.toString(16)} valid=$valid")

                return valid == 1
            }
        }

        Log.w(TAG, "readClockValid: all GET_CUR attempts failed")

        return false
    }

    fun setAltSetting(altSetting: Int): Boolean {
        val conn = connection ?: return false

        val device = currentDevice ?: return false

        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)

            if (iface.interfaceClass == UsbConstants.USB_CLASS_AUDIO &&
                iface.interfaceSubclass == 2 &&
                iface.alternateSetting == altSetting) {
                val result = conn.setInterface(iface)

                Log.i(TAG, "setAltSetting($altSetting): $result " +
                        "(iface id=${iface.id}, endpoints=${iface.endpointCount})")

                return result
            }
        }

        Log.w(TAG, "setAltSetting($altSetting): no matching UsbInterface found, " +
                "trying all AudioStreaming interfaces...")

        for (i in 0 until device.interfaceCount) {
            val iface = device.getInterface(i)

            if (iface.interfaceClass == UsbConstants.USB_CLASS_AUDIO &&
                iface.interfaceSubclass == 2) {
                Log.d(TAG, "  interface $i: id=${iface.id} alt=${iface.alternateSetting} " +
                        "endpoints=${iface.endpointCount}")
            }
        }

        return false
    }
}
