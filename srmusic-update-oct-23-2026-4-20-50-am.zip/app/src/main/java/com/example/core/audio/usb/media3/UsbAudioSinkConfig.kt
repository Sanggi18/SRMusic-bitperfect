package com.example.core.audio.usb.media3

import com.example.core.audio.dac.DacVolumeMode

data class UsbAudioSinkConfig(
    val bitPerfectEnabled: Boolean = true,
    val forceRouteToSpeaker: Boolean = true,
    val dacVolumeMode: DacVolumeMode = DacVolumeMode.SOFTWARE,
    val dacExclusiveUsb: Boolean = true
)
