package com.example.core.data.mediastore.tags

object GenreUtils {
    fun isValidGenre(genre: String?): Boolean {
        if (genre.isNullOrBlank()) return false

        val lower = genre.trim().lowercase()

        return lower != "<unknown>" &&
            lower != "unknown" &&
            lower != "unknown genre" &&
            genre.trim().length in 2..50
    }

    fun cleanGenre(genre: String): String {
        return genre.trim().trim('"', '\'', ';', '/', '\\', '\u0000').trim()
    }
}
