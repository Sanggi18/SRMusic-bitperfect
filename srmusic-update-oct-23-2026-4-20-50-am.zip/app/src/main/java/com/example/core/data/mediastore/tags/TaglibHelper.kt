package com.example.core.data.mediastore.tags

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.LruCache
import com.example.core.data.database.AppDatabase
import com.example.core.data.database.song.SongEntity
import com.example.core.model.Song
import com.kyant.taglib.TagLib
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.HashMap
import java.util.Locale

data class AudioStreamProps(
    val format: String,
    val sampleRateHz: Int?,
    val bitrateKbps: Int?,
    val bitDepth: Int? = null
) {
    fun formatSampleRate(): String? {
        val hz = sampleRateHz ?: return null

        val khz = hz / 1000.0

        return if (khz % 1.0 == 0.0) {
            "${khz.toInt()} kHz"
        } else {
            String.format(Locale.US, "%.1f kHz", khz)
        }
    }
}

data class SongMetadata(
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val year: String = "",
    val trackNumber: String = "",
    val discNumber: String = "",
    val genre: String = "",
    val albumArtist: String = "",
    val composer: String = "",
    val copyright: String = "",
    val lyrics: String = "",
    val artworkWidth: Int = 0,
    val artworkHeight: Int = 0,
    val artworkSizeBytes: Long = 0L
) {
    val formattedDimensions: String
        get() = if (artworkWidth > 0 && artworkHeight > 0) "${artworkWidth} × ${artworkHeight}" else "No Artwork"

    val formattedArtworkSize: String
        get() = when {
            artworkSizeBytes <= 0L -> "—"
            artworkSizeBytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", artworkSizeBytes / 1024.0)
            else -> String.format(Locale.US, "%.2f MB", artworkSizeBytes / (1024.0 * 1024.0))
        }
}

object TaglibHelper {
    fun getPropertyMap(file: File): Map<String, Array<String>>? {
        return try {
            if (!file.exists() || !file.canRead()) return null

            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                TagLib.getMetadata(pfd.dup().detachFd())?.propertyMap
            }
        } catch (_: Exception) {
            null
        }
    }

    fun getFirstProperty(file: File, vararg keys: String): String? {
        val map = getPropertyMap(file) ?: return null

        for (targetKey in keys) {
            val direct = map[targetKey]?.firstOrNull()?.takeIf { it.isNotBlank() }

            if (direct != null) return direct

            val caseInsensitive = map.entries
                .firstOrNull { it.key.equals(targetKey, ignoreCase = true) }
                ?.value
                ?.firstOrNull()
                ?.takeIf { it.isNotBlank() }

            if (caseInsensitive != null) return caseInsensitive
        }

        return null
    }

    fun getLyrics(file: File): String? {
        return getFirstProperty(
            file,
            "LYRICS",
            "UNSYNCEDLYRICS",
            "UNSYNCED LYRICS",
            "SYLT",
            "©lyr"
        )
    }

    fun getArtworkBytes(file: File): ByteArray? {
        return try {
            if (!file.exists() || !file.canRead()) return null

            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
                TagLib.getPictures(pfd.dup().detachFd())
                    .firstOrNull()?.data
                    ?.takeIf { it.isNotEmpty() }
            }
        } catch (_: Exception) {
            null
        }
    }

    fun getSongMetadata(context: Context, song: Song): SongMetadata {
        var title = song.title
        var artist = song.artist
        var album = song.album
        var year = song.year?.toString() ?: ""
        var trackNumber = song.trackNumber?.toString() ?: ""
        var discNumber = ""
        var genre = song.genre ?: ""
        var albumArtist = ""
        var composer = ""
        var copyright = ""
        var lyrics = ""
        var artworkWidth = 0
        var artworkHeight = 0
        var artworkSizeBytes = 0L

        val file = song.dataPath?.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() && it.canRead() }
        val pfd = try {
            if (file != null) {
                ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            } else if (song.contentUri != android.net.Uri.EMPTY) {
                context.contentResolver.openFileDescriptor(song.contentUri, "r")
            } else null
        } catch (_: Exception) {
            null
        }

        pfd?.use { descriptor ->
            try {
                val metadata = TagLib.getMetadata(descriptor.dup().detachFd())
                val map = metadata?.propertyMap
                if (map != null) {
                    fun getVal(vararg keys: String): String {
                        for (k in keys) {
                            map[k]?.firstOrNull()?.takeIf { it.isNotBlank() }?.let { return it }
                            map.entries.firstOrNull { it.key.equals(k, ignoreCase = true) }?.value?.firstOrNull()?.takeIf { it.isNotBlank() }?.let { return it }
                        }
                        return ""
                    }
                    val t = getVal("TITLE")
                    if (t.isNotBlank()) title = t
                    val a = getVal("ARTIST")
                    if (a.isNotBlank()) artist = a
                    val al = getVal("ALBUM")
                    if (al.isNotBlank()) album = al
                    val y = getVal("DATE", "YEAR")
                    if (y.isNotBlank()) year = y
                    val tr = getVal("TRACKNUMBER")
                    if (tr.isNotBlank()) trackNumber = tr
                    val dn = getVal("DISCNUMBER")
                    if (dn.isNotBlank()) discNumber = dn
                    val g = getVal("GENRE")
                    if (g.isNotBlank()) genre = g
                    val aa = getVal("ALBUMARTIST", "ALBUM ARTIST")
                    if (aa.isNotBlank()) albumArtist = aa
                    val comp = getVal("COMPOSER")
                    if (comp.isNotBlank()) composer = comp
                    val cpr = getVal("COPYRIGHT")
                    if (cpr.isNotBlank()) copyright = cpr
                    val lyr = getVal("LYRICS", "UNSYNCEDLYRICS", "UNSYNCED LYRICS", "SYLT", "©lyr")
                    if (lyr.isNotBlank()) lyrics = lyr
                }

                val pics = metadata?.pictures
                val pic = pics?.firstOrNull()
                if (pic != null && pic.data.isNotEmpty()) {
                    val data = pic.data
                    artworkSizeBytes = data.size.toLong()
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(data, 0, data.size, opts)
                    artworkWidth = opts.outWidth
                    artworkHeight = opts.outHeight
                }
            } catch (_: Exception) {
            }
        }

        if (artworkWidth <= 0 || artworkHeight <= 0) {
            try {
                val uriToUse = if (song.artworkUri != android.net.Uri.EMPTY) song.artworkUri else song.contentUri
                if (uriToUse != android.net.Uri.EMPTY) {
                    context.contentResolver.openInputStream(uriToUse)?.use { input ->
                        val bytes = input.readBytes()
                        if (bytes.isNotEmpty()) {
                            artworkSizeBytes = bytes.size.toLong()
                            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                            artworkWidth = opts.outWidth
                            artworkHeight = opts.outHeight
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        return SongMetadata(
            title = title,
            artist = artist,
            album = album,
            year = year,
            trackNumber = trackNumber,
            discNumber = discNumber,
            genre = genre,
            albumArtist = albumArtist,
            composer = composer,
            copyright = copyright,
            lyrics = lyrics,
            artworkWidth = artworkWidth,
            artworkHeight = artworkHeight,
            artworkSizeBytes = artworkSizeBytes
        )
    }

    suspend fun saveSongMetadata(
        context: Context,
        song: Song,
        newMetadata: SongMetadata
    ): Boolean {
        return withContext(Dispatchers.IO) {
            var fileSaved = false
            try {
                val file = song.dataPath?.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() }
                val pfd = if (file != null && file.canWrite()) {
                    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_WRITE)
                } else if (song.contentUri != android.net.Uri.EMPTY) {
                    try {
                        context.contentResolver.openFileDescriptor(song.contentUri, "rw")
                    } catch (_: Exception) {
                        null
                    }
                } else null

                pfd?.use { descriptor ->
                    val fd = descriptor.dup().detachFd()
                    val existingMeta = TagLib.getMetadata(fd)
                    val map = existingMeta?.propertyMap ?: HashMap<String, Array<String>>()
                    map["TITLE"] = arrayOf(newMetadata.title)
                    map["ARTIST"] = arrayOf(newMetadata.artist)
                    map["ALBUM"] = arrayOf(newMetadata.album)
                    if (newMetadata.year.isNotBlank()) map["DATE"] = arrayOf(newMetadata.year)
                    if (newMetadata.trackNumber.isNotBlank()) map["TRACKNUMBER"] = arrayOf(newMetadata.trackNumber)
                    if (newMetadata.discNumber.isNotBlank()) map["DISCNUMBER"] = arrayOf(newMetadata.discNumber)
                    if (newMetadata.genre.isNotBlank()) map["GENRE"] = arrayOf(newMetadata.genre)
                    if (newMetadata.albumArtist.isNotBlank()) map["ALBUMARTIST"] = arrayOf(newMetadata.albumArtist)
                    if (newMetadata.composer.isNotBlank()) map["COMPOSER"] = arrayOf(newMetadata.composer)
                    if (newMetadata.copyright.isNotBlank()) map["COPYRIGHT"] = arrayOf(newMetadata.copyright)
                    if (newMetadata.lyrics.isNotBlank()) {
                        map["LYRICS"] = arrayOf(newMetadata.lyrics)
                        map["UNSYNCEDLYRICS"] = arrayOf(newMetadata.lyrics)
                    }
                    fileSaved = TagLib.savePropertyMap(fd, map)
                }
            } catch (_: Exception) {
            }

            try {
                val updatedEntity = SongEntity(
                    id = song.id,
                    title = newMetadata.title.ifBlank { song.title },
                    artist = newMetadata.artist.ifBlank { song.artist },
                    album = newMetadata.album.ifBlank { song.album },
                    duration = song.duration,
                    albumId = song.albumId,
                    contentUriString = song.contentUri.toString(),
                    artworkUriString = song.artworkUri.toString(),
                    trackNumber = newMetadata.trackNumber.toIntOrNull() ?: song.trackNumber,
                    year = newMetadata.year.toIntOrNull() ?: song.year,
                    size = song.size,
                    displayName = song.displayName,
                    relativePath = song.relativePath,
                    dataPath = song.dataPath,
                    dateAdded = song.dateAdded,
                    dateModified = System.currentTimeMillis(),
                    genre = newMetadata.genre.ifBlank { song.genre }
                )
                AppDatabase.getInstance(context).songDao().upsertSongs(listOf(updatedEntity))
            } catch (_: Exception) {
            }

            true
        }
    }

    private val streamPropsCache = LruCache<Long, AudioStreamProps>(64)

    fun getAudioStreamProps(song: Song, context: Context): AudioStreamProps {
        streamPropsCache.get(song.id)?.let { return it }

        var sampleRate: Int? = null

        var bitrate: Int? = null

        var format = song.displayName?.let { dn ->
            if (dn.contains('.')) dn.substringAfterLast('.').uppercase() else null
        } ?: song.dataPath?.let { dp ->
            if (dp.contains('.')) dp.substringAfterLast('.').uppercase() else null
        } ?: "MP3"

        if (format.contains("AAC", ignoreCase = true) || format.contains("MP4", ignoreCase = true)) {
            format = "M4A"
        }

        val retriever = MediaMetadataRetriever()

        try {
            val dp = song.dataPath

            if (!dp.isNullOrBlank() && File(dp).exists()) {
                retriever.setDataSource(dp)
            } else if (song.contentUri != android.net.Uri.EMPTY) {
                retriever.setDataSource(context, song.contentUri)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                sampleRate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)?.toIntOrNull()
            }

            bitrate = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull()?.let { it / 1000 }
            val mime = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            if (mime?.contains("alac", ignoreCase = true) == true) {
                format = "ALAC"
            }
        } catch (_: Exception) {
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }

        if (bitrate == null && song.duration > 0 && (song.size ?: 0L) > 0) {
            bitrate = (((song.size ?: 0L) * 8) / song.duration).toInt()
        }

        var bitDepth: Int? = null

        try {
            val fileToRead = song.dataPath?.takeIf { it.isNotBlank() }?.let { File(it) }?.takeIf { it.exists() && it.canRead() }

            val inputStream = fileToRead?.inputStream() ?: if (song.contentUri != android.net.Uri.EMPTY) {
                context.contentResolver.openInputStream(song.contentUri)
            } else null

            inputStream?.use { stream ->
                val buffer = ByteArray(32768)
                val readBytes = stream.read(buffer)

                if (readBytes >= 26 && buffer[0] == 'f'.code.toByte() && buffer[1] == 'L'.code.toByte() && buffer[2] == 'a'.code.toByte() && buffer[3] == 'C'.code.toByte()) {
                    val b20 = buffer[20].toInt() and 0xFF
                    val b21 = buffer[21].toInt() and 0xFF
                    val flacBits = (((b20 and 0x01) shl 4) or ((b21 and 0xF0) ushr 4)) + 1
                    if (flacBits in 8..32) {
                        bitDepth = flacBits
                    }
                } else if (readBytes >= 36 && buffer[0] == 'R'.code.toByte() && buffer[1] == 'I'.code.toByte() && buffer[2] == 'F'.code.toByte() && buffer[3] == 'F'.code.toByte()) {
                    val wavBits = (buffer[34].toInt() and 0xFF) or ((buffer[35].toInt() and 0xFF) shl 8)
                    if (wavBits in 8..32) {
                        bitDepth = wavBits
                    }
                } else if (readBytes > 40 && (format == "M4A" || format == "ALAC")) {
                    // Check for ALAC atom in MP4 / M4A container
                    for (i in 0 until readBytes - 36) {
                        if (buffer[i] == 'a'.code.toByte() && buffer[i + 1] == 'l'.code.toByte() &&
                            buffer[i + 2] == 'a'.code.toByte() && buffer[i + 3] == 'c'.code.toByte()
                        ) {
                            format = "ALAC"
                            val bd = buffer[i + 17].toInt() and 0xFF
                            if (bd in 8..32) {
                                bitDepth = bd
                            }
                            if (sampleRate == null || sampleRate == 0) {
                                val sr = ((buffer[i + 32].toInt() and 0xFF) shl 24) or
                                        ((buffer[i + 33].toInt() and 0xFF) shl 16) or
                                        ((buffer[i + 34].toInt() and 0xFF) shl 8) or
                                        (buffer[i + 35].toInt() and 0xFF)
                                if (sr in 8000..384000) {
                                    sampleRate = sr
                                }
                            }
                            break
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        if (bitDepth == null) {
            bitDepth = when (format) {
                "FLAC", "WAV", "ALAC", "AIFF" -> 16

                else -> 16
            }
        }

        val result = AudioStreamProps(
            format = format,
            sampleRateHz = sampleRate,
            bitrateKbps = bitrate,
            bitDepth = bitDepth
        )

        streamPropsCache.put(song.id, result)

        return result
    }
}
