package com.example.ui.common

enum class ArtworkShape {
    ROUNDED_SQUARE,
    CIRCLE
}

enum class ArtworkPlaceholderType {
    MUSIC,
    ARTIST,
    ALBUM,
    FOLDER,
    AUDIO_FILE
}

enum class YearSortOrder {
    DESCENDING,
    ASCENDING
}

enum class ItemPosition {
    TOP,
    MIDDLE,
    BOTTOM,
    SINGLE
}
