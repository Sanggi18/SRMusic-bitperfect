package com.example.ui.common.components

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.Size
import com.kyant.taglib.TagLib
import com.example.core.data.mediastore.tags.TaglibHelper
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.common.ArtworkPlaceholderType
import androidx.collection.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val artworkBitmapCache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
}

private val missingArtworkKeys = java.util.Collections.synchronizedSet(
    object : LinkedHashSet<String>() {
        override fun add(element: String): Boolean {
            if (size >= 1000) {
                val it = iterator()

                if (it.hasNext()) {
                    it.next()

                    it.remove()
                }
            }

            return super.add(element)
        }
    }
)

@Composable
fun AlbumArtwork(
    artworkUri: Uri? = null,
    fallbackUri: Uri? = null,
    dataPath: String? = null,
    imageFile: File? = null,
    fallbackText: String = "",
    contentDescription: String? = null,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    targetSizePx: Int? = null,
    shape: Shape = RoundedCornerShape(12.dp),
    placeholderType: ArtworkPlaceholderType = ArtworkPlaceholderType.MUSIC,
    topCrop: Boolean = false,
    onLoadingChange: ((Boolean) -> Unit)? = null,
) {
    val context = LocalContext.current

    val density = LocalDensity.current

    val px = remember(density, size, targetSizePx) {
        (targetSizePx ?: with(density) { size.roundToPx() }).coerceIn(1, 1024)
    }

    val placeholderIcon: ImageVector = remember(placeholderType) {
        when (placeholderType) {
            ArtworkPlaceholderType.MUSIC -> Icons.Rounded.MusicNote

            ArtworkPlaceholderType.ARTIST -> Icons.Rounded.Person

            ArtworkPlaceholderType.ALBUM -> Icons.Rounded.Album

            ArtworkPlaceholderType.FOLDER -> Icons.Rounded.Folder

            ArtworkPlaceholderType.AUDIO_FILE -> Icons.Rounded.AudioFile
        }
    }

    val srcKey = remember(artworkUri, fallbackUri, dataPath, imageFile?.absolutePath) {
        dataPath ?: artworkUri?.toString() ?: fallbackUri?.toString() ?: imageFile?.absolutePath
    }

    val cacheKey = remember(srcKey, px) {
        if (srcKey != null) "${srcKey}_$px" else null
    }

    val cachedBitmap = remember(cacheKey) {
        if (cacheKey != null) artworkBitmapCache.get(cacheKey)?.asImageBitmap() else null
    }

    val bitmap by produceState<ImageBitmap?>(
        initialValue = cachedBitmap,
        artworkUri, fallbackUri, dataPath, imageFile, px, cacheKey
    ) {
        if (cacheKey != null) {
            val memBmp = artworkBitmapCache.get(cacheKey)

            if (memBmp != null) {
                value = memBmp.asImageBitmap()

                return@produceState
            }
        }

        if (srcKey == null || missingArtworkKeys.contains(srcKey)) {
            value = null

            return@produceState
        }

        if (artworkUri == null && fallbackUri == null && dataPath.isNullOrBlank() && (imageFile == null || !imageFile.exists())) {
            value = null

            return@produceState
        }

        onLoadingChange?.invoke(true)

        val loaded = withContext(Dispatchers.IO) {
            runCatching {
                var decoded: Bitmap? = null

                val storeKey = dataPath ?: artworkUri?.toString() ?: fallbackUri?.toString()
                if (storeKey != null && getNoArtworkMarkerFile(context, storeKey).exists()) {
                    missingArtworkKeys.add(srcKey)
                    return@runCatching null
                }

                val storeFile = storeKey?.let { getArtworkStoreFile(context, it) }

                if (storeFile != null && storeFile.exists() && storeFile.length() > 0) {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(storeFile.absolutePath, bounds)
                    if (bounds.outWidth >= 400 || bounds.outHeight >= 400) {
                        decoded = decodeSampledFile(storeFile, px)
                    } else {
                        storeFile.delete()
                    }
                }

                if (decoded == null && artworkUri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val reqThumbSize = maxOf(px * 2, 512)
                    val thumb = runCatching {
                        context.contentResolver.loadThumbnail(artworkUri, Size(reqThumbSize, reqThumbSize), null)
                    }.getOrNull()
                    if (thumb != null) {
                        decoded = thumb
                        if (storeFile != null && (thumb.width >= 400 || thumb.height >= 400)) {
                            saveArtworkToDisk(thumb, storeFile)
                        }
                    }
                }
                if (decoded == null && fallbackUri != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val reqThumbSize = maxOf(px * 2, 512)
                    val thumb = runCatching {
                        context.contentResolver.loadThumbnail(fallbackUri, Size(reqThumbSize, reqThumbSize), null)
                    }.getOrNull()
                    if (thumb != null) {
                        decoded = thumb
                        if (storeFile != null && (thumb.width >= 400 || thumb.height >= 400)) {
                            saveArtworkToDisk(thumb, storeFile)
                        }
                    }
                }

                if (decoded == null) {
                    decoded = extractMasterEmbeddedArtwork(context, dataPath, artworkUri ?: fallbackUri, px, storeKey)
                }

                if (decoded == null && imageFile != null && imageFile.exists()) {
                    decoded = decodeSampledFile(imageFile, px)
                }

                if (decoded != null && cacheKey != null) {
                    artworkBitmapCache.put(cacheKey, decoded)
                } else if (decoded == null && srcKey != null) {
                    missingArtworkKeys.add(srcKey)
                    if (storeKey != null) {
                        runCatching { getNoArtworkMarkerFile(context, storeKey).createNewFile() }
                    }
                }

                decoded
            }.getOrNull()
        }

        value = loaded?.asImageBitmap()

        onLoadingChange?.invoke(false)
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(MaterialTheme.colorScheme.surfaceContainerHighest),
        contentAlignment = Alignment.Center,
    ) {
        val bmp = bitmap

        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = contentDescription,
                modifier = Modifier.fillMaxSize(),
                alignment = if (topCrop) Alignment.TopCenter else Alignment.Center,
                contentScale = ContentScale.Crop,
            )
        } else if (fallbackText.isNotBlank()) {
            Text(
                text = fallbackText.trim().first().uppercase(),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Clip,
            )
        } else {
            Icon(
                imageVector = placeholderIcon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(size * 0.45f),
            )
        }
    }
}

private fun calcSampleSize(w: Int, h: Int, reqPx: Int): Int {
    var s = 1

    val minSide = minOf(w, h)

    while (s * 2 <= minSide / reqPx) s *= 2

    return s.coerceAtLeast(1)
}

private fun decodeSampledStream(resolver: ContentResolver, uri: Uri, reqPx: Int): Bitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }

        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }

        val sample = calcSampleSize(bounds.outWidth, bounds.outHeight, reqPx)

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample

            inPreferredConfig = Bitmap.Config.HARDWARE
        }

        val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }

        bmp ?: resolver.openInputStream(uri)?.use {
            val fallbackOpts = BitmapFactory.Options().apply { inSampleSize = sample }

            BitmapFactory.decodeStream(it, null, fallbackOpts)
        }
    } catch (_: Exception) { null }
}

private fun decodeSampledFile(file: File, reqPx: Int): Bitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }

        BitmapFactory.decodeFile(file.absolutePath, bounds)

        val sample = calcSampleSize(bounds.outWidth, bounds.outHeight, reqPx)

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample

            inPreferredConfig = Bitmap.Config.HARDWARE
        }

        BitmapFactory.decodeFile(file.absolutePath, opts) ?: BitmapFactory.decodeFile(
            file.absolutePath,
            BitmapFactory.Options().apply { inSampleSize = sample }
        )
    } catch (_: Exception) { null }
}

private fun getNoArtworkMarkerFile(context: android.content.Context, key: String): File {
    val dir = File(context.filesDir, "artwork_store")
    if (!dir.exists()) dir.mkdirs()
    val hash = key.hashCode().toUInt().toString(16)
    return File(dir, "art_$hash.none")
}

private fun getArtworkStoreFile(context: android.content.Context, key: String): File {
    val dir = File(context.filesDir, "artwork_store")
    if (!dir.exists()) dir.mkdirs()
    val hash = key.hashCode().toUInt().toString(16)
    return File(dir, "art_$hash.webp")
}

private fun saveArtworkToDisk(bitmap: Bitmap, file: File) {
    try {
        val softwareBmp = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bitmap.config == Bitmap.Config.HARDWARE) {
            bitmap.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            bitmap
        } ?: bitmap

        val maxDim = 1024

        val scaled = if (softwareBmp.width > maxDim || softwareBmp.height > maxDim) {
            val ratio = minOf(maxDim.toFloat() / softwareBmp.width, maxDim.toFloat() / softwareBmp.height)

            val w = (softwareBmp.width * ratio).toInt().coerceAtLeast(1)

            val h = (softwareBmp.height * ratio).toInt().coerceAtLeast(1)

            Bitmap.createScaledBitmap(softwareBmp, w, h, true)
        } else {
            softwareBmp
        }

        val tempFile = File(file.parentFile, "${file.name}.tmp")

        tempFile.outputStream().use { out ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                scaled.compress(Bitmap.CompressFormat.WEBP_LOSSY, 95, out)
            } else {
                @Suppress("DEPRECATION")
                scaled.compress(Bitmap.CompressFormat.WEBP, 95, out)
            }
        }

        tempFile.renameTo(file)

        if (scaled != softwareBmp && scaled != bitmap) {
            scaled.recycle()
        }

        if (softwareBmp != bitmap) {
            softwareBmp.recycle()
        }
    } catch (_: Exception) {}
}

private fun extractMasterEmbeddedArtwork(
    context: android.content.Context,
    dataPath: String?,
    uri: Uri?,
    reqPx: Int,
    storeKey: String?
): Bitmap? {
    val noneFile = storeKey?.let { getNoArtworkMarkerFile(context, it) }
    if (noneFile != null && noneFile.exists()) {
        return null
    }

    val storeFile = storeKey?.let { getArtworkStoreFile(context, it) }

    if (storeFile != null && storeFile.exists() && storeFile.length() > 0) {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }

        BitmapFactory.decodeFile(storeFile.absolutePath, bounds)

        if (bounds.outWidth >= 400 || bounds.outHeight >= 400) {
            val cachedBmp = decodeSampledFile(storeFile, reqPx)

            if (cachedBmp != null) return cachedBmp
        } else {
            storeFile.delete()
        }
    }

    var rawBytes: ByteArray? = null

    if (!dataPath.isNullOrBlank()) {
        val file = File(dataPath)

        if (file.exists() && file.canRead()) {
            try {
                val retriever = MediaMetadataRetriever()

                retriever.setDataSource(dataPath)

                rawBytes = retriever.embeddedPicture

                retriever.release()
            } catch (_: Exception) {}

            if (rawBytes == null || rawBytes.isEmpty()) {
                rawBytes = TaglibHelper.getArtworkBytes(file)
            }
        }
    }

    if ((rawBytes == null || rawBytes.isEmpty()) && uri != null) {
        val uriStr = uri.toString()

        if (uriStr.contains("albumart", ignoreCase = true) || uriStr.endsWith(".jpg", ignoreCase = true) || uriStr.endsWith(".png", ignoreCase = true) || uriStr.endsWith(".webp", ignoreCase = true)) {
            val streamBmp = decodeSampledStream(context.contentResolver, uri, 1024)

            if (streamBmp != null) {
                if (storeFile != null) saveArtworkToDisk(streamBmp, storeFile)

                return decodeSampledFile(storeFile ?: return streamBmp, reqPx) ?: streamBmp
            }
        }

        try {
            val retriever = MediaMetadataRetriever()

            if (uri.scheme == "content") {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    retriever.setDataSource(pfd.fileDescriptor)

                    rawBytes = retriever.embeddedPicture
                }
            } else {
                retriever.setDataSource(uri.path ?: uri.toString())

                rawBytes = retriever.embeddedPicture
            }

            retriever.release()
        } catch (_: Exception) {}

        if (rawBytes == null || rawBytes.isEmpty()) {
            try {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    val pictures = TagLib.getPictures(pfd.dup().detachFd())

                    rawBytes = pictures.firstOrNull()?.data
                }
            } catch (_: Exception) {}
        }
    }

    if (rawBytes != null && rawBytes.isNotEmpty()) {
        val masterBmp = decodeSampledByteArray(rawBytes, 1024)

        if (masterBmp != null) {
            if (storeFile != null) {
                saveArtworkToDisk(masterBmp, storeFile)
            }

            return decodeSampledByteArray(rawBytes, reqPx) ?: masterBmp
        }
    }

    noneFile?.let { runCatching { it.createNewFile() } }
    return null
}

private fun decodeSampledByteArray(data: ByteArray, reqPx: Int): Bitmap? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }

        BitmapFactory.decodeByteArray(data, 0, data.size, bounds)

        val sample = calcSampleSize(bounds.outWidth, bounds.outHeight, reqPx)

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample

            inPreferredConfig = Bitmap.Config.HARDWARE
        }

        BitmapFactory.decodeByteArray(data, 0, data.size, opts) ?: BitmapFactory.decodeByteArray(
            data, 0, data.size,
            BitmapFactory.Options().apply { inSampleSize = sample }
        )
    } catch (_: Exception) { null }
}

