package com.example.ui.common.dialog

import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalOverscrollConfiguration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SheetValue
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import com.example.core.data.mediastore.tags.SongMetadata
import com.example.core.data.mediastore.tags.TaglibHelper
import com.example.core.model.Song
import com.example.ui.common.components.ArtworkCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongInfoBottomSheet(
    song: Song,
    onDismissRequest: () -> Unit
) {
    val context = LocalContext.current

    val coroutineScope = rememberCoroutineScope()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)

    val isFullscreen = sheetState.currentValue == SheetValue.Expanded

    var metadata by remember(song.id) {
        mutableStateOf(
            SongMetadata(
                title = song.title,
                artist = song.artist,
                album = song.album,
                year = song.year?.toString() ?: "",
                trackNumber = song.trackNumber?.toString() ?: "",
                genre = song.genre ?: ""
            )
        )
    }

    var isLoadingMetadata by remember(song.id) { mutableStateOf(true) }

    var isEditing by remember { mutableStateOf(false) }

    var isSaving by remember { mutableStateOf(false) }

    var editTitle by remember { mutableStateOf("") }

    var editArtist by remember { mutableStateOf("") }

    var editAlbum by remember { mutableStateOf("") }

    var editYear by remember { mutableStateOf("") }

    var editTrackNumber by remember { mutableStateOf("") }

    var editDiscNumber by remember { mutableStateOf("") }

    var editGenre by remember { mutableStateOf("") }

    var editAlbumArtist by remember { mutableStateOf("") }

    var editComposer by remember { mutableStateOf("") }

    var editCopyright by remember { mutableStateOf("") }

    var editLyric by remember { mutableStateOf("") }

    fun syncEditFields(m: SongMetadata) {
        editTitle = m.title
        editArtist = m.artist
        editAlbum = m.album
        editYear = m.year
        editTrackNumber = m.trackNumber
        editDiscNumber = m.discNumber
        editGenre = m.genre
        editAlbumArtist = m.albumArtist
        editComposer = m.composer
        editCopyright = m.copyright
        editLyric = m.lyrics
    }

    LaunchedEffect(song.id) {
        isLoadingMetadata = true

        val loaded = withContext(Dispatchers.IO) {
            TaglibHelper.getSongMetadata(context, song)
        }

        metadata = loaded

        syncEditFields(loaded)

        isLoadingMetadata = false
    }

    BackHandler(enabled = isFullscreen) {
        coroutineScope.launch {
            sheetState.partialExpand()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) },
        dragHandle = {
            BottomSheetDefaults.DragHandle(
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                width = 36.dp,
                height = 4.dp
            )
        },
        modifier = Modifier.testTag("song_info_bottom_sheet")
    ) {
        val view = LocalView.current
        val isDark = MaterialTheme.colorScheme.surface.luminance() <= 0.5f
        SideEffect {
            var parent = view.parent
            while (parent != null) {
                if (parent is DialogWindowProvider) {
                    val window = parent.window
                    window.navigationBarColor = android.graphics.Color.TRANSPARENT
                    window.statusBarColor = android.graphics.Color.TRANSPARENT
                    WindowCompat.setDecorFitsSystemWindows(window, false)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        window.isNavigationBarContrastEnforced = false
                    }
                    val insetsController = WindowCompat.getInsetsController(window, window.decorView)
                    insetsController.isAppearanceLightNavigationBars = !isDark
                    break
                }
                parent = parent.parent
            }
        }

        @OptIn(ExperimentalFoundationApi::class)
        CompositionLocalProvider(
            LocalOverscrollConfiguration provides null
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .navigationBarsPadding()
                    .padding(bottom = 24.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (isEditing) "Edit Metadata" else "Song Info",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                if (!isEditing) {
                    FilledTonalButton(
                        onClick = {
                            syncEditFields(metadata)

                            isEditing = true
                        },
                        modifier = Modifier.testTag("song_info_edit_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        Text("Edit")
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = {
                                syncEditFields(metadata)

                                isEditing = false
                            },
                            modifier = Modifier.testTag("song_info_cancel_edit_button")
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                ArtworkCard(
                    artworkUri = song.artworkUri,
                    contentUri = song.contentUri,
                    dataPath = song.dataPath,
                    size = 140.dp,
                    cornerRadius = 16.dp,
                    title = song.title,
                    modifier = Modifier.testTag("song_info_artwork")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.padding(horizontal = 8.dp)
                ) {
                    Text(
                        text = "${metadata.formattedDimensions}  ·  ${metadata.formattedArtworkSize}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (!isEditing) {
                InfoDisplayItem(label = "Title", value = metadata.title)

                InfoDisplayItem(label = "Artist", value = metadata.artist)

                InfoDisplayItem(label = "Album", value = metadata.album)

                InfoDisplayItem(label = "Year", value = metadata.year)

                InfoDisplayItem(label = "Track Number", value = metadata.trackNumber)

                InfoDisplayItem(label = "Disc Number", value = metadata.discNumber)

                InfoDisplayItem(label = "Genre", value = metadata.genre)

                InfoDisplayItem(label = "Album Artist", value = metadata.albumArtist)

                InfoDisplayItem(label = "Composer", value = metadata.composer)

                InfoDisplayItem(label = "Copyright", value = metadata.copyright)

                InfoDisplayItem(label = "Lyric", value = metadata.lyrics, isMultiline = true)
            } else {
                OutlinedTextField(
                    value = editTitle,
                    onValueChange = { editTitle = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_title")
                )

                OutlinedTextField(
                    value = editArtist,
                    onValueChange = { editArtist = it },
                    label = { Text("Artist") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_artist")
                )

                OutlinedTextField(
                    value = editAlbum,
                    onValueChange = { editAlbum = it },
                    label = { Text("Album") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_album")
                )

                OutlinedTextField(
                    value = editYear,
                    onValueChange = { editYear = it },
                    label = { Text("Year") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_year")
                )

                OutlinedTextField(
                    value = editTrackNumber,
                    onValueChange = { editTrackNumber = it },
                    label = { Text("Track Number") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_track_number")
                )

                OutlinedTextField(
                    value = editDiscNumber,
                    onValueChange = { editDiscNumber = it },
                    label = { Text("Disc Number") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_disc_number")
                )

                OutlinedTextField(
                    value = editGenre,
                    onValueChange = { editGenre = it },
                    label = { Text("Genre") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_genre")
                )

                OutlinedTextField(
                    value = editAlbumArtist,
                    onValueChange = { editAlbumArtist = it },
                    label = { Text("Album Artist") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_album_artist")
                )

                OutlinedTextField(
                    value = editComposer,
                    onValueChange = { editComposer = it },
                    label = { Text("Composer") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_composer")
                )

                OutlinedTextField(
                    value = editCopyright,
                    onValueChange = { editCopyright = it },
                    label = { Text("Copyright") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_copyright")
                )

                OutlinedTextField(
                    value = editLyric,
                    onValueChange = { editLyric = it },
                    label = { Text("Lyric") },
                    minLines = 4,
                    maxLines = 8,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .testTag("edit_field_lyric")
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (!isSaving) {
                            isSaving = true

                            val newMeta = metadata.copy(
                                title = editTitle.trim(),
                                artist = editArtist.trim(),
                                album = editAlbum.trim(),
                                year = editYear.trim(),
                                trackNumber = editTrackNumber.trim(),
                                discNumber = editDiscNumber.trim(),
                                genre = editGenre.trim(),
                                albumArtist = editAlbumArtist.trim(),
                                composer = editComposer.trim(),
                                copyright = editCopyright.trim(),
                                lyrics = editLyric.trim()
                            )

                            coroutineScope.launch {
                                val saved = TaglibHelper.saveSongMetadata(context, song, newMeta)

                                isSaving = false

                                if (saved) {
                                    metadata = newMeta

                                    isEditing = false

                                    Toast.makeText(context, "Metadata saved", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Failed to save metadata", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("song_info_save_button"),
                    enabled = !isSaving
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text("Saving...")
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.Save,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Text("Save")
                    }
                }
            }
        }
    }
}
}

@Composable
private fun InfoDisplayItem(
    label: String,
    value: String,
    isMultiline: Boolean = false
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = if (value.isNotBlank()) value else "—",
                style = MaterialTheme.typography.bodyMedium,
                color = if (value.isNotBlank()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                maxLines = if (isMultiline) 20 else 2
            )
        }
    }
}
