package com.example.ui.common.theme

import androidx.compose.ui.graphics.Color

val PixelPlayPurpleDark = Color(0xFF121214)

val PixelPlaySurface = Color(0xFF18181C)

val PixelPlaySurfaceContainer = Color(0xFF222228)

val PixelPlaySurfaceContainerHigh = Color(0xFF2C2C34)

val PixelPlaySurfaceContainerHighest = Color(0xFF363640)

val PixelPlaySurfaceContainerLow = Color(0xFF1C1C20)

val PixelPlayPurplePrimary = Color(0xFF8B5CF6)

val PixelPlayPink = Color(0xFFEC4899)

val PixelPlayOrange = Color(0xFFF97316)

val PixelPlayLightPurple = Color(0xFFF1F1F5)

val PixelPlayMuted = Color(0xFFA1A1AA)

val PixelPlayOutline = Color(0xFF52525B)

val PixelPlayOutlineVariant = Color(0xFF3F3F46)

val PixelPlayWhite = Color(0xFFFFFFFF)

val PixelPlayBlack = Color(0xFF000000)

val LightBackground = Color(0xFFF8F9FC)

val LightSurface = Color(0xFFFFFFFF)

val LightSurfaceContainer = Color(0xFFF0F2F7)

val LightSurfaceContainerHigh = Color(0xFFE5E8F0)

val LightSurfaceContainerHighest = Color(0xFFDBDFEA)

val LightSurfaceContainerLow = Color(0xFFF5F6FA)

val LightSurfaceVariant = Color(0xFFE8EBF2)

val LightOnSurface = Color(0xFF14161C)

val LightOnSurfaceVariant = Color(0xFF5E6472)

val LightPrimary = Color(0xFF6366F1)

val LightPrimaryContainer = Color(0xFFE0E7FF)

val LightOnPrimaryContainer = Color(0xFF1E1B4B)

val LightOutline = Color(0xFF94A3B8)

val LightOutlineVariant = Color(0xFFCBD5E1)

val AmoledBg = Color(0xFF000000)

val AmoledSurface = Color(0xFF000000)

val AmoledSurfaceContainer = Color(0xFF121215)

val AmoledSurfaceContainerHigh = Color(0xFF1A1A1E)

val AmoledSurfaceContainerHighest = Color(0xFF242429)

val AmoledOnSurface = Color(0xFFF4F4F6)

val AmoledBorder = Color(0xFF2B2B32)

val AccentPurple = PixelPlayPurplePrimary

val AccentIndigo = LightPrimary

val AccentPink = PixelPlayPink

val AccentOrange = PixelPlayOrange

val AccentTeal = Color(0xFF14B8A6)

val AccentEmerald = Color(0xFF10B981)

val AccentAmber = Color(0xFFF59E0B)

val AccentCoral = Color(0xFFF43F5E)

val SoftLightBlue = Color(0xFF64B5F6)

val AccentBlue = SoftLightBlue
