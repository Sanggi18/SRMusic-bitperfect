package com.example.ui.home.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.audio.AudioOutputDetector
import com.example.core.audio.AudioOutputType
import com.example.core.audio.AudioTerminalLogger
import com.example.core.data.preferences.EqualizerPreferences
import com.example.core.model.Song
import com.example.ui.player.components.rememberAudioOutputInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeTerminal(
    currentSong: Song?,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val coroutineScope = rememberCoroutineScope()

    val audioOutputInfo = rememberAudioOutputInfo()

    val isDacConnected = remember(audioOutputInfo) {
        AudioOutputDetector.isDacConnected(context)
    }

    var isBitPerfectPref by remember {
        mutableStateOf(EqualizerPreferences(context).loadEqualizerConfig().isBitPerfectEnabled)
    }

    DisposableEffect(context) {
        val prefs = context.getSharedPreferences("srmusic_prefs", Context.MODE_PRIVATE)

        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "eq_bit_perfect" || key == null) {
                isBitPerfectPref = prefs.getBoolean("eq_bit_perfect", false)
            }
        }

        prefs.registerOnSharedPreferenceChangeListener(listener)

        isBitPerfectPref = prefs.getBoolean("eq_bit_perfect", false)

        onDispose {
            prefs.unregisterOnSharedPreferenceChangeListener(listener)
        }
    }

    LaunchedEffect(Unit) {
        AudioTerminalLogger.init(context)
    }

    val isBitPerfectActive = isBitPerfectPref && (audioOutputInfo.type == AudioOutputType.USB) && isPlaying

    val logs by AudioTerminalLogger.logs.collectAsState()

    val diagLogs by AudioTerminalLogger.diagLogs.collectAsState()

    val terminalListState = rememberLazyListState()

    val diagListState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            terminalListState.animateScrollToItem(logs.size - 1)
        }
    }

    LaunchedEffect(diagLogs.size) {
        if (diagLogs.isNotEmpty()) {
            diagListState.animateScrollToItem(diagLogs.size - 1)
        }
    }

    val containerBg = MaterialTheme.colorScheme.surfaceContainer

    val primaryColor = MaterialTheme.colorScheme.primary

    val onSurfaceColor = MaterialTheme.colorScheme.onSurface

    val outputLabel = when (audioOutputInfo.type) {
        AudioOutputType.USB -> "USB Audio"

        AudioOutputType.SPEAKER -> "Speaker"

        AudioOutputType.BLUETOOTH -> "Bluetooth"

        AudioOutputType.WIRED -> "Headset"
    }

    val outputDotColor = when {
        isBitPerfectActive -> Color(0xFF2196F3)

        isPlaying -> Color(0xFF00C853)

        currentSong != null -> Color(0xFF9E9E9E)

        else -> Color(0xFFF44336)
    }

    val pagerState = rememberPagerState(initialPage = 0) { 2 }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch(Dispatchers.IO) {
                try {
                    val logDump = buildString {
                        appendLine("SRMusic Audio Subsystem Diagnostic Log")

                        val deviceName = Build.MODEL

                        val primaryAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"

                        val armInfo = primaryAbi.replace("-", "")

                        appendLine("Device Name: $deviceName")

                        appendLine("Arm: $armInfo")

                        appendLine("Android Version: ${Build.VERSION.RELEASE}")

                        appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")

                        appendLine("Output Route: ${audioOutputInfo.displayName} [${audioOutputInfo.type}]")

                        appendLine()

                        appendLine("--- Terminal Audio ---")

                        logs.forEach { appendLine(it) }

                        appendLine()

                        appendLine("--- Log Audio ---")

                        diagLogs.forEach { appendLine(it.replace("SRMusicAudioDiag: ", ": ").replace("SRMusicAudioDiag ", "")) }
                    }

                    context.contentResolver.openOutputStream(uri)?.use { stream ->
                        stream.write(logDump.toByteArray(Charsets.UTF_8))
                    }

                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Log successfully saved to srmusic-audio.log", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Failed to save log: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    val onCopyClick: () -> Unit = {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

        val textToCopy = if (pagerState.currentPage == 0) {
            logs.joinToString(separator = "\n")
        } else {
            diagLogs.joinToString(separator = "\n") {
                it.replace("SRMusicAudioDiag: ", ": ").replace("SRMusicAudioDiag ", "")
            }
        }

        if (textToCopy.isNotEmpty()) {
            val clip = ClipData.newPlainText("SRMusic Audio Log", textToCopy)

            clipboard?.setPrimaryClip(clip)

            Toast.makeText(context, "Terminal logs copied to clipboard", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Logs are empty", Toast.LENGTH_SHORT).show()
        }
    }

    val onSaveClick: () -> Unit = {
        saveLauncher.launch("srmusic-audio.log")
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(100.dp)
            .padding(horizontal = 16.dp)
            .testTag("home_terminal"),
        shape = RoundedCornerShape(16.dp),
        color = containerBg,
        tonalElevation = 2.dp,
        border = null
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 7.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (page == 0) ">_ Terminal Audio [1]" else ">_ Log Audio [2]",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            letterSpacing = 0.3.sp
                        ),
                        color = primaryColor
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .clickable(onClick = onCopyClick),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = "Copy Log",
                                tint = onSurfaceColor,
                                modifier = Modifier.size(11.dp)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .clickable(onClick = onSaveClick),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SaveAlt,
                                contentDescription = "Save Log",
                                tint = onSurfaceColor,
                                modifier = Modifier.size(11.dp)
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 5.dp, vertical = 1.5.dp)
                        ) {
                            Text(
                                text = outputLabel,
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 8.5.sp
                                ),
                                color = onSurfaceColor
                            )

                            Spacer(modifier = Modifier.width(4.dp))

                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(outputDotColor)
                            )
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    if (page == 0) {
                        TerminalLogList(
                            list = logs,
                            state = terminalListState,
                            isTerminal1 = true,
                            onSurfaceColor = onSurfaceColor
                        )
                    } else {
                        TerminalLogList(
                            list = diagLogs,
                            state = diagListState,
                            isTerminal1 = false,
                            onSurfaceColor = onSurfaceColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TerminalLogList(
    list: List<String>,
    state: LazyListState,
    isTerminal1: Boolean,
    onSurfaceColor: Color
) {
    LazyColumn(
        state = state,
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(1.5.dp)
    ) {
        items(list) { rawLine ->
            val line = if (!isTerminal1) {
                rawLine.replace("SRMusicAudioDiag: ", ": ").replace("SRMusicAudioDiag ", "")
            } else {
                rawLine
            }

            val isBlue = isTerminal1 && (
                (line.contains("PLAYER_READY") && line.contains("isBitPerfect=true")) ||
                line.contains("Bit-Perfect Route: ACTIVE")
            )

            val textColor = if (isBlue) Color(0xFF2196F3) else onSurfaceColor

            val fontWeight = if (isBlue) FontWeight.Bold else FontWeight.Normal

            Text(
                text = line,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = fontWeight,
                    lineHeight = 12.sp
                ),
                color = textColor
            )
        }
    }
}
