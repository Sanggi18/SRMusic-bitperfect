package com.example.ui.settings.about

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class ChangelogRelease(
    val version: String,
    val date: String,
    val badge: String,
    val isLatest: Boolean,
    val sections: List<ChangelogSection>
)

private data class ChangelogSection(
    val title: String,
    val icon: ImageVector,
    val items: List<String>
)

@Composable
fun ChangelogScreen(modifier: Modifier = Modifier) {
    val releases = listOf(
        ChangelogRelease(
            version = "1.1.0-beta4",
            date = "October 2026",
            badge = "Latest",
            isLatest = true,
            sections = listOf(
                ChangelogSection(
                    title = "Version Updates",
                    icon = Icons.Rounded.NewReleases,
                    items = listOf(
                        "Release updated to version 1.1.0-beta4.",
                        "Audio playback stability and UI performance optimizations."
                    )
                ),
                ChangelogSection(
                    title = "Design & UI Updates",
                    icon = Icons.Rounded.CheckCircle,
                    items = listOf(
                        "Refreshed About App screen in minimal Material 3 Expressive style.",
                        "New app icon with elegant squircle profile and proportional glyph.",
                        "Smooth grouped card containers in settings menu and info dialogs."
                    )
                )
            )
        ),
        ChangelogRelease(
            version = "1.1.0-beta3",
            date = "October 2026",
            badge = "Previous",
            isLatest = false,
            sections = listOf(
                ChangelogSection(
                    title = "Design & UI Updates",
                    icon = Icons.Rounded.NewReleases,
                    items = listOf(
                        "Refreshed About App screen in minimal Material 3 Expressive style.",
                        "New app icon with elegant squircle profile and proportional glyph.",
                        "Smooth grouped card containers in settings menu and info dialogs."
                    )
                ),
                ChangelogSection(
                    title = "Improvements & Cleanup",
                    icon = Icons.Rounded.CheckCircle,
                    items = listOf(
                        "Playback performance optimization and progress seeker deduplication.",
                        "Dynamic color palette alignment and navigation transition polish."
                    )
                )
            )
        ),
        ChangelogRelease(
            version = "1.0.0",
            date = "Initial Release",
            badge = "Stable",
            isLatest = false,
            sections = listOf(
                ChangelogSection(
                    title = "Core Features",
                    icon = Icons.Rounded.NewReleases,
                    items = listOf(
                        "Categorized Settings Architecture: Appearance, Audio & Playback, Library, and App.",
                        "Material 3 & Dynamic Color: System, Dark, Light, AMOLED modes, and 5 custom presets.",
                        "Flexible Navigation Tabs: Customize order and visibility of bottom navigation tabs.",
                        "Hierarchical Folder Navigation: Browse audio directories directly from device storage.",
                        "Precision 10-Band Equalizer: Vertical fader controls, Bit-Perfect mode, and audio routing.",
                        "Full-Screen Now Playing: Synchronized lyrics support and audio visualizer."
                    )
                )
            )
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        releases.forEach { release ->
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "v${release.version}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Spacer(Modifier.width(8.dp))

                            Surface(
                                shape = CircleShape,
                                color = if (release.isLatest)

                                    MaterialTheme.colorScheme.primaryContainer

                                else

                                    MaterialTheme.colorScheme.surfaceContainerHighest
                            ) {
                                Text(
                                    text = release.badge,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = if (release.isLatest)

                                        MaterialTheme.colorScheme.onPrimaryContainer

                                    else

                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Text(
                            text = release.date,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    release.sections.forEachIndexed { index, section ->
                        if (index > 0) {
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 14.dp),
                                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                                thickness = 0.5.dp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = section.icon,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )

                            Spacer(Modifier.width(8.dp))

                            Text(
                                text = section.title,
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(Modifier.height(8.dp))

                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            section.items.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Text(
                                        text = "·",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )

                                    Text(
                                        text = item,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}
